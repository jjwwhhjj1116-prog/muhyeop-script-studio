# 무협스튜디오 안티그래비티 완전 이관 계획

작성일: 2026-08-21  
작성자: Manus AI

## 1. 목표와 이관 완료 정의

이 계획의 목표는 현재 Manus WebDev에서 동작하는 **무협스튜디오**를 안티그래비티의 로컬 개발 환경으로 옮기고, 배포 후에는 Manus 인증, 내장 언어 모델, 내장 이미지 생성, `/manus-storage` 파일 주소, Manus 데이터베이스 및 자동 게시에 더 이상 의존하지 않게 만드는 것이다. 안티그래비티는 코드 실행, 로컬 파일 조작, 웹 탐색, 스킬 및 MCP 연결을 수행하는 로컬 에이전트 중심 개발 환경이므로, 소스 개발 및 유지 관리는 안티그래비티에서 맡고, 실제 서비스는 Firebase와 Google Cloud에 배포한다.[1] [2]

> **완전 이관의 기준은 화면을 복사하는 것이 아니라, 사용자의 대본·상태 장부·작업 이력·생성 자산이 Manus 없이 저장, 조회, 수정, 내보내기, 검수, 생성될 수 있는 상태다.**

| 완료 항목 | 이관 완료 기준 |
|---|---|
| 대시보드 | 21청크 열람·편집·기획안 첨부·상태 장부·제작 승인 흐름이 새 주소에서 동작 |
| 연속성 | 정본, 상태 장부, 브라우저 검수, Python 컴파일러 검사 결과가 기존 기준과 동일 |
| 데이터 | 기존 작업실 백업 JSON을 새 프로젝트로 가져와 원고·수정본·버전·장부·기획안을 복원 |
| AI | 안티그래비티가 정본 파일을 읽고 청크 초안·수정을 수행하며, 필요할 때만 대시보드 내부 자동 생성 API를 추가 |
| 파일 | 이미지·백업·내보내기 파일이 Google Cloud Storage 또는 사용자 로컬 파일에 보관 |
| 영상 | Flow용 TXT·매핑 JSON·ZIP을 새 대시보드에서 그대로 생성하고, 영상 결과는 파일/URL로 다시 연결 |
| 운영 | GitHub 기반 버전 관리, 스테이징 검증, 운영 배포, 이전 버전 복구 절차를 갖춤 |

## 2. 현재 자산 및 의존성 인벤토리

현재 화면과 핵심 업무 규칙의 대다수는 React와 브라우저에서 실행된다. 특히 원고·상태 장부·기획안·버전·제작 워크플로우는 현재 브라우저 저장소에 보관되며, 통합본·JSON·CSV·Flow ZIP 내보내기와 연속성·앵커 충돌 검수도 클라이언트 로직으로 구현되어 있다. 따라서 UI와 검수 엔진은 재사용성이 높다. 반면 AI 생성, 인증, 이미지 저장, 기본 정적 자산 주소는 Manus 전용 서비스에 결합되어 있어 명시적 교체가 필요하다.

| 구역 | 현재 구현 | 이관 판단 | 안티그래비티 이관 방식 |
|---|---|---|---|
| 화면·편집기 | React 19, TypeScript, Vite, Tailwind, shadcn, Wouter | 대부분 재사용 | 소스 유지, Manus 전용 import만 제거 |
| 21청크·정본 검수 | `continuityValidator`, `stateLedgerValidator`, `productionWorkflow` | 그대로 재사용 | 순수 TS 모듈로 유지, Python 컴파일러와 교차 검증 |
| 작업실 데이터 | localStorage 및 `칠성탈명록_작업실_백업.json` | 이전 가능 | Firestore 영속화 + 최초 1회 백업 JSON 가져오기 |
| 버전·수정 이력 | localStorage | 이전 가능 | Firestore 버전 문서와 불변 이력으로 전환 |
| Flow·CSV·ZIP 내보내기 | 브라우저 Blob, fflate | 그대로 재사용 | 클라이언트 내보내기 유지 |
| 고밀도 프롬프트 | Manus 서버의 LLM 래퍼 | 선택적 교체 | 기본은 안티그래비티가 파일 기준으로 작성, 대시보드 버튼 자동 생성은 Cloud Run API 어댑터로 추가 |
| 대본 재작성·문체 점수 | Manus 서버의 LLM 래퍼 | 선택적 교체 | 기본은 안티그래비티가 정본·장부를 읽고 수행, 대시보드 버튼 자동 평가는 API 어댑터로 추가 |
| 인물·장면 이미지 | Manus ImageService + Manus Storage | 교체 필요 | Cloud Run API + Google 이미지 생성 어댑터 + Cloud Storage |
| 로그인 | Manus OAuth·protectedProcedure | 교체 필요 | Firebase Authentication + Cloud Run ID 토큰 검증 |
| API | Express + tRPC | 유지 가능 | Express+tRPC 유지, Cloud Run 배포 |
| 정적 이미지 | `/manus-storage/...` URL | 교체 필요 | Cloud Storage 공개/서명 URL 또는 Firebase Hosting 정적 자산 |
| 배포·복구 | Manus 체크포인트·자동 게시 | 교체 필요 | GitHub PR, Firebase Hosting Preview, Cloud Run revision, Firebase rollback |

## 3. 권장 대상 아키텍처

가장 안전한 방식은 프런트엔드를 다시 쓰지 않고 현재 React/Vite + Express/tRPC 구조를 보존하는 것이다. Firebase Hosting은 SPA를 전역 CDN으로 제공하고 Cloud Run 또는 Cloud Functions와 연결할 수 있으므로, Vite 정적 프런트엔드와 Express API를 분리해 운영하기 적합하다.[3] 안티그래비티는 이 GitHub 저장소를 열고 로컬에서 개발·테스트·배포하는 작업 환경으로 사용한다.[1] [2]

```text
사용자 브라우저
  ├─ Firebase Hosting
  │   └─ React/Vite 무협스튜디오
  ├─ Firebase Authentication
  │   └─ Google 로그인 + 허용 사용자 확인
  └─ /api/trpc/*
      └─ Cloud Run: Express + tRPC
          ├─ Firestore: 프로젝트·청크·장부·버전·워크플로우 메타데이터
          ├─ Cloud Storage: 기획안 원본·이미지·백업·선택적 생성 산출물
          ├─ 선택형 Gemini API/Vertex AI: 대시보드 내부 자동 재작성·점수·구조화 프롬프트
          └─ 이미지 생성 제공자: 성인 외형 정책을 적용한 Gemini 이미지 모델

GitHub → GitHub Actions → Hosting Preview / Cloud Run Staging → Production
안티그래비티 → 정본 파일 독해·청크 작성/수정·컴파일러 실행·리뷰·배포 지시
```

### 3-1. 권장 서비스 결정

| 기능 | 권장 선택 | 선택 이유 | 금지 또는 주의 사항 |
|---|---|---|---|
| 개발 작업실 | Google Antigravity | 로컬 파일·터미널·에이전트 기반 개발 및 GitHub 작업 | 안티그래비티 자체를 운영 서버로 간주하지 않음 |
| 소스 정본 | GitHub 비공개 저장소 | 코드·문서·검수 규칙·배포 이력의 단일 기준점 | API 키와 사용자 백업 파일은 커밋 금지 |
| 프런트엔드 | Firebase Hosting | SPA 배포, 미리보기 채널, HTTPS, 되돌리기 | `/manus-storage` URL을 모두 제거 |
| API | Cloud Run의 Express+tRPC | 현재 API 계약 재사용, 비밀키 서버 보관, 확장 용이 | 브라우저에서 모델 API 키 직접 호출 금지 |
| 로그인 | Firebase Authentication | Google 계정 로그인과 소유자 제한을 분리 가능 | 프런트엔드 로그인만 믿지 말고 서버에서 토큰 검증 |
| 데이터 | Cloud Firestore | 청크·장부·버전·워크플로우 문서 단위 저장에 적합 | 원고 이력 삭제 대신 불변 버전 사용 |
| 바이너리 | Cloud Storage | 이미지와 원본 기획안, 백업 파일 저장 | Firestore에 이미지 바이트나 대형 파일 저장 금지 |
| 기본 글쓰기 AI | Google Antigravity | Google AI Ultra의 모델 할당량으로 정본 파일을 읽고 대본 초안·수정·검수를 수행 | 대시보드가 모델 API를 직접 호출한다고 가정하지 않음.[6] |
| 선택형 텍스트 API | Gemini 구조화 출력 | 대시보드 안의 한 번 클릭 재작성·점수·장면 프롬프트가 필요할 때만 추가 | 생성 결과도 기존 TS/Python 검수를 통과해야만 저장.[4] [6] |
| 이미지 AI | 모델명을 환경 설정으로 분리한 Gemini 이미지 어댑터 | 제공 모델 교체에 대비하고, 인물·장면 생성 계약을 유지 | 현재 Imagen 문서는 Nano Banana 계열로의 전환을 권고하므로 Imagen 모델명을 코드에 고정하지 않음.[5] |
| 영상 | Flow 입력용 TXT·매핑 JSON·ZIP 유지 | Flow Ultra 웹 사용 방식과 별개로 대시보드 산출물은 독립 유지 | Flow 웹 UI 자동 조작은 이관 범위에서 제외하고 영상 결과 파일/URL만 재연결 |

### 3-2. 글쓰기 운영 방식의 분리

대본의 정본성은 모델 이름보다 **정본 파일, 21청크 경계, 상태 장부, Python 컴파일러를 항상 같은 작업 맥락으로 제공하는가**에 의해 결정된다. 따라서 기본 운영은 안티그래비티가 GitHub 작업 폴더의 정본·상태 장부·대상 청크를 읽고 Markdown을 직접 수정한 뒤 컴파일러를 실행하는 방식으로 둔다. Google AI Ultra는 안티그래비티 안에서 높은 모델 할당량을 제공하므로, 이 글쓰기 경로에는 별도 대시보드 API 키가 필요하지 않다.[6] [7]

| 운영 방식 | 대본 작성 주체 | 별도 API 키 | 적합한 업무 | 제약 |
|---|---|---|---|---|
| **권장 기본: 안티그래비티 작성** | 안티그래비티 에이전트가 프로젝트 파일을 읽고 청크 Markdown 수정 | 필요 없음 | 새 청크 초안, 지시 반영 최소 수정, 상태 장부 갱신, 컴파일러 검수 | 안티그래비티 세션·모델 할당량에 따름 |
| 대시보드 수동 관리 | 사용자가 대시보드 편집기에서 직접 수정 | 필요 없음 | 파일 가져오기·비교·통합본·Flow ZIP·충돌 복구 | AI 재작성 버튼은 비활성 또는 안내 상태 |
| 대시보드 자동 작성 | Cloud Run이 Gemini API를 호출 | 필요 | 청크별 버튼 재작성, 점수 재평가, 프롬프트 일괄 생성 | Gemini API와 Google Cloud 과금은 별도 관리 |
| ChatGPT·Claude 보조 작성 | 각 서비스 웹/데스크톱 앱에서 작성 후 Markdown 가져오기 | 필요 없음 | 대안 초안, 훅 비교, 대사 후보 | ChatGPT/Claude 구독과 API 과금은 분리되므로 대시보드 자동 호출에는 그대로 쓸 수 없음.[8] [9] |

> 안티그래비티는 **글쓰는 주체**, 무협스튜디오는 **정본을 보관하고 검수·이미지·Flow 자료를 관리하는 작업실**로 역할을 분리한다. 이 구조는 현재의 구독을 먼저 활용하면서, 나중에 버튼형 자동화가 필요할 때만 API를 추가하게 한다.

## 4. 새 데이터 모델

현재 브라우저 저장소 키를 그대로 서버 데이터 모델로 옮기지 않는다. 프로젝트 단위로 묶고, 청크와 상태 장부는 번호별 문서, 수정본과 충돌 수정은 불변 이력으로 저장한다. 로컬 저장소는 오프라인 임시 캐시로만 남긴다.

| Firestore 경로 | 핵심 필드 | 기존 데이터 원천 | 보존 원칙 |
|---|---|---|---|
| `projects/{projectId}` | 제목, 정본 버전, 생성일, 최근 수정일, 소유자 | `projectBrief`, 현재 작품명 | 정본 기준과 프로젝트 설정 분리 |
| `projects/{id}/briefs/current` | 원본 파일명, Markdown, 해시, 업로드 시각 | `projectBrief` | 제목 파생 규칙 유지 |
| `projects/{id}/chunks/{01..21}` | 원본, 현재 수정본, 해시, 출처, 수정 시각 | `importedChunks`, `editedChunks` | 현재본만 빠르게 조회 |
| `projects/{id}/chunkVersions/{versionId}` | 청크 번호, 본문, 메모, 차이, 생성자, 시각 | `draftVersions` | 삭제 대신 버전 보관 |
| `projects/{id}/stateLedgers/{01..21}` | 인물·나이·관계·소지품·인지·종료 상태 | `stateLedgers` | 컴파일러의 입력 계약 |
| `projects/{id}/workflow/current` | 승인 단계, 장면, 캐릭터, 프롬프트, 충돌 이력 | `chilseong-production-workflow-v1` | 워크플로우 최신 상태 |
| `projects/{id}/workflowEvents/{eventId}` | 변경 주체, 전후 상태 요약, 무효화 사유 | 공통 충돌·프롬프트 보정 이력 | 복구 가능한 감사 로그 |
| `projects/{id}/assets/{assetId}` | Storage 경로, MIME, 해시, 프롬프트, 생성 모델 | 인물·장면 이미지 URL | 파일 바이트는 Storage에만 저장 |
| `projects/{id}/exports/{exportId}` | 생성 산출물 메타데이터, 원고 해시, 다운로드 경로 | JSON·ZIP 내보내기 | 재현 가능한 내보내기 기록 |

Cloud Storage는 아래와 같이 분리한다. `projects/{projectId}/briefs/`, `assets/characters/`, `assets/scenes/`, `backups/`, `exports/` 경로를 사용하고, 파일명 대신 무작위 ID와 SHA-256 해시를 함께 기록한다. 각 프로젝트의 소유자만 읽고 쓸 수 있도록 Firebase Security Rules와 Cloud Run 서버 검사를 함께 둔다.

## 5. 코드 이관 순서

### 5-1. 0단계: 동결과 인수 백업

먼저 현재 Manus 버전을 동결한다. 최종 체크포인트 `da0681b9`를 기준점으로 기록하고, 대시보드의 **작업실 백업**에서 현재 브라우저별 데이터를 JSON으로 내보낸다. 브라우저 저장소는 기기마다 별개이므로, 데스크톱·노트북·모바일에 서로 다른 수정본이 있다면 각 기기에서 모두 백업해야 한다. 이 단계는 데이터를 합치는 작업이 아니라, 원본을 잃지 않기 위한 보존 절차다.

| 산출물 | 생성 방법 | 인수 확인 |
|---|---|---|
| 소스 기준점 | GitHub 비공개 저장소에 현재 프로젝트 소스 이관 | `pnpm test`, `pnpm build` 성공 |
| 정본 문서 | V12 FULL, 프로젝트 컨텍스트, canon, Python 컴파일러 | 읽기 전용 파일의 SHA-256 기록 |
| 작업실 백업 | 각 기기의 `칠성탈명록_작업실_백업.json` | 21청크·장부·기획안·수정 이력 포함 여부 |
| 제작 백업 | `workflow/current`에 해당하는 브라우저 저장 데이터 | 캐릭터·장면·프롬프트·충돌 이력 확인 |
| 이미지 자산 목록 | 기존 `/manus-storage` URL, 파일명, 해시, 사용 위치 | 새 Storage 업로드 후 URL 교체 가능 여부 |

### 5-2. 1단계: GitHub와 안티그래비티 개발 환경 구성

안티그래비티에서 비공개 GitHub 저장소를 연다. Node.js 22, pnpm, Python 3.11 이상, Firebase CLI, Google Cloud CLI를 설치한다. Antigravity 공식 안내도 로컬 개발 환경과 Node.js, Firebase CLI를 전제로 하며, GitHub와 Firebase CLI를 통한 배포를 지원한다.[2]

이 단계에서 `MANUS_*`, `BUILT_IN_FORGE_*`, `/manus-storage/` 검색 결과를 모두 이관 목록으로 생성한다. 또한 `migration/manifest.json`을 만들고, 각 파일의 이관 상태를 `portable`, `replace`, `remove`, `verify` 네 상태로 관리한다.

### 5-3. 2단계: 플랫폼 어댑터 분리

기존 비즈니스 규칙을 바꾸기 전에 플랫폼 의존부를 아래 인터페이스로 분리한다. 이 작업이 완료되면 검수·제작 로직은 특정 클라우드와 무관해진다.

```ts
interface ProjectRepository {
  loadProject(projectId: string): Promise<ProjectSnapshot>
  saveProjectPatch(projectId: string, patch: ProjectPatch): Promise<void>
  appendEvent(projectId: string, event: WorkflowEvent): Promise<void>
}

interface TextGenerationService {
  rewriteChunk(input: RewriteRequest): Promise<RewriteResult>
  scoreChunk(input: ScoreRequest): Promise<ScoreResult>
  generateDensePrompts(input: DensePromptRequest): Promise<DensePromptResult>
}

interface ImageGenerationService {
  generateCharacter(input: CharacterImageRequest): Promise<GeneratedAsset>
  generateScene(input: SceneImageRequest): Promise<GeneratedAsset>
}

interface AssetStore {
  put(input: BinaryAsset): Promise<StoredAsset>
  signedRead(assetId: string): Promise<string>
}
```

`productionWorkflow.ts`, `continuityValidator.ts`, `stateLedgerValidator.ts`, Flow ZIP 빌더, 충돌 검사, 프롬프트 자동 보정은 이 인터페이스 아래에서 변경 없이 재사용한다. `trpc`는 즉시 제거하지 않고 Express+tRPC를 Cloud Run으로 옮긴 뒤, 안정화 후 REST/OpenAPI 전환 필요성이 있을 때만 검토한다.

### 5-4. 3단계: 데이터와 자산 이전

새 대시보드에 **Manus 작업실 백업 가져오기** 마법사를 추가한다. JSON 스키마를 검사하고, 프로젝트 생성 → 기획안 → 21청크 → 수정본 버전 → 상태 장부 → 제작 워크플로우 → 스타일 프로필 순서로 Firestore에 기록한다. 가져오기 전에는 미리보기와 충돌 정책을 표시한다.

| 충돌 대상 | 기본 정책 | 이유 |
|---|---|---|
| 동일 청크 | 해시가 같으면 건너뜀, 다르면 새 버전으로 저장 | 수정본 유실 방지 |
| 상태 장부 | 새 장부를 별도 버전으로 보관 후 현재본 선택 | 연속성 계약 손상 방지 |
| 기획안 | 원본 파일명·시각을 유지한 버전 추가 | 제목 파생 근거 보존 |
| 워크플로우 | 원고 해시 불일치 시 시각화 이후 단계를 무효화 | 잘못된 이미지·Flow 재사용 차단 |
| 기존 이미지 | 새 Storage에 복사 후 해시 대조 | Manus URL 제거 및 참조 안정화 |

데이터 이전 뒤에는 기존 Python 컴파일러의 `check-all`과 웹 검수기를 모두 실행한다. 두 결과가 기존 정본과 동일하거나, 설명 가능한 개선 경고만 남아야 다음 단계로 진행한다.

### 5-5. 4단계: 안티그래비티 글쓰기 흐름 정착과 선택형 AI·이미지 API

기본 글쓰기 작업은 안티그래비티가 GitHub 작업 폴더에서 `정본 → 상태 장부 → 대상 청크 → 컴파일러` 순서로 수행한다. 안티그래비티가 작성한 Markdown은 즉시 대시보드에 가져오거나, 같은 Firestore 프로젝트에 저장한 뒤 기존 검수 엔진으로 확인한다. 이 단계에서는 Gemini API 키가 없어도 대본 작성·수정·연속성 검수·내보내기가 가능하다.

대시보드 안에서 **재작성**, **문체 점수**, **고밀도 프롬프트 생성** 버튼까지 자동화하려는 경우에만 Cloud Run의 Gemini API 어댑터를 구현한다. Gemini API는 JSON Schema 기반 구조화 출력을 지원하므로, 현재 장면 번호·문장 ID·프롬프트 길이·영문·텍스트 제거 지시 검증을 모델 응답 이전과 이후 두 번 적용한다.[4] Google AI Ultra의 AI Studio·안티그래비티 할당량과 외부 앱의 Gemini API 사용량은 별도 체계이므로, 이 선택형 자동화에는 API 키와 결제 한도가 필요하다.[6]

인물과 장면 이미지는 서버의 `ImageGenerationService`가 생성하고, 응답 바이트는 Cloud Storage에 업로드한 뒤 안전한 접근 URL만 클라이언트에 전달한다. 모델 ID는 코드 상수가 아니라 서버 환경 설정으로 둔다. 공식 문서상 Imagen 계열은 종료 예정이며 Gemini 이미지 생성 모델로의 이동을 권고하므로, 실제 운영 전 이미지 모델 승인 테스트를 한 번 수행하고 고정한다.[5]

복아·회상 인물 등 모든 생성 요청에는 **성인 외형만 허용**한다는 제작 규칙을 서버 프롬프트와 제공자 안전 설정에 함께 넣는다. 사용자 입력이 그 규칙을 약화시키면 생성 요청을 중단하고 수정 안내를 표시한다.

### 5-6. 5단계: 인증, 권한, 저장 규칙 적용

첫 운영 버전은 다중 사용자 공개 서비스가 아니라 YOO 전용 제작실로 제한한다. Firebase Authentication의 Google 로그인으로 사용자 토큰을 얻고, Cloud Run에서 토큰 검증 후 허용된 UID 또는 이메일만 쓰기 작업을 통과시킨다. Firestore와 Storage Rules에서도 동일 소유자만 접근 가능하도록 제한한다.

| 역할 | 권한 |
|---|---|
| Owner | 프로젝트 생성·삭제, 정본 교체, AI 생성, 데이터 이관, 모든 내보내기 |
| Editor | 명시적으로 초대할 경우 원고·장부 수정 및 생성 요청 |
| Viewer | 읽기·내보내기만 가능, 정본·워크플로우 수정 불가 |

### 5-7. 6단계: 배포·전환·복구

Firebase Hosting의 Preview Channel과 Firebase Emulator Suite에서 먼저 검증한다. Firebase Hosting은 SPA 호스팅, Cloud Run 연결, 미리보기 URL, GitHub 반복 배포와 되돌리기를 제공한다.[3] 검증을 통과하면 새 도메인 또는 임시 Firebase 도메인을 운영으로 지정한다. 기존 Manus 사이트는 즉시 삭제하지 않고 **읽기 전용 비상 복구본**으로 30일 유지한다.

전환일에는 새 작업 생성과 AI 생성만 새 대시보드에서 허용한다. 문제가 생기면 새 DB를 삭제하지 않고, 운영 주소를 기존 Manus 대시보드로 되돌린 뒤 Cloud Run 로그·Firestore 이력으로 원인을 분석한다. 이미 생성된 새 데이터는 백업 JSON과 Firestore export로 보존한다.

## 6. 기능별 동등성 검증표

| 기능군 | 필수 검증 시나리오 | 통과 기준 |
|---|---|---|
| 기획안 | Markdown 첨부 후 제목·인물표·하위 작업 연결 | 현재 작품명이 정상 변경되고 원본이 보존 |
| 대본 | 21청크 가져오기·편집·버전 비교·통합 Markdown | 기존 파일과 해시 또는 승인 차이만 존재 |
| 상태 장부 | JSON 업로드·폼 수정·청크 간 검수 | 연령·관계·대가 오류 위치가 기존과 동일 |
| 정본 컴파일 | Python `check-all` | 오류 0건, 경고는 사전 승인 목록과 일치 |
| 제작 대시보드 | 승인·무효화·전환 표시 | 대본 변경 시 캐릭터 이후 단계가 같은 규칙으로 무효화 |
| 프롬프트 | 청크별 생성·길이 보정·이력 복구 | 장면 ID·청크 경계·외형 앵커가 유지 |
| 충돌 제어 | 필터·수정안·일괄 수정·복구 | 이력과 복구 전후 앵커가 정확히 일치 |
| 이미지 | 주요 인물 1명, 장면 2개 생성 | 성인 외형 가드, Storage 저장, 미리보기, 실패 재시도 동작 |
| Flow 패키지 | 단일·다중 청크 TXT/JSON/CSV/ZIP | 기존 파일명·장면 수·문장 ID가 일치 |
| 권한 | 비로그인·비소유자·소유자 요청 | 읽기/쓰기/생성 권한이 의도대로 차단 또는 허용 |
| 성능·복구 | 새 브라우저·새 기기·오프라인 재접속 | Firestore 동기화와 로컬 임시 캐시 복원 확인 |

## 7. 권장 실행 일정

| 구간 | 핵심 결과 | 완료 판정 |
|---|---|---|
| 1일차 | GitHub 기준점, 전 기기 작업실 백업, 자산 목록 | 소스·정본·백업 파일을 독립 보관 |
| 2~3일차 | 안티그래비티 개발 환경, Firebase/GCP 프로젝트, Hosting·Cloud Run 스테이징 | 빈 대시보드와 인증 가능한 API 연결 |
| 4~5일차 | 플랫폼 어댑터, Firestore/Storage, 백업 가져오기 | 칠성탈명록 21청크와 장부 복원 |
| 6~7일차 | Gemini 텍스트·이미지 어댑터, 프롬프트/이미지 회귀 테스트 | AI 기능을 Manus 없이 수행 |
| 8일차 | Flow 패키지, 충돌 제어, 권한·보안 규칙 | 기능 동등성 표 전수 통과 |
| 9일차 | Preview 검수, 운영 전환, 복구 리허설 | 새 도메인 운영 시작 |
| 전환 뒤 30일 | 로그 관찰, 수정, Manus 읽기 전용 보존 | 새 환경만으로 운영 가능 확인 |

일정은 개발일 기준이며, Firebase·Google Cloud 프로젝트 생성 및 API 결제 계정 설정 시간이 별도로 필요할 수 있다. 기능 축소 없이 완전 이전하려면 이미지 생성과 사용자 데이터 이전을 먼저 안정화하는 것이 핵심이다.

## 8. 사용자 준비 사항

| 준비물 | 필요한 이유 | 준비 시점 |
|---|---|---|
| GitHub 계정 및 비공개 저장소 권한 | 소스 정본·배포 이력·안티그래비티 작업 기준점 | 0단계 |
| 안티그래비티 설치 PC | 로컬 개발·에이전트 작업·테스트 | 1단계 |
| Firebase 프로젝트 | Authentication·Firestore·Storage·Hosting | 1단계 |
| Google Cloud 결제 계정 및 Cloud Run 권한 | 서버 API·AI 호출·이미지 생성 운영 | 1단계 |
| Gemini/Vertex AI 사용 권한 | 대시보드 내부의 한 번 클릭 재작성·점수·고밀도 프롬프트·이미지 자동 생성 | 선택형 4단계 |
| 각 기기의 작업실 백업 JSON | 브라우저에 남아 있는 수정본·버전·장부 보존 | 0단계 |
| 새 도메인 여부 | 운영 주소 확정 | 6단계 전 |

API 키, 서비스 계정 JSON, 백업 원고는 GitHub에 올리지 않는다. 안티그래비티의 로컬 비밀 저장소와 Firebase/Google Cloud Secret Manager를 사용하고, 서버 환경 변수로만 주입한다.

## 9. 이번 단계의 의사결정

이관 구현 전 아래 항목만 확정하면 바로 0단계와 1단계로 진행할 수 있다.

1. 운영 기반은 **Firebase Hosting + Cloud Run + Firestore + Cloud Storage**로 한다.
2. 대본 작성·수정·문체 검수의 기본 주체는 **Google AI Ultra의 안티그래비티**로 한다. 안티그래비티는 정본과 상태 장부를 읽고 청크 Markdown을 수정한 뒤 컴파일러를 실행한다.
3. 대시보드 내부의 Gemini 재작성·점수·고밀도 프롬프트 버튼은 **선택형 API 기능**으로 분리한다. 필요한 시점에만 Gemini API 키·비용 상한·Cloud Run 어댑터를 설정한다.
4. 인물·장면 이미지는 **Google 이미지 생성 모델 어댑터**로 이전하되, 실제 기본 모델은 성인 외형 가드 테스트 후 확정한다.
5. Google Flow Ultra는 브라우저 자동화 대상에서 제외하고, 기존처럼 **Flow ZIP 출력 및 생성 결과 재연결** 방식으로 유지한다.
6. 현재 Manus 버전은 전환 후 최소 30일 동안 읽기 전용 복구 기준점으로 남긴다.

## References

[1]: https://antigravity.google/docs/overview "Google Antigravity 2.0 Overview"
[2]: https://antigravity.google/docs/firebase-studio-migration "Firebase Studio Migration | Google Antigravity Docs"
[3]: https://firebase.google.com/docs/hosting "Firebase Hosting"
[4]: https://ai.google.dev/gemini-api/docs/structured-output "Structured outputs | Gemini API"
[5]: https://ai.google.dev/gemini-api/docs/imagen "Generate images using Imagen | Gemini API"
[6]: https://ai.google.dev/gemini-api/docs/google-ai-plans "Google AI plans | Gemini API"
[7]: https://support.google.com/googleone/answer/16286513?hl=en "Use Google AI Ultra benefits"
[8]: https://help.openai.com/en/articles/9039756-managing-billing-settings-on-chatgpt-web-and-platform "Managing Billing Settings on ChatGPT Web and Platform"
[9]: https://support.claude.com/en/articles/8325606-what-is-the-pro-plan "What is the Pro plan?"
