# 무협스튜디오 Firebase·Google Cloud 설정 가이드

작성일: 2026-08-21  
대상: 안티그래비티로 이전할 무협스튜디오의 개발·스테이징·운영 환경

## 1. 이 가이드의 범위

이 문서는 현재 Manus WebDev에서 동작하는 무협스튜디오를 **Firebase Hosting + Cloud Run + Firestore + Cloud Storage + Firebase Authentication**으로 옮기기 위한 설정 절차다. 안티그래비티는 개발·테스트·GitHub 작업을 수행하는 로컬 에이전트 환경이며, 운영 서비스는 Firebase와 Google Cloud에 배포한다.[1]

현재 소스에는 Manus OAuth, Forge LLM, Forge ImageService, `/manus-storage` 참조가 남아 있다. 따라서 이 가이드의 인프라 생성은 먼저 해도 되지만, **기존 소스를 곧바로 Cloud Run에 배포하지 않는다.** 플랫폼 어댑터와 Firebase/GCP 서비스 연동이 완료된 브랜치만 배포한다.

> Firestore 위치와 기본 Storage 위치는 생성 뒤 변경하기 어렵다. 서울 사용 기준으로는 `asia-northeast3`를 우선 검토하되, Firebase Console에서 실제 선택 가능 위치를 확인한 뒤 확정한다. 2024년 9월 이후 새 기본 Storage 버킷은 Firestore 기본 인스턴스와 위치가 독립적이므로, 두 위치를 각각 확인해야 한다.[6]

## 2. 사전 준비

| 항목 | 권장 기준 | 확인 명령 |
|---|---|---|
| Node.js | 22 LTS 또는 최신 LTS | `node --version` |
| pnpm | 프로젝트 `packageManager`와 동일 계열 | `pnpm --version` |
| Python | 3.10 이상 | `python --version` 또는 Windows `py --version` |
| Firebase CLI | 최신 버전 | `firebase --version` |
| Google Cloud CLI | 최신 버전 | `gcloud version` |
| GitHub CLI | 비공개 저장소 접근 가능한 계정 | `gh auth status` |

Firebase CLI는 Node.js 18 이상을 요구하며, `npm install -g firebase-tools`로 설치할 수 있다.[2]

```powershell
# Windows PowerShell
npm install -g firebase-tools
winget install Google.CloudSDK

firebase login
gcloud auth login
gcloud auth application-default login

firebase projects:list
gcloud projects list
```

`gcloud auth application-default login`은 로컬 Firestore 이관 스크립트와 테스트가 서비스 계정 JSON 파일 없이 Application Default Credentials를 사용하도록 한다. Cloud Run 내부에서는 기본 서비스 계정 또는 지정 서비스 계정의 ADC를 사용한다.[3]

## 3. Firebase와 Google Cloud 프로젝트 생성

프로젝트 ID는 생성 뒤 바꿀 수 없으므로 영문 소문자, 숫자, 하이픈만 사용한다. 개발과 운영을 분리하기 위해 아래 두 프로젝트를 권장한다.

| 환경 | 예시 프로젝트 ID | 사용 목적 |
|---|---|---|
| 스테이징 | `muhyeop-studio-stg` | 백업 이관·에뮬레이터·미리보기·AI 호출 검증 |
| 운영 | `muhyeop-studio-prod` | 실제 원고·이미지·제작 워크플로우 |

```powershell
$PROJECT_ID = "muhyeop-studio-stg"       # 운영은 muhyeop-studio-prod
$REGION = "asia-northeast3"

gcloud projects create $PROJECT_ID --name="무협스튜디오 스테이징"
gcloud config set project $PROJECT_ID
gcloud billing accounts list

# <BILLING_ACCOUNT_ID>를 실제 값으로 바꾼다.
gcloud billing projects link $PROJECT_ID --billing-account=<BILLING_ACCOUNT_ID>

gcloud services enable `
  run.googleapis.com `
  cloudbuild.googleapis.com `
  artifactregistry.googleapis.com `
  secretmanager.googleapis.com `
  firestore.googleapis.com `
  storage.googleapis.com `
  aiplatform.googleapis.com `
  iamcredentials.googleapis.com
```

Cloud Run은 사용량 기반이며, 사용 전 Cloud Billing 계정 연결과 Cloud Run API 활성화가 필요하다.[4] Firebase Console에서 **프로젝트 추가**를 선택하고, 방금 만든 Cloud 프로젝트를 선택해 Firebase를 연결한다. CLI만으로 Firebase 제품을 전부 구성하려 하지 말고, Authentication 공급자·Firestore 위치·기본 Storage 버킷처럼 콘솔 확인이 필요한 항목은 아래 순서대로 설정한다.[3]

## 4. Firebase Console에서 한 번만 설정할 항목

### 4-1. Firestore

Firebase Console의 **Databases & Storage → Firestore → 데이터베이스 만들기**를 연다. 시작 규칙은 **Production mode**를 선택한다. 이 모드는 웹·모바일 클라이언트 읽기와 쓰기를 기본 차단하지만, 서버의 인증된 Admin SDK는 접근할 수 있다.[5]

### 4-2. Cloud Storage

Firebase Console의 **Databases & Storage → Storage**에서 기본 버킷을 만든다. 인물 이미지, 장면 이미지, 기획안 원본, 가져온 백업, 생성한 Flow 패키지를 저장한다. 버킷 위치는 Firestore와 같은 권역을 우선하고, 세부 자산 저장 규칙은 서버 연동 단계에서 적용한다.

### 4-3. Firebase Authentication

Firebase Console의 **Authentication → Sign-in method**에서 Google 로그인을 활성화한다. 첫 운영은 YOO의 Google 계정만 허용하도록 Cloud Run API의 서버 검증과 Firestore/Storage Rules를 함께 적용한다. 클라이언트 UI에서 숨기는 것만으로는 권한 통제가 되지 않는다.

### 4-4. 웹 앱 등록

Firebase Console의 **Project settings → Your apps → Web**에서 앱을 등록한다. 콘솔이 제공하는 `firebaseConfig`는 공개 식별 설정이지만, 서비스 계정 키·Gemini 키·서버 비밀값은 절대 프런트엔드 코드에 두지 않는다.

## 5. 로컬 저장소 초기화

비공개 GitHub 저장소를 안티그래비티 또는 로컬 PC에 복제한 뒤, Firebase CLI를 연결한다. CLI의 `firebase init`은 프로젝트 루트에 `firebase.json`과 `.firebaserc`를 만들며, 스테이징·운영 별칭을 관리할 수 있다.[2]

```powershell
git clone https://github.com/<GITHUB_OWNER>/muhyeop-script-studio.git
cd muhyeop-script-studio
pnpm install

firebase init
# 선택: Firestore, Storage, Hosting, Emulators
# Hosting public directory: dist
# Single-page app rewrite: Yes
# 자동 GitHub 배포: 초기에는 No. CI를 확정한 뒤 추가한다.

firebase use --add
# muhyeop-studio-stg -> stg
firebase use --add
# muhyeop-studio-prod -> prod
```

권장 `firebase.json` 구조는 아래와 같다. API 서비스 이름과 지역은 Cloud Run 배포 완료 뒤 실제 값으로 바꾼다.

```json
{
  "$schema": "https://raw.githubusercontent.com/firebase/firebase-tools/master/schema/firebase-config.json",
  "hosting": {
    "public": "dist",
    "ignore": ["firebase.json", "**/.*", "**/node_modules/**"],
    "rewrites": [
      {
        "source": "/api/**",
        "run": {
          "serviceId": "muhyeop-api",
          "region": "asia-northeast3",
          "pinTag": true
        }
      },
      { "source": "**", "destination": "/index.html" }
    ]
  },
  "firestore": { "rules": "firestore.rules", "indexes": "firestore.indexes.json" },
  "storage": { "rules": "storage.rules" },
  "emulators": {
    "auth": { "port": 9099 },
    "firestore": { "port": 8080 },
    "storage": { "port": 9199 },
    "hosting": { "port": 5000 },
    "ui": { "enabled": true, "port": 4000 },
    "singleProjectMode": true
  }
}
```

Firebase Hosting은 정적 SPA를 제공하고, `/api/**` 같은 요청을 Cloud Run 서비스로 rewrite할 수 있다.[4] `pinTag: true`는 Hosting 버전과 Cloud Run revision을 함께 맞춰 배포·롤백하기에 유리하다.[4]

## 6. 최소 보안 규칙 초안

첫 배포 전까지는 클라이언트가 Firestore와 Storage에 직접 쓰지 않게 한다. 모든 쓰기와 AI 호출을 Cloud Run API로 보내고, 서버가 Firebase ID 토큰을 검증한다. 아래는 UI가 Firestore를 직접 읽을 필요가 없을 때의 잠금 초안이다.

```text
// firestore.rules
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if false;
    }
  }
}
```

```text
// storage.rules
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /{allPaths=**} {
      allow read, write: if false;
    }
  }
}
```

이후 서버 토큰 검증과 프로젝트 멤버십 문서를 구현한 다음, 읽기 전용 UI에 필요한 범위만 규칙을 넓힌다. 개발 중 Test mode를 운영에 남겨두지 않는다.[5]

## 7. Firestore 백업 이관 스크립트 실행

### 7-1. 백업 생성

현재 Manus 대시보드에서 **작업실 백업**을 눌러 `칠성탈명록_작업실_백업.json`을 다운로드한다. 수정본이 여러 기기에 나뉘어 있으면 각 기기에서 백업하고, 덮어쓰지 않도록 파일명에 기기와 날짜를 붙인다.

### 7-2. 스크립트 설치와 드라이런

```powershell
cd muhyeop-script-studio
py -m pip install -r scripts/requirements-migration.txt

# 사전 변환. Firestore에는 쓰지 않는다.
py scripts/migrate_workspace_backup_to_firestore.py `
  --backup "C:\Users\YOO\Downloads\칠성탈명록_작업실_백업.json" `
  --project-id "chilseong-script-001" `
  --plan-out "migration-output\chilseong-script-001-plan.json"

# 변환 로직 단위 테스트
py scripts/test_workspace_backup_migration.py
```

드라이런 출력에서 `Firestore documents`, 21청크·상태 장부 경고, 프로젝트 ID를 확인한다. `migration-output/`과 사용자 백업은 `.gitignore`에 포함되어 있어 GitHub에 올라가지 않는다.

### 7-3. 실제 업로드

```powershell
# 현재 gcloud 계정의 ADC로 업로드한다.
gcloud config set project muhyeop-studio-stg
gcloud auth application-default login

py scripts/migrate_workspace_backup_to_firestore.py `
  --backup "C:\Users\YOO\Downloads\칠성탈명록_작업실_백업.json" `
  --project-id "chilseong-script-001" `
  --plan-out "migration-output\chilseong-script-001-plan.json" `
  --apply
```

스크립트는 기본적으로 이미 존재하는 `projects/{projectId}` 문서를 덮어쓰지 않는다. 다른 대상 ID를 사용하는 것이 가장 안전하다. 정말 덮어써야 할 때만 백업을 다시 만든 뒤 `--allow-overwrite --apply`를 함께 사용한다.

| Firestore 경로 | 내용 |
|---|---|
| `projects/{projectId}` | 제목, 원본 백업 해시, 이관 시각, 문서 수 |
| `briefs/current` | 기획안 Markdown과 파일 메타데이터 |
| `chunks/{01..21}` | 원본과 현재 수정본, 현재 해시 |
| `chunkVersions/*` | 원본·수정본·기존 스냅샷의 불변 이력 |
| `stateLedgers/{01..21}` | 연령·관계·소지품·종료 상태 |
| `workflow/current` | 확장 백업에 포함한 제작 워크플로우 |
| `settings/styleProfile` | 사용자 문체 프로필 |
| `migrationEvents/legacy-import` | 변환 경고와 원본 백업 해시 |

현재 기본 작업실 백업 v1은 제작 워크플로우 데이터가 없을 수 있다. 이 경우 대본·기획안·장부·버전은 안전하게 옮기고, 인물 이미지·장면 프롬프트·승인 상태는 별도 확장 백업 또는 새 대시보드의 JSON 내보내기에서 추가 이관한다.

## 8. Cloud Run 서비스 계정과 배포 준비

Cloud Run 서비스가 Firestore, Storage, Secret Manager, Vertex AI에 접근하도록 전용 서비스 계정을 만든다. 운영에서는 소유자 권한을 주지 않고 필요한 최소 역할만 부여한다.

```powershell
$PROJECT_ID = "muhyeop-studio-stg"
$REGION = "asia-northeast3"
$SERVICE_ACCOUNT = "muhyeop-api"

gcloud iam service-accounts create $SERVICE_ACCOUNT --display-name="무협스튜디오 API"
$SA_EMAIL = "$SERVICE_ACCOUNT@$PROJECT_ID.iam.gserviceaccount.com"

gcloud projects add-iam-policy-binding $PROJECT_ID --member="serviceAccount:$SA_EMAIL" --role="roles/datastore.user"
gcloud projects add-iam-policy-binding $PROJECT_ID --member="serviceAccount:$SA_EMAIL" --role="roles/aiplatform.user"
gcloud projects add-iam-policy-binding $PROJECT_ID --member="serviceAccount:$SA_EMAIL" --role="roles/secretmanager.secretAccessor"

# 새 Firebase 기본 Storage 버킷은 PROJECT_ID.firebasestorage.app 형식이다.
# 콘솔의 Storage Files 탭에서 실제 버킷명을 반드시 확인한다.
$BUCKET = "$PROJECT_ID.firebasestorage.app"
gcloud storage buckets add-iam-policy-binding "gs://$BUCKET" `
  --member="serviceAccount:$SA_EMAIL" `
  --role="roles/storage.objectAdmin"
```

비밀값은 Secret Manager에 둔다. Gemini 키나 외부 서비스 키를 코드, `.env`, GitHub Actions 로그, Firestore 문서에 저장하지 않는다.

```powershell
# 실제 비밀값을 화면에 출력하지 않도록 PowerShell 프롬프트에서 입력한다.
$GEMINI_KEY = Read-Host "Gemini API key"
$GEMINI_KEY | gcloud secrets create GEMINI_API_KEY --data-file=-

# 기존 Secret을 갱신할 때
$GEMINI_KEY | gcloud secrets versions add GEMINI_API_KEY --data-file=-
```

서비스 코드에서 Manus 전용 어댑터를 Firebase/GCP 어댑터로 교체한 뒤에만 배포한다. Cloud Run은 `PORT` 환경 변수로 수신 포트를 제공하므로 서버에서 포트를 고정하지 않는다.[4]

```powershell
pnpm test
pnpm build

gcloud run deploy muhyeop-api `
  --source . `
  --region $REGION `
  --service-account $SA_EMAIL `
  --allow-unauthenticated `
  --set-secrets "GEMINI_API_KEY=GEMINI_API_KEY:latest" `
  --set-env-vars "NODE_ENV=production"

firebase use stg
firebase deploy --only firestore:rules,storage,hosting
```

Firebase Hosting에서 Cloud Run으로 라우팅되는 요청은 60초 시간 제한이 있으므로, 장면 이미지 다중 생성이나 긴 AI 작업은 한 요청에 몰아넣지 않는다. 현재처럼 청크·장면 단위 순차 처리와 재시도 UI를 유지한다.[4]

## 9. 검증과 운영 전환 명령

```powershell
# 로컬 정적 UI·Firestore·Auth·Storage 규칙 확인
firebase emulators:start --only auth,firestore,storage,hosting

# Firebase Hosting Preview Channel
firebase hosting:channel:deploy migration-preview --expires 7d

# 스테이징에서만 실제 백업 업로드와 21청크 검수를 통과한 뒤 운영으로 전환
firebase use prod
firebase deploy --only firestore:rules,storage,hosting
```

운영 전환 전에는 다음을 모두 통과해야 한다.

1. Firestore에서 21청크, 상태 장부, 기획안, 수정 이력이 원본 해시와 일치한다.
2. Python 컴파일러 `check-all`과 브라우저 연속성 검수의 오류가 0건이다.
3. 비로그인·비소유자 API 요청이 거부되고, 소유자만 AI 생성과 수정이 가능하다.
4. Flow TXT·JSON·CSV·ZIP이 기존 장면 ID와 청크 경계를 보존한다.
5. Manus는 30일 동안 읽기 전용 복구 기준점으로 남긴다.

## References

[1]: https://antigravity.google/docs/overview "Google Antigravity 2.0 Overview"
[2]: https://firebase.google.com/docs/cli "Firebase CLI reference"
[3]: https://firebase.google.com/docs/admin/setup "Add the Firebase Admin SDK to your server"
[4]: https://firebase.google.com/docs/hosting/cloud-run "Serve dynamic content and host microservices with Cloud Run"
[5]: https://firebase.google.com/docs/firestore/quickstart "Get started with Firestore Standard edition"
[6]: https://firebase.google.com/docs/storage/faqs-storage-changes-announced-sept-2024 "Default bucket and billing requirements for Cloud Storage for Firebase after September 2024"
