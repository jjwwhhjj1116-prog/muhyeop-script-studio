/**
 * 강물의 장부 디자인: 이 규칙 엔진은 화면 장식이 아니라 정본 계약을
 * 청크별 대본에 대조하는 읽기 전용 장부다. 자동 판정과 수동 검토 대상을 분리한다.
 */

export type Severity = "error" | "warning";

export type ValidationIssue = {
  level: Severity;
  code: string;
  chunk?: number;
  message: string;
  detail?: string;
};

export type ValidationReport = {
  errors: ValidationIssue[];
  warnings: ValidationIssue[];
  checkedChunks: number;
  missingChunks: number[];
  characterCount: number;
  passed: boolean;
};

export type ImportedDrafts = Record<number, { content: string }>;

const chunks = Array.from({ length: 21 }, (_, index) => index + 1);
const allowedSpeakers = new Set(["강무진", "단여령", "복아", "백야", "위천록", "노철산", "설란", "허담"]);
const allowedEmotions = new Set(["내추럴", "화남", "슬픔", "기쁨", "행복", "놀람", "FIRM"]);
const fixedDialogues = [
  { id: "Hook 첫 대사", chunk: 1, text: '[복아|놀람]"아저씨, 나 아직 스무 살이야."' },
  { id: "Hook 마지막 대사", chunk: 1, text: '[허담|내추럴]"별이 내린 땅의 세월은 관천원의 것이다. 남은 것까지 거두어라."' },
  { id: "Intro 첫 대사", chunk: 1, text: '[강무진|FIRM]"내 배에 오른 사람은, 무슨 일이 있어도 건너편에 내려준다."' },
  { id: "Intro 마지막 대사", chunk: 3, text: '[단여령|내추럴]"복아의 쉰 해를 되찾으려면, 관천원의 하늘부터 부숴야 해요."' },
  { id: "백야 관계 대사", chunk: 4, text: '[백야|내추럴]"왜 나까지 건졌지?"' },
  { id: "강무진 관계 대사", chunk: 4, text: '[강무진|내추럴]"네가 내 배에 올랐으니까."' },
  { id: "위천록 핵심 논리", chunk: 11, text: '[위천록|내추럴]"사람들은 제 시간을 버리면서도, 내가 가져가면 억울해하지."' },
  { id: "강무진 반박", chunk: 20, text: '[강무진|FIRM]"강은 건널 사람을 고르지 않는다. 사람 목숨에 값을 매기는 놈은 사공이 아니라 장사꾼이지."' },
  { id: "위천록 최종 대사", chunk: 20, text: '[위천록|화남]"어째서 네 세월은 아깝지 않으냐!"' },
  { id: "강무진 최종 대사", chunk: 20, text: '[강무진|FIRM]"아깝다. 그러니 아무한테나 주지 않았다."' },
  { id: "End 마지막 대사", chunk: 21, text: '[강무진|FIRM]"강은 다시 흐른다. 건널 사람부터 타라."' },
];

const requiredTerms: Record<number, string[]> = {
  1: ["[CTA]", "별이 내린 땅의 세월은 관천원의 것이다", "내 배에 오른 사람은"],
  2: ["단여령", "요광"],
  3: ["관천원의 하늘부터 부숴야 해요", "## Body"],
  4: ["왜 나까지 건졌지", "네가 내 배에 올랐으니까"],
  5: ["요광개로", "천선", "서른넷"],
  6: ["야류강", "침수성"],
  7: ["이름", "천권"],
  8: ["노철산", "용골수문"],
  9: ["천기", "백야"],
  10: ["백세연", "밀고"],
  11: ["옥형", "요광개로", "마흔넷"],
  12: ["하늘 균열", "천 년"],
  13: ["사천", "단여령"],
  14: ["천수고", "지하"],
  15: ["개양", "요광개로", "쉰넷"],
  16: ["백만 년", "원래 주인"],
  17: ["설란", "자발적"],
  18: ["노철산", "죽"],
  19: ["천추", "하늘 균열"],
  20: ["칠성도강", "일흔넷", "위천록"],
  21: ["[END]", "스무 살", "강은 다시 흐른다"],
};

const targetCharacters: Record<number, number> = { 1: 3000, 2: 3050, 3: 3050, 4: 3000, 5: 3100, 6: 3000, 7: 3000, 8: 3000, 9: 3100, 10: 3000, 11: 3200, 12: 3000, 13: 3000, 14: 3000, 15: 3200, 16: 3000, 17: 3000, 18: 3100, 19: 3200, 20: 3300, 21: 3000 };
const headingByChunk: Record<number, string[]> = { 1: ["## Hook", "## Intro"], 3: ["## Body"], 20: ["## Climax"], 21: ["## End"] };
const markerByChunk: Record<number, string[]> = { 1: ["[CTA]"], 21: ["[END]"] };
const allHeadings = ["## Hook", "## Intro", "## Body", "## Climax", "## End"];
const allMarkers = ["[CTA]", "[END]"];
const bannedPhrases = ["짚음", "짚었다", "짚어왔다", "짚어냈다", "짚이는", "한 자락", "한 호흡", "한 결", "한 박자", "자리 잡고 있었다", "박혀 있었다", "머물러 있었다", "감정이 어렸다", "의미가 실려 있었다", "감정이 담겨 있었다", "굳혔다", "굳어졌다", "시선이 닿았다"];
const limitedPhrases: Record<string, number> = { "자리": 5, "한 갈래": 3, "한 줄기": 3, "한 가닥": 3, "한 줌": 2, "박동": 4, "결": 2, "응시": 2, "옅게": 3, "옅은": 3, "깊이": 4, "깊게": 4, "무겁게": 2, "짙게": 2, "천천히": 3, "가만히": 3, "조용히": 2, "단호히": 2, "차갑게": 2, "응축": 3, "묵은": 3, "묵직한": 3, "솟구쳤다": 4, "흩어졌다": 4, "흩날렸다": 4, "가라앉았다": 2, "가라앉히며": 2, "자리였다": 2, "순간이었다": 2 };
const recapPhrases = ["지난 이야기", "앞서", "그동안", "다시 말해"];
const falseCliffPhrases = ["그때였다", "바로 그 순간", "등 뒤에서 목소리가 들렸다"];
const abilityWindows: Record<string, number[]> = { "요광개로": [5, 11, 15], "칠성도강": [20] };

function lines(text: string) {
  return text.replace(/\r\n/g, "\n").split("\n").map((line) => line.trim()).filter(Boolean);
}

function count(text: string, phrase: string) {
  return text.split(phrase).length - 1;
}

function visibleCharacterCount(text: string) {
  return text.replace(/^\[청크\s*\d{1,2}\/21\]\s*$/gim, "").replace(/\s+/g, "").length;
}

function add(issues: ValidationIssue[], level: Severity, code: string, message: string, chunk?: number, detail?: string) {
  issues.push({ level, code, message, chunk, detail });
}

export function validateChilseongDrafts(importedChunks: ImportedDrafts, editedChunks: Record<number, string>, baseChunkOne: string): ValidationReport {
  const errors: ValidationIssue[] = [];
  const warnings: ValidationIssue[] = [];
  const available = (chunk: number) => editedChunks[chunk] ?? (chunk === 1 ? baseChunkOne : importedChunks[chunk]?.content ?? "");
  const loadedChunks = chunks.filter((chunk) => Boolean(available(chunk)));
  const missingChunks = chunks.filter((chunk) => !available(chunk));
  const allIssues: ValidationIssue[] = [];

  chunks.forEach((chunk) => {
    const text = available(chunk);
    if (!text) {
      add(allIssues, "error", "draft_missing", `청크 ${String(chunk).padStart(2, "0")} 원고가 없습니다.`, chunk);
      return;
    }
    const draftLines = lines(text);
    const expectedHeader = `[청크 ${String(chunk).padStart(2, "0")}/21]`;
    if (draftLines[0] !== expectedHeader) add(allIssues, "error", "header", `첫 내용 줄은 ${expectedHeader}이어야 합니다.`, chunk);

    allHeadings.forEach((heading) => {
      const actual = count(text, heading);
      const expected = headingByChunk[chunk]?.includes(heading) ? 1 : 0;
      if (actual !== expected) add(allIssues, "error", "structure_heading", `${heading}이 ${actual}개입니다. 이 청크의 허용 수는 ${expected}개입니다.`, chunk);
    });
    allMarkers.forEach((marker) => {
      const actual = count(text, marker);
      const expected = markerByChunk[chunk]?.includes(marker) ? 1 : 0;
      if (actual !== expected) add(allIssues, "error", "structure_marker", `${marker}이 ${actual}개입니다. 이 청크의 허용 수는 ${expected}개입니다.`, chunk);
    });

    if (chunk === 1 && draftLines.includes("[CTA]")) {
      const ctaIndex = draftLines.indexOf("[CTA]");
      const hookLast = fixedDialogues.find((item) => item.id === "Hook 마지막 대사")?.text;
      if (draftLines[ctaIndex - 1] !== hookLast) add(allIssues, "error", "cta_position", "[CTA] 바로 앞줄은 Hook 마지막 고정 대사여야 합니다.", chunk);
    }
    if (chunk === 21 && draftLines.includes("[END]")) {
      const endIndex = draftLines.indexOf("[END]");
      if (draftLines[endIndex + 1] !== "## End") add(allIssues, "error", "end_position", "[END] 다음 줄은 정확히 ## End여야 합니다.", chunk);
    }

    fixedDialogues.filter((item) => item.chunk === chunk).forEach((item) => {
      if (!text.includes(item.text)) add(allIssues, "error", "fixed_dialogue", `${item.id}가 없거나 원문과 다릅니다.`, chunk);
    });
    if (chunk === 21 && draftLines.at(-1) !== fixedDialogues.find((item) => item.id === "End 마지막 대사")?.text) add(allIssues, "error", "end_last_line", "청크 21의 마지막 내용 줄은 강무진의 최종 고정 대사여야 합니다.", chunk);

    text.split("\n").forEach((line, index) => {
      if (!/^\s*\[[^\]\n]*\|[^\]\n]*\]/.test(line)) return;
      const match = line.match(/^\s*\[([^|\]\n]+)\|([^\]\n]+)\]"([^"\n]*)"\s*$/);
      if (!match) {
        add(allIssues, "error", "dialogue_format", `${index + 1}행의 대사 태그 형식이 틀렸습니다.`, chunk);
        return;
      }
      const [, speaker, emotion, spoken] = match;
      if (!allowedSpeakers.has(speaker)) add(allIssues, "error", "unknown_speaker", `${index + 1}행의 화자 ${speaker}은 정본 고정명이 아닙니다.`, chunk);
      if (!allowedEmotions.has(emotion)) add(allIssues, "error", "unknown_emotion", `${index + 1}행의 감정 ${emotion}은 허용값이 아닙니다.`, chunk);
      if (emotion === "FIRM" && speaker !== "강무진") add(allIssues, "error", "firm_misuse", `${index + 1}행의 FIRM은 강무진만 사용할 수 있습니다.`, chunk);
      if (!spoken.trim()) add(allIssues, "error", "empty_dialogue", `${index + 1}행의 직접 대사가 비어 있습니다.`, chunk);
    });

    Object.entries(abilityWindows).forEach(([ability, allowed]) => {
      const mentions = count(text, ability);
      if (mentions && !allowed.includes(chunk)) add(allIssues, "error", "ability_out_of_window", `${ability}은 청크 ${allowed.map((value) => String(value).padStart(2, "0")).join(", ")}에서만 사용할 수 있습니다.`, chunk);
      if (mentions > 2) add(allIssues, "warning", "ability_repeat", `${ability}이 ${mentions}회 언급되었습니다. 결정적 사용인지 직접 확인하세요.`, chunk);
    });

    const actualLength = visibleCharacterCount(text);
    const target = targetCharacters[chunk];
    if (actualLength < target - 200 || actualLength > target + 200) add(allIssues, "warning", "chunk_length", `공백 제외 ${actualLength.toLocaleString()}자입니다. 목표 ${target.toLocaleString()}자의 허용 범위는 ${(target - 200).toLocaleString()}~${(target + 200).toLocaleString()}자입니다.`, chunk);
    requiredTerms[chunk].forEach((term) => {
      if (!text.includes(term)) add(allIssues, "warning", "target_state_evidence", `청크 종료 상태 증거어 '${term}'이 없습니다.`, chunk);
    });
    bannedPhrases.forEach((phrase) => {
      const hits = count(text, phrase);
      if (hits) add(allIssues, "warning", "banned_lexicon", `금지 후보 '${phrase}'이 ${hits}회 발견되었습니다. 맥락을 확인하세요.`, chunk);
    });
    recapPhrases.forEach((phrase) => {
      if (text.includes(phrase)) add(allIssues, "warning", "recap_phrase", `재요약 후보 표현 '${phrase}'이 발견되었습니다.`, chunk);
    });
    if (chunk < 21) {
      const tail = draftLines.slice(-5).join("\n");
      falseCliffPhrases.forEach((phrase) => {
        if (tail.includes(phrase)) add(allIssues, "warning", "false_cliff", `청크 말미에 가짜 클리프행어 후보 '${phrase}'이 있습니다.`, chunk);
      });
    }
  });

  if (!missingChunks.length) {
    const manuscript = chunks.map(available).join("\n");
    allMarkers.forEach((marker) => {
      const actual = count(manuscript, marker);
      if (actual !== 1) add(allIssues, "error", "global_marker", `전체 원고의 ${marker} 개수는 1개여야 하나 ${actual}개입니다.`);
    });
    allHeadings.forEach((heading) => {
      const actual = count(manuscript, heading);
      if (actual !== 1) add(allIssues, "error", "global_heading", `전체 원고의 ${heading} 개수는 1개여야 하나 ${actual}개입니다.`);
    });
    const totalCharacters = visibleCharacterCount(manuscript);
    if (totalCharacters < 63000 || totalCharacters > 68000) add(allIssues, "warning", "total_length", `전체 공백 제외 ${totalCharacters.toLocaleString()}자입니다. 권장 범위는 63,000~68,000자입니다.`);

    for (let start = 1; start <= 21; start += 3) {
      const group = chunks.slice(start - 1, start + 2).map(available).join("\n");
      Object.entries(limitedPhrases).forEach(([phrase, limit]) => {
        const hits = count(group, phrase);
        if (hits > limit) add(allIssues, "warning", "lexical_limit", `청크 ${start.toString().padStart(2, "0")}~${Math.min(start + 2, 21).toString().padStart(2, "0")}에서 '${phrase}'이 ${hits}회입니다. 상한 ${limit}회를 넘었습니다.`);
      });
    }
    for (let chunk = 2; chunk <= 21; chunk += 1) {
      const previous = lines(available(chunk - 1)).at(-1);
      const current = lines(available(chunk)).find((line) => !/^\[청크/.test(line));
      if (previous && current && previous === current) add(allIssues, "warning", "boundary_repeat", `청크 ${String(chunk - 1).padStart(2, "0")}의 마지막 줄과 청크 ${String(chunk).padStart(2, "0")}의 첫 줄이 같습니다.`, chunk);
    }
  }

  allIssues.forEach((issue) => (issue.level === "error" ? errors : warnings).push(issue));
  const fullText = loadedChunks.map(available).join("\n");
  return { errors, warnings, checkedChunks: loadedChunks.length, missingChunks, characterCount: visibleCharacterCount(fullText), passed: errors.length === 0 && missingChunks.length === 0, };
}
