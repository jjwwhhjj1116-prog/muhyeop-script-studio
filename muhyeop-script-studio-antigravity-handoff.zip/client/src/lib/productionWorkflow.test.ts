import { describe, expect, it } from "vitest";
import { strFromU8, unzipSync } from "fflate";
import { applyGeneratedChunkScenePrompts, approveStage, auditChunkAppearance, auditCommonAnchorConflicts, auditProduction, auditSceneAnchorConflicts, autoOptimizeChunkScenePrompts, batchUpdateCharacterAnchors, buildFinalScriptExport, buildFlowChunkExport, buildFlowChunkZipBundle, buildFlowMultiChunkZipBundle, buildScenePlan, buildVisualizationChunkExport, buildVisualizationExport, createProductionWorkflow, deriveScriptSentences, estimateChunkGeneration, invalidateDownstream, normalizeProductionWorkflow, optimizeImagePrompt, regenerateFlow, resolveCommonAnchorConflict, restoreCommonAnchorConflictResolution, restorePromptBeforeOptimization, reviewCharacterAppearance, suggestCommonAnchorConflictAnchors, updateCharacterAsset, updateSceneImage, updateScenePrompt, validateMetadata, zipFlowChunkBundle, zipFlowMultiChunkBundle } from "./productionWorkflow";

const chunks = {
  1: { content: '# 칠성탈명록\n## Hook\n[복아|놀람]"아저씨, 나 아직 스무 살이야."\n별이 떨어졌다. 강물이 솟구쳤다.\n[CTA]\n## Intro\n[강무진|FIRM]"건너편에 내려준다."' },
  2: { content: "강무진은 삿대를 들었다. 집행대가 나루를 막았다. 복아는 배 안으로 물러났다." },
};

describe("production workflow", () => {
  it("keeps every sentence and dialogue in a three-sentence scene plan", () => {
    const sentences = deriveScriptSentences(chunks, {});
    const workflow = buildScenePlan(createProductionWorkflow("테스트", "hash", sentences));
    const audit = auditProduction(workflow);
    expect(workflow.scenes.flatMap((scene) => scene.scriptSentenceIds)).toHaveLength(sentences.length);
    expect(workflow.scenes.flatMap((scene) => scene.dialogueIds)).toHaveLength(sentences.filter((sentence) => sentence.dialogue).length);
    expect(audit.issues.some((issue) => issue.code === "sentence_unmapped")).toBe(false);
    expect(workflow.scenes.every((scene) => scene.scriptSentenceIds.every((id) => id.startsWith(`c${String(scene.chunk).padStart(2, "0")}`)))).toBe(true);
  });

  it("invalidates exactly the required downstream stages", () => {
    const workflow = createProductionWorkflow("테스트", "hash", []);
    const next = invalidateDownstream(workflow, "script", "대본 수정");
    expect(next.stages.synopsis.status).toBe("APPROVED");
    expect(next.stages.characters.status).toBe("INVALIDATED");
    expect(next.stages.audit.status).toBe("INVALIDATED");
  });

  it("regenerates Flow only from the full visualization prompt list", () => {
    const sentences = deriveScriptSentences({ 1: chunks[1] }, {});
    let workflow = buildScenePlan(createProductionWorkflow("테스트", "hash", sentences));
    workflow = updateScenePrompt(workflow, 1, "Moonlit riverbank, a wooden ferry, cinematic medium shot");
    workflow = updateScenePrompt(workflow, 2, "Falling star above the river, wide shot, dark fantasy wuxia");
    workflow = regenerateFlow(workflow);
    expect(workflow.flowLines).toEqual([
      "Moonlit riverbank, a wooden ferry, cinematic medium shot",
      "Falling star above the river, wide shot, dark fantasy wuxia",
    ]);
  });

  it("requires all three title types and exact metadata counts before approval", () => {
    const workflow = createProductionWorkflow("테스트", "hash", []);
    expect(validateMetadata(workflow.metadata).some((issue) => issue.code === "timeline_count")).toBe(true);
    expect(validateMetadata({
      titles: [
        { type: "의문형", text: "별은 왜 강으로 떨어졌나?", scriptEvidence: "별 추락" },
        { type: "직설형", text: "수명을 세금으로 거둔 관천원", scriptEvidence: "수명세" },
        { type: "숫자·역전형", text: "50년을 빼앗긴 스무 살 약초꾼", scriptEvidence: "복아의 쉰 해" },
      ],
      timeline: ["00:00", "12:00", "24:00", "36:00", "48:00"],
      hashtags: Array.from({ length: 12 }, (_, index) => `#무협${index}`),
      signature: "🗡️ 무협스튜디오 — 강호는 멈추지 않는다.",
    })).toEqual([]);
  });

  it("hydrates an older saved workflow without metadata fields", () => {
    const current = createProductionWorkflow("테스트", "hash", []);
    const restored = normalizeProductionWorkflow({ ...current, metadata: undefined as never }, "테스트", "hash", []);
    expect(restored.metadata.titles).toHaveLength(3);
    expect(restored.metadata.signature).toBe("🗡️ 무협스튜디오 — 강호는 멈추지 않는다.");
  });

  it("exports final script chunks and visualization scenes with their sentence IDs", () => {
    const sentences = deriveScriptSentences(chunks, {});
    let workflow = buildScenePlan(createProductionWorkflow("테스트", "hash", sentences));
    workflow = updateScenePrompt(workflow, 1, "Moonlit riverbank, cinematic wuxia");
    const scriptExport = buildFinalScriptExport("테스트", "hash", chunks, { 1: "수정된 원고" });
    const visualizationExport = buildVisualizationExport(workflow);
    expect(scriptExport.chunks).toHaveLength(21);
    expect(scriptExport.chunks[0]).toMatchObject({ chunk: 1, content: "수정된 원고", edited: true });
    expect(visualizationExport.scenes[0].scriptSentenceIds).toEqual(workflow.scenes[0].scriptSentenceIds);
    expect(visualizationExport.scenes[0].flowPrompt).toBeNull();
  });

  it("stores a generated scene image and invalidates downstream production stages", () => {
    const workflow = buildScenePlan(createProductionWorkflow("테스트", "hash", deriveScriptSentences(chunks, {})));
    const next = updateSceneImage(workflow, 1, "https://example.com/scene-1.png");
    expect(next.scenes[0].imageUrl).toBe("https://example.com/scene-1.png");
    expect(next.stages.flow.status).toBe("INVALIDATED");
  });

  it("applies dense prompts only to one chunk and exports that chunk as a recoverable unit", () => {
    const workflow = buildScenePlan(createProductionWorkflow("테스트", "hash", deriveScriptSentences(chunks, {})));
    const chunkOneScenes = workflow.scenes.filter((scene) => scene.chunk === 1);
    const dense = "A moonlit river ferry at night, adult Korean ferryman Kang Mujin braces beside the wet wooden rail as a black-clad swordsman cuts through the mist, the pole hooks the rail and water ripples reveal the attack line, three-quarter low angle medium-wide framing, tense foreground splashes, lantern glow against ink-blue shadows, weathered wood texture, cinematic Korean wuxia dark fantasy, shallow depth of field, no text, no watermark, no logo, no subtitles, no modern objects, no collage, no duplicate people, no extra limbs.";
    const next = applyGeneratedChunkScenePrompts(workflow, 1, chunkOneScenes.map((scene) => ({ sceneNumber: scene.number, prompt: dense })), "gpt-5-mini");
    expect(next.scenes.filter((scene) => scene.chunk === 1).every((scene) => scene.promptSource === "generated")).toBe(true);
    expect(next.scenes.filter((scene) => scene.chunk === 2).every((scene) => !scene.enImagePrompt)).toBe(true);
    const exportChunk = buildVisualizationChunkExport(next, 1);
    expect(exportChunk.chunk).toBe(1);
    expect(exportChunk.scenes.every((scene) => scene.chunk === 1)).toBe(true);
    expect(() => applyGeneratedChunkScenePrompts(workflow, 1, chunkOneScenes.map((scene) => ({ sceneNumber: scene.number, prompt: "short, no text" })), "gpt-5-mini")).toThrow("고밀도 프롬프트 길이");
  });

  it("estimates per-chunk image work, audits appearance anchors, and exports approved Flow lines with source IDs", () => {
    let workflow = buildScenePlan(createProductionWorkflow("테스트", "hash", deriveScriptSentences(chunks, {})));
    const dense = "A moonlit river ferry at night, Kang Mujin, a lean ferryman with a scarred jaw and weathered navy hemp robe, braces beside the wet wooden rail as a black-clad swordsman cuts through the mist, the pole hooks the rail and water ripples reveal the attack line, three-quarter low angle medium-wide framing, tense foreground splashes, lantern glow against ink-blue shadows, weathered wood texture, cinematic Korean wuxia dark fantasy, shallow depth of field, no text, no watermark, no logo, no subtitles, no modern objects, no collage, no duplicate people, no extra limbs.";
    workflow = updateCharacterAsset(workflow, "강무진", { supportAnchor: "scarred jaw, weathered navy hemp robe" });
    const chunkOneScenes = workflow.scenes.filter((scene) => scene.chunk === 1);
    workflow = applyGeneratedChunkScenePrompts(workflow, 1, chunkOneScenes.map((scene) => ({ sceneNumber: scene.number, prompt: dense })), "gpt-5-mini");
    const estimate = estimateChunkGeneration(workflow, 1);
    expect(estimate).toMatchObject({ sceneCount: chunkOneScenes.length, densePromptRequestCount: 0, imageGenerationRequestCount: chunkOneScenes.length, imageModel: "GPT Image 2", imageQuality: "medium" });
    const appearance = auditChunkAppearance(workflow, 1);
    expect(appearance.checks.find((check) => check.name === "강무진")).toMatchObject({ status: "checked", score: 100, missingKeywords: [] });
    expect(() => buildFlowChunkExport(workflow, 1)).toThrow("시각화 승인 후");
    const approved = approveStage(workflow, "visualization");
    const flowExport = buildFlowChunkExport(approved, 1);
    expect(flowExport.lines).toHaveLength(chunkOneScenes.length);
    expect(flowExport.lines[0]).toMatchObject({ sceneNumber: chunkOneScenes[0].number, scriptSentenceIds: chunkOneScenes[0].scriptSentenceIds, prompt: dense });
  });

  it("automatically removes repeated prompt clauses, keeps the negative guard, and preserves other chunks", () => {
    const repeated = `${"Kang Mujin scarred jaw navy robe, ".repeat(75)}moonlit ferry on the river, cinematic medium-wide frame, no watermark, no logo`;
    const optimized = optimizeImagePrompt(repeated);
    expect(optimized.prompt.length).toBeLessThanOrEqual(1_600);
    expect(optimized.prompt).toContain("no text");
    expect(optimized.result.removedDuplicateClauses).toBeGreaterThan(0);
    let workflow = buildScenePlan(createProductionWorkflow("테스트", "hash", deriveScriptSentences(chunks, {})));
    workflow = updateScenePrompt(workflow, 1, repeated);
    const chunkTwoBefore = workflow.scenes.filter((scene) => scene.chunk === 2).map((scene) => scene.enImagePrompt);
    const result = autoOptimizeChunkScenePrompts(workflow, 1);
    expect(result.workflow.scenes.find((scene) => scene.number === 1)?.enImagePrompt.length).toBeLessThanOrEqual(1_600);
    expect(result.workflow.scenes.filter((scene) => scene.chunk === 2).map((scene) => scene.enImagePrompt)).toEqual(chunkTwoBefore);
    expect(result.workflow.stages.visualization.status).toBe("NEEDS_REVIEW");
  });

  it("records appearance review reset on image or anchor changes and builds a single Flow ZIP bundle", () => {
    let workflow = buildScenePlan(createProductionWorkflow("테스트", "hash", deriveScriptSentences(chunks, {})));
    const dense = "A moonlit river ferry at night, Kang Mujin, a lean ferryman with a scarred jaw and weathered navy hemp robe, braces beside the wet wooden rail, cinematic Korean wuxia, no text, no watermark, no logo, no subtitles, no modern objects, no collage, no duplicate people, no extra limbs.";
    const chunkOneScenes = workflow.scenes.filter((scene) => scene.chunk === 1);
    workflow = applyGeneratedChunkScenePrompts(workflow, 1, chunkOneScenes.map((scene) => ({ sceneNumber: scene.number, prompt: dense })), "gpt-5-mini");
    workflow = approveStage(workflow, "visualization");
    workflow = updateCharacterAsset(workflow, "강무진", { imageUrl: "https://example.com/kang.png", supportAnchor: "scarred jaw, weathered navy hemp robe", appearanceReviewStatus: "APPROVED", appearanceReviewedAt: "2026-08-20T00:00:00.000Z" });
    const kang = workflow.characters.find((character) => character.name === "강무진");
    expect(kang).toMatchObject({ appearanceReviewStatus: "NOT_REVIEWED", appearanceReviewedAt: null });
    workflow = reviewCharacterAppearance(workflow, "강무진", "APPROVED", "턱 흉터와 남색 삼베 도포를 이미지에서 확인했다.");
    expect(workflow.characters.find((character) => character.name === "강무진")).toMatchObject({ appearanceReviewStatus: "APPROVED", appearanceReviewNote: "턱 흉터와 남색 삼베 도포를 이미지에서 확인했다." });
    const approved = approveStage(workflow, "visualization");
    const bundle = buildFlowChunkZipBundle(approved, 1);
    expect(bundle.filename).toBe("테스트_청크_01_Flow_묶음.zip");
    expect(Object.keys(bundle.files)).toEqual(["테스트_청크_01_Flow.txt", "테스트_청크_01_Flow_장면_ID_매핑.json"]);
    expect(bundle.files["테스트_청크_01_Flow.txt"]).toContain("scarred jaw");
    const unpacked = unzipSync(zipFlowChunkBundle(bundle));
    expect(strFromU8(unpacked["테스트_청크_01_Flow.txt"])).toContain("scarred jaw");
    expect(strFromU8(unpacked["테스트_청크_01_Flow_장면_ID_매핑.json"])).toContain("scriptSentenceIds");
  });

  it("keeps prompt optimization history, restores the pre-optimization prompt, and isolates other chunks", () => {
    let workflow = buildScenePlan(createProductionWorkflow("테스트", "hash", deriveScriptSentences(chunks, {})));
    const repeated = `${"Kang Mujin scarred jaw navy robe, ".repeat(75)}moonlit ferry on the river, cinematic medium-wide frame, no watermark, no logo`;
    workflow = updateScenePrompt(workflow, 1, repeated);
    const untouchedChunkTwo = workflow.scenes.filter((scene) => scene.chunk === 2).map((scene) => scene.enImagePrompt);
    const optimized = autoOptimizeChunkScenePrompts(workflow, 1).workflow;
    const optimizedScene = optimized.scenes.find((scene) => scene.number === 1)!;
    expect(optimizedScene.promptOptimizationHistory).toHaveLength(1);
    expect(optimizedScene.promptOptimizationHistory[0].beforePrompt).toBe(repeated);
    const firstSnapshotId = optimizedScene.promptOptimizationHistory[0].id;
    const secondSource = `${"Moonlit river ferry and scarred jaw, ".repeat(75)}${optimizedScene.enImagePrompt}`;
    const secondOptimized = autoOptimizeChunkScenePrompts(updateScenePrompt(optimized, 1, secondSource), 1).workflow;
    expect(secondOptimized.scenes.find((scene) => scene.number === 1)?.promptOptimizationHistory).toHaveLength(2);
    const restored = restorePromptBeforeOptimization(secondOptimized, 1, firstSnapshotId);
    expect(restored.scenes.find((scene) => scene.number === 1)?.enImagePrompt).toBe(repeated);
    expect(restored.scenes.filter((scene) => scene.chunk === 2).map((scene) => scene.enImagePrompt)).toEqual(untouchedChunkTwo);
  });

  it("detects conflicting anchors in a shared scene and packages multiple approved chunks with CSV", () => {
    let workflow = buildScenePlan(createProductionWorkflow("테스트", "hash", deriveScriptSentences(chunks, {})));
    workflow.scenes[0].koText = "강무진과 복아가 젖은 나루에 함께 섰다.";
    workflow = updateCharacterAsset(workflow, "강무진", { supportAnchor: "male female, black hair white hair, navy robe, wooden pole" });
    workflow = updateCharacterAsset(workflow, "복아", { supportAnchor: "female, white hair, navy robe, wooden pole" });
    const conflicts = auditSceneAnchorConflicts(workflow, 1);
    expect(conflicts.conflicts.some((conflict) => conflict.kind === "self_contradiction" && conflict.characterNames.includes("강무진"))).toBe(true);
    expect(conflicts.conflicts.some((conflict) => conflict.kind === "shared_visual_marker" && conflict.characterNames.includes("강무진") && conflict.characterNames.includes("복아"))).toBe(true);
    workflow = updateCharacterAsset(workflow, "강무진", { supportAnchor: "male, black hair, navy robe, wooden pole" });
    workflow = updateCharacterAsset(workflow, "복아", { supportAnchor: "female, silver hair, white robe, long sword" });
    expect(auditSceneAnchorConflicts(workflow, 1).conflicts).toEqual([]);

    const dense = "A moonlit river ferry at night, Kang Mujin and adult Bok-ah stand apart on the wet wooden rail, navy robe and white hair are clearly separated by position and action, wooden pole in the foreground, decisive medium-wide angle, lantern glow against ink-blue water, rain-dark hemp texture, cinematic Korean wuxia dark fantasy, deep atmospheric perspective, no text, no watermark, no logo, no subtitles, no modern objects, no collage, no duplicate people, no extra limbs.";
    [1, 2].forEach((chunk) => {
      const scenes = workflow.scenes.filter((scene) => scene.chunk === chunk);
      workflow = applyGeneratedChunkScenePrompts(workflow, chunk, scenes.map((scene) => ({ sceneNumber: scene.number, prompt: dense })), "gpt-5-mini");
    });
    workflow = approveStage(workflow, "visualization");
    const bundle = buildFlowMultiChunkZipBundle(workflow, [2, 1, 2]);
    expect(bundle.chunks).toEqual([1, 2]);
    expect(bundle.filename).toBe("테스트_청크_01-02_Flow_일괄_묶음.zip");
    const unpacked = unzipSync(zipFlowMultiChunkBundle(bundle));
    expect(Object.keys(unpacked)).toContain("테스트_Flow_전체_장면_매핑.csv");
    expect(strFromU8(unpacked["테스트_Flow_전체_장면_매핑.csv"])).toContain("script_sentence_ids");
    expect(Object.keys(unpacked).filter((name) => name.endsWith(".txt"))).toHaveLength(2);
  });

  it("groups repeated anchor conflicts across chunks and resolves them with one batch update", () => {
    let workflow = buildScenePlan(createProductionWorkflow("테스트", "hash", deriveScriptSentences(chunks, {})));
    workflow.scenes = workflow.scenes.map((scene) => ({ ...scene, koText: "강무진과 복아가 같은 나루에 섰다." }));
    workflow = updateCharacterAsset(workflow, "강무진", { supportAnchor: "male female, black hair, navy robe, wooden pole" });
    workflow = updateCharacterAsset(workflow, "복아", { supportAnchor: "female, white hair, navy robe, wooden pole" });
    const common = auditCommonAnchorConflicts(workflow);
    const repeated = common.find((entry) => entry.kind === "shared_visual_marker" && entry.characterNames.join("|") === "강무진|복아" && entry.evidence.includes("navy robe"));
    expect(repeated).toMatchObject({ affectedChunks: [1, 2] });
    expect(repeated?.occurrenceCount).toBeGreaterThanOrEqual(2);

    const fixed = batchUpdateCharacterAnchors(workflow, {
      강무진: "male, black hair, navy robe, wooden pole",
      복아: "female, silver hair, white robe, long sword",
    });
    expect(fixed.characters.find((character) => character.name === "복아")?.supportAnchor).toContain("silver hair");
    expect(fixed.stages.characters.status).toBe("NEEDS_REVIEW");
    expect(auditCommonAnchorConflicts(fixed)).toEqual([]);
  });

  it("records common conflict fixes, suggests conservative anchors, and restores a selected history entry", () => {
    let workflow = buildScenePlan(createProductionWorkflow("테스트", "hash", deriveScriptSentences(chunks, {})));
    workflow.scenes = workflow.scenes.map((scene) => ({ ...scene, koText: "강무진과 복아가 같은 나루에 섰다." }));
    workflow = updateCharacterAsset(workflow, "강무진", { supportAnchor: "male, black hair, navy robe, wooden pole" });
    workflow = updateCharacterAsset(workflow, "복아", { supportAnchor: "female, white hair, navy robe, wooden pole" });
    const conflict = auditCommonAnchorConflicts(workflow).find((entry) => entry.kind === "shared_visual_marker" && entry.evidence.includes("navy robe"))!;
    const suggestions = suggestCommonAnchorConflictAnchors(workflow, conflict);
    expect(suggestions.복아).not.toContain("navy robe");
    const resolved = resolveCommonAnchorConflict(workflow, conflict, suggestions);
    expect(resolved.commonAnchorConflictHistory).toHaveLength(1);
    expect(resolved.commonAnchorConflictHistory[0]).toMatchObject({ characterNames: ["강무진", "복아"], affectedChunks: [1, 2] });
    const restored = restoreCommonAnchorConflictResolution(resolved, resolved.commonAnchorConflictHistory[0].id);
    expect(restored.characters.find((character) => character.name === "복아")?.supportAnchor).toContain("navy robe");
    expect(restored.commonAnchorConflictHistory).toHaveLength(1);
  });
});
