import { describe, expect, it } from "vitest";
import { buildFeatureFilmMarkdown } from "./featureFilm";

describe("feature film markdown", () => {
  it("merges all 21 chunks in numeric order and uses an edited chunk when present", () => {
    const source = Object.fromEntries(
      Array.from({ length: 21 }, (_, index) => {
        const chunk = index + 1;
        return [chunk, { content: `칠성탈명록\n[청크 ${String(chunk).padStart(2, "0")}/21]\n원고 ${chunk}` }];
      }),
    );
    const markdown = buildFeatureFilmMarkdown(source, { 2: "[청크 02/21]\n수정 원고 2" });

    expect(markdown).toContain("수정본 1개");
    expect(markdown).toContain("<!-- CHUNK 01 / 21 -->");
    expect(markdown).toContain("<!-- CHUNK 21 / 21 -->");
    expect(markdown.indexOf("원고 1")).toBeLessThan(markdown.indexOf("수정 원고 2"));
    expect(markdown).not.toContain("칠성탈명록\n[청크 02/21]");
  });

  it("refuses to build a feature film when a chunk is missing", () => {
    expect(() => buildFeatureFilmMarkdown({ 1: { content: "원고" } })).toThrow("청크 2, 3");
  });
});
