/**
 * 강물의 장부 디자인: 기획의 인물표, 사용자의 실제 수정, 문장 리듬을
 * 같은 장부 형식으로 다뤄 대본 편집이 다음 초안의 기준이 되게 한다.
 */

import type { StateLedger } from "@/lib/stateLedgerValidator";

export type RhythmNotice = {
  id: string;
  label: string;
  summary: string;
  start: number;
  end: number;
};

export type StyleProfile = {
  sampleCount: number;
  preferredEndings: Array<{ ending: string; count: number }>;
  averageSentenceLength: number;
  shortSentenceRatio: number;
  preferredRhythm: string;
  updatedAt: string;
};

export type CastField = "body_age" | "mind_age" | "actual_age" | "possessions";

export type CastSuggestion = {
  name: string;
  fields: Partial<Record<CastField, number | string[]>>;
  evidence: string[];
};

export type RelationshipSuggestion = {
  pair: string;
  stage: number;
  label?: string;
  evidence: string[];
};

export type CastParseReport = {
  suggestions: CastSuggestion[];
  relationships: RelationshipSuggestion[];
  warnings: string[];
  sourceFound: boolean;
};

export type RelationshipPreview = {
  pair: string;
  currentStage: number | null;
  proposedStage: number;
  nextStage: number | null;
  cap?: number;
  status: "apply" | "same" | "skip";
  message: string;
  label?: string;
  evidence: string[];
};

const knownCharacters = ["강무진", "단여령", "복아", "백야", "위천록", "노철산", "설란", "허담"] as const;
const koreanNumbers: Record<string, number> = { 여덟: 8, 열: 10, 스무: 20, 서른둘: 32, 서른넷: 34, 서른일곱: 37, 마흔넷: 44, 마흔여섯: 46, 마흔일곱: 47, 쉰둘: 52, 쉰넷: 54, 쉰여덟: 58, 일흔: 70, 일흔넷: 74, 백마흔셋: 143 };
const trackedPairs = ["강무진|단여령", "강무진|백야", "강무진|복아", "강무진|위천록"] as const;
const relationshipMaxStage: Record<string, Record<number, number>> = {
  "강무진|단여령": { 1: 1, 5: 2, 10: 4, 11: 5, 15: 7, 20: 8, 21: 9 },
  "강무진|백야": { 4: 4, 10: 5, 11: 6, 15: 7, 20: 8 },
  "강무진|복아": { 1: 1, 5: 2, 7: 4, 20: 5, 21: 6 },
  "강무진|위천록": { 11: 3, 12: 4, 20: 6 },
};

function numberFrom(value?: string) {
  if (!value) return undefined;
  const arabic = Number(value.replace(/[^0-9]/g, ""));
  if (Number.isFinite(arabic) && arabic > 0) return arabic;
  return koreanNumbers[value.replace(/\s/g, "")];
}

function sentencesWithRanges(text: string) {
  const sentences: Array<{ text: string; start: number; end: number }> = [];
  const matcher = /[^.!?\n]+[.!?]?/g;
  let match: RegExpExecArray | null;
  while ((match = matcher.exec(text))) {
    const raw = match[0];
    const leading = raw.search(/\S/);
    const cleaned = raw.trim();
    if (leading >= 0 && cleaned.length > 2 && !/^\[[^\]]+\]"/.test(cleaned)) {
      const start = match.index + leading;
      sentences.push({ text: cleaned, start, end: start + cleaned.length });
    }
  }
  return sentences;
}

export function inspectRhythmWithRanges(text: string, profile?: StyleProfile | null): RhythmNotice[] {
  const sentences = sentencesWithRanges(text);
  const notices: RhythmNotice[] = [];
  const shortSentenceLimit = profile?.averageSentenceLength && profile.averageSentenceLength <= 19 ? 12 : 15;
  const similarLengthTolerance = profile?.averageSentenceLength && profile.averageSentenceLength >= 30 ? 8 : 6;
  for (let index = 0; index < sentences.length - 2; index += 1) {
    const run = sentences.slice(index, index + 3);
    if (run.every((sentence) => sentence.text.replace(/\s/g, "").length <= shortSentenceLimit)) {
      notices.push({ id: `short-${index}`, label: "짧은 문장 3연속", summary: `${index + 1}~${index + 3}문장`, start: run[0].start, end: run.at(-1)!.end });
    }
  }
  for (let index = 0; index < sentences.length - 3; index += 1) {
    const run = sentences.slice(index, index + 4);
    const endings = run.map((sentence) => sentence.text.match(/(았다|었다|였다|한다|된다|이다)$/)?.[1]).filter((value): value is string => Boolean(value));
    if (endings.length === 4 && new Set(endings).size === 1) {
      notices.push({ id: `ending-${index}`, label: "같은 종결어미 4연속", summary: `${index + 1}~${index + 4}문장`, start: run[0].start, end: run.at(-1)!.end });
    }
    const lengths = run.map((sentence) => sentence.text.replace(/\s/g, "").length);
    if (Math.max(...lengths) - Math.min(...lengths) <= similarLengthTolerance) {
      notices.push({ id: `length-${index}`, label: "비슷한 길이 문장 4연속", summary: `${index + 1}~${index + 4}문장`, start: run[0].start, end: run.at(-1)!.end });
    }
  }
  return notices.filter((notice, index, items) => items.findIndex((item) => item.label === notice.label && item.start === notice.start) === index).slice(0, 12);
}

function getCharacterWindow(content: string, name: string) {
  const index = content.indexOf(name);
  if (index < 0) return "";
  const nextHeading = content.slice(index + name.length).search(/\n#{1,3}\s/);
  const end = nextHeading >= 0 ? index + name.length + nextHeading : Math.min(content.length, index + 850);
  return content.slice(Math.max(0, index - 50), end);
}

function findAge(window: string, terms: string[]) {
  for (const term of terms) {
    const expression = new RegExp(`${term}[^\n。.!?]{0,34}?([0-9]+|여덟|열|스무|서른둘|서른넷|서른일곱|마흔넷|마흔여섯|마흔일곱|쉰둘|쉰넷|쉰여덟|일흔|일흔넷|백마흔셋)\s*세`);
    const matched = window.match(expression);
    const parsed = numberFrom(matched?.[1]);
    if (parsed) return parsed;
  }
  const generic = window.match(/(?:나이|연령)[^\n。.!?]{0,20}?([0-9]+|여덟|열|스무|서른둘|서른넷|서른일곱|마흔넷|마흔여섯|마흔일곱|쉰둘|쉰넷|쉰여덟|일흔|일흔넷|백마흔셋)\s*세/);
  return numberFrom(generic?.[1]);
}

function stageCap(pair: string, chunk?: number) {
  const limits = relationshipMaxStage[pair];
  if (!limits || !chunk) return undefined;
  const eligible = Object.keys(limits).map(Number).filter((point) => point <= chunk);
  return eligible.length ? limits[Math.max(...eligible)] : undefined;
}

function parseRelationshipSuggestions(content: string): RelationshipSuggestion[] {
  const suggestions: RelationshipSuggestion[] = [];
  const lines = content.split("\n").map((line) => line.trim()).filter(Boolean);
  trackedPairs.forEach((pair) => {
    const [first, second] = pair.split("|");
    const matching = lines.find((line) => line.includes(first) && line.includes(second) && /관계|단계|동행|신뢰|적대|동료|추격|대립/.test(line));
    if (!matching) return;
    const stageMatch = matching.match(/(?:관계\s*)?([1-9])\s*단계|단계\s*[:：]?\s*([1-9])/);
    const stage = Number(stageMatch?.[1] ?? stageMatch?.[2]);
    if (!Number.isInteger(stage) || stage < 1) return;
    const label = matching
      .replace(new RegExp(`${first}\s*(?:↔|\\||와|과|\\/)?\s*${second}`), "")
      .replace(/(?:관계|단계)\s*[:：]?\s*[1-9]?(?:\s*단계)?/g, "")
      .replace(/[-:：]/g, " ")
      .trim()
      .slice(0, 70);
    suggestions.push({ pair, stage, label: label || undefined, evidence: [matching] });
  });
  return suggestions;
}

export function parseCastTable(content: string): CastParseReport {
  const sourceFound = /인물|캐릭터|등장인물|나이|연령|관계|단계/.test(content);
  const suggestions: CastSuggestion[] = [];
  const relationships = parseRelationshipSuggestions(content);
  const warnings: string[] = [];
  knownCharacters.forEach((name) => {
    const window = getCharacterWindow(content, name);
    if (!window) return;
    const fields: CastSuggestion["fields"] = {};
    const evidence = [window.replace(/\s+/g, " ").slice(0, 180)];
    const bodyAge = findAge(window, ["육체", "외형", "몸"]);
    const mindAge = findAge(window, ["정신", "목소리", "실제 나이"]);
    const actualAge = findAge(window, ["실제 나이"]);
    if (bodyAge) fields.body_age = bodyAge;
    if (mindAge) fields.mind_age = mindAge;
    if (actualAge) fields.actual_age = actualAge;
    const possession = window.match(/(?:소지품|무기|지닌 물건)\s*[:：-]\s*([^\n]+)/)?.[1];
    if (possession) fields.possessions = possession.split(/[,·/]/).map((item) => item.trim()).filter(Boolean).slice(0, 6);
    if (name === "복아") {
      fields.mind_age = 20;
      fields.body_age = 70;
      fields.actual_age = 20;
      evidence.push("사용자 확정 복아 잠금: 실제·정신·목소리 20세, 청크 1~20 육체 70세, 청크 21 육체 20세 복귀");
    }
    if (Object.keys(fields).length) suggestions.push({ name, fields, evidence });
  });
  if (!sourceFound) warnings.push("인물표·캐릭터·나이 항목을 찾지 못했습니다. 기획본에 이름과 연령을 표기해 주세요.");
  if (!suggestions.length && !relationships.length) warnings.push("상태 장부에 적용할 인물·관계 정보를 추출하지 못했습니다.");
  return { suggestions, relationships, warnings, sourceFound };
}

export function previewRelationshipSuggestions(ledger: StateLedger, report: CastParseReport): RelationshipPreview[] {
  return report.relationships.map((suggestion) => {
    const base = { pair: suggestion.pair, proposedStage: suggestion.stage, label: suggestion.label, evidence: suggestion.evidence };
    const existing = ledger.relationships?.[suggestion.pair];
    const currentStage = typeof existing?.stage === "number" ? existing.stage : null;
    const cap = stageCap(suggestion.pair, ledger.chunk);
    if (!existing) {
      return { ...base, currentStage, nextStage: null, cap, status: "skip", message: "현재 장부에 관계쌍이 없습니다." };
    }
    if (cap !== undefined && suggestion.stage > cap) {
      return { ...base, currentStage, nextStage: currentStage, cap, status: "skip", message: `청크 ${ledger.chunk}의 관계 상한 ${cap}단계를 넘습니다.` };
    }
    if (currentStage !== null && suggestion.stage <= currentStage) {
      return { ...base, currentStage, nextStage: currentStage, cap, status: "same", message: "현재 장부 단계가 같거나 더 높아 그대로 둡니다." };
    }
    return { ...base, currentStage, nextStage: suggestion.stage, cap, status: "apply", message: "기획본 근거와 함께 현재 장부에 반영할 수 있습니다." };
  });
}

export function applyCastSuggestions(ledger: StateLedger, report: CastParseReport): { ledger: StateLedger; applied: string[]; skipped: string[] } {
  const characters = { ...ledger.characters };
  const relationships = { ...ledger.relationships };
  const applied: string[] = [];
  const skipped: string[] = [];
  report.suggestions.forEach((suggestion) => {
    const existing = characters[suggestion.name];
    if (!existing) {
      skipped.push(`${suggestion.name}: 현재 장부에 없는 인물`);
      return;
    }
    const fields = suggestion.fields;
    characters[suggestion.name] = {
      ...existing,
      ...(typeof fields.body_age === "number" ? { body_age: fields.body_age } : {}),
      ...(typeof fields.mind_age === "number" ? { mind_age: fields.mind_age } : {}),
      ...(typeof fields.actual_age === "number" ? { actual_age: fields.actual_age } : {}),
      ...(Array.isArray(fields.possessions) ? { possessions: fields.possessions } : {}),
    };
    applied.push(suggestion.name);
  });
  report.relationships.forEach((suggestion) => {
    const existing = relationships[suggestion.pair];
    if (!existing) {
      skipped.push(`${suggestion.pair}: 현재 장부에 없는 관계쌍`);
      return;
    }
    const cap = stageCap(suggestion.pair, ledger.chunk);
    if (cap !== undefined && suggestion.stage > cap) {
      skipped.push(`${suggestion.pair}: 청크 ${ledger.chunk}의 최대 단계 ${cap} 초과`);
      return;
    }
    if (typeof existing.stage === "number" && suggestion.stage < existing.stage) {
      skipped.push(`${suggestion.pair}: 현재 단계보다 낮은 제안`);
      return;
    }
    relationships[suggestion.pair] = {
      ...existing,
      stage: suggestion.stage,
      ...(suggestion.label ? { label: suggestion.label } : {}),
      evidence: Array.from(new Set([...(existing.evidence ?? []), ...suggestion.evidence])).slice(-4),
    };
    applied.push(`${suggestion.pair} 관계`);
  });
  return { ledger: { ...ledger, characters, relationships }, applied, skipped };
}

function endingStats(text: string) {
  const counts = new Map<string, number>();
  sentencesWithRanges(text).forEach(({ text: sentence }) => {
    const ending = sentence.match(/(았다|었다|였다|한다|된다|이다|한다|였다|겠다|네요|어요|았다)$/)?.[1];
    if (ending) counts.set(ending, (counts.get(ending) ?? 0) + 1);
  });
  return Array.from(counts.entries()).map(([ending, count]) => ({ ending, count })).sort((a, b) => b.count - a.count).slice(0, 4);
}

export function updateStyleProfile(previous: StyleProfile | null, source: string, revised: string): StyleProfile {
  const revisedSentences = sentencesWithRanges(revised);
  const changedDensity = Math.max(1, Math.abs(revised.length - source.length));
  const averageSentenceLength = revisedSentences.length ? Math.round(revisedSentences.reduce((total, sentence) => total + sentence.text.replace(/\s/g, "").length, 0) / revisedSentences.length) : 0;
  const shortSentenceRatio = revisedSentences.length ? Math.round((revisedSentences.filter((sentence) => sentence.text.replace(/\s/g, "").length <= 15).length / revisedSentences.length) * 100) : 0;
  const preferredEndings = endingStats(revised);
  const sampleCount = (previous?.sampleCount ?? 0) + 1;
  const weightedAverage = previous ? Math.round(((previous.averageSentenceLength * previous.sampleCount) + averageSentenceLength) / sampleCount) : averageSentenceLength;
  const weightedShort = previous ? Math.round(((previous.shortSentenceRatio * previous.sampleCount) + shortSentenceRatio) / sampleCount) : shortSentenceRatio;
  const preferredRhythm = weightedAverage <= 19 ? "짧고 빠른 호흡" : weightedAverage >= 30 ? "길고 묵직한 호흡" : "짧음과 중간 길이를 섞는 호흡";
  return { sampleCount, preferredEndings, averageSentenceLength: weightedAverage, shortSentenceRatio: weightedShort, preferredRhythm: `${preferredRhythm} · 수정 밀도 ${changedDensity.toLocaleString()}자`, updatedAt: new Date().toISOString() };
}

export function styleGuidance(profile: StyleProfile | null) {
  if (!profile?.sampleCount) return "사용자 수정본이 쌓이면 선호 문장 길이와 종결어미를 다음 초안에 반영합니다.";
  const endings = profile.preferredEndings.map((item) => `${item.ending} ${item.count}회`).join(", ") || "특정 종결어미 없음";
  return `사용자 수정 ${profile.sampleCount}회 기준. 평균 ${profile.averageSentenceLength}자, 짧은 문장 ${profile.shortSentenceRatio}퍼센트, 선호 종결어미 ${endings}. ${profile.preferredRhythm}`;
}
