export const STAGE_KEYS = ["synopsis", "script", "characters", "visualization", "flow", "video", "metadata", "audit"] as const;

import { strToU8, zipSync } from "fflate";

export type ProductionStage = (typeof STAGE_KEYS)[number];
export type StageStatus = "NOT_STARTED" | "IN_PROGRESS" | "NEEDS_REVIEW" | "APPROVED" | "INVALIDATED" | "FAILED";

export type ScriptSentence = {
  id: string;
  chunk: number;
  text: string;
  dialogue: boolean;
};

export type VisualScene = {
  number: number;
  chunk: number;
  scriptSentenceIds: string[];
  dialogueIds: string[];
  koText: string;
  enImagePrompt: string;
  promptSource: "manual" | "generated" | null;
  promptGeneratedAt: string | null;
  promptModel: string | null;
  imageUrl: string;
  imageGeneratedAt: string | null;
  promptOptimizationHistory: PromptOptimizationSnapshot[];
};

export type PromptOptimizationSnapshot = {
  id: string;
  createdAt: string;
  beforePrompt: string;
  afterPrompt: string;
  result: Omit<PromptOptimizationResult, "sceneNumber">;
};

export type CharacterAppearanceReviewStatus = "NOT_REVIEWED" | "NEEDS_REVIEW" | "APPROVED";

export type CharacterAsset = {
  name: string;
  importance: "main" | "support";
  sheetReady: boolean;
  characterSheet: string;
  imageReady: boolean;
  imageUrl: string;
  imageAlt: string;
  faceReferenceReady: boolean;
  fullBodyReferenceReady: boolean;
  supportAnchor: string;
  appearanceReviewStatus: CharacterAppearanceReviewStatus;
  appearanceReviewNote: string;
  appearanceReviewedAt: string | null;
};

export type MetadataDraft = {
  titles: Array<{ type: "의문형" | "직설형" | "숫자·역전형"; text: string; scriptEvidence: string }>;
  timeline: string[];
  hashtags: string[];
  signature: string;
};

export type StageRun = {
  status: StageStatus;
  version: number;
  approvedAt: string | null;
  invalidatedReason: string | null;
};

export type InvalidationEvent = {
  id: string;
  sourceStage: ProductionStage;
  affectedStages: ProductionStage[];
  reason: string;
  createdAt: string;
};

export type ProductionIssue = {
  severity: "error" | "warning";
  stage: ProductionStage;
  code: string;
  message: string;
};

export type ProductionAudit = {
  sentenceCount: number;
  sceneCount: number;
  mappedSentenceCount: number;
  mappedDialogueCount: number;
  flowCount: number;
  videoCount: number;
  issues: ProductionIssue[];
};

export type ProductionWorkflow = {
  schemaVersion: "1.0";
  title: string;
  scriptFingerprint: string;
  stages: Record<ProductionStage, StageRun>;
  sentences: ScriptSentence[];
  scenes: VisualScene[];
  characters: CharacterAsset[];
  metadata: MetadataDraft;
  flowLines: string[];
  videoLines: string[];
  invalidations: InvalidationEvent[];
  commonAnchorConflictHistory: CommonAnchorConflictResolution[];
  updatedAt: string;
};

export type FinalScriptExport = {
  schemaVersion: "1.0";
  exportedAt: string;
  title: string;
  scriptFingerprint: string;
  chunks: Array<{ chunk: number; content: string; edited: boolean }>;
  sentences: ScriptSentence[];
};

export type VisualizationExport = {
  schemaVersion: "1.0";
  exportedAt: string;
  title: string;
  scriptFingerprint: string;
  stage: StageRun;
  scenes: Array<VisualScene & { flowPrompt: string | null; videoPrompt: string | null }>;
};

export type VisualizationChunkExport = {
  schemaVersion: "1.1";
  exportedAt: string;
  title: string;
  scriptFingerprint: string;
  chunk: number;
  scenes: Array<VisualScene & { flowPrompt: string | null; videoPrompt: string | null }>;
};

export type ChunkGenerationEstimate = {
  chunk: number;
  sceneCount: number;
  densePromptRequestCount: number;
  imageGenerationRequestCount: number;
  generatedImageCount: number;
  imageModel: "GPT Image 2";
  imageQuality: "medium";
};

export type CharacterAppearanceCheck = {
  name: string;
  sceneCount: number;
  score: number | null;
  matchedKeywords: string[];
  missingKeywords: string[];
  status: "checked" | "anchor_missing" | "not_in_chunk";
};

export type ChunkAppearanceAudit = {
  chunk: number;
  overallScore: number | null;
  checks: CharacterAppearanceCheck[];
};

export type FlowChunkExport = {
  schemaVersion: "1.0";
  exportedAt: string;
  title: string;
  scriptFingerprint: string;
  chunk: number;
  lines: Array<{ sceneNumber: number; scriptSentenceIds: string[]; prompt: string }>;
};

export type FlowChunkZipBundle = {
  filename: string;
  files: Record<string, string>;
};

export type PromptOptimizationResult = {
  sceneNumber: number;
  originalLength: number;
  optimizedLength: number;
  removedDuplicateClauses: number;
  repeatedTerms: string[];
  truncated: boolean;
};

export type ChunkPromptOptimization = {
  chunk: number;
  changedCount: number;
  results: PromptOptimizationResult[];
};

export type SceneAnchorConflict = {
  sceneNumber: number;
  characterNames: string[];
  severity: "warning" | "error";
  kind: "self_contradiction" | "duplicate_anchor" | "shared_visual_marker";
  message: string;
  evidence: string[];
};

export type ChunkAnchorConflictAudit = {
  chunk: number;
  conflicts: SceneAnchorConflict[];
};

export type CommonAnchorConflict = {
  key: string;
  kind: SceneAnchorConflict["kind"];
  severity: SceneAnchorConflict["severity"];
  characterNames: string[];
  evidence: string[];
  message: string;
  affectedChunks: number[];
  affectedSceneNumbers: number[];
  occurrenceCount: number;
};

export type CommonAnchorConflictResolution = {
  id: string;
  createdAt: string;
  conflictKey: string;
  conflictMessage: string;
  characterNames: string[];
  beforeAnchors: Record<string, string>;
  afterAnchors: Record<string, string>;
  affectedChunks: number[];
};

export type FlowMultiChunkZipBundle = {
  filename: string;
  files: Record<string, string>;
  chunks: number[];
};

const stage = (status: StageStatus): StageRun => ({ status, version: status === "APPROVED" ? 1 : 0, approvedAt: status === "APPROVED" ? new Date().toISOString() : null, invalidatedReason: null });

const downstream: Record<ProductionStage, ProductionStage[]> = {
  synopsis: ["script", "characters", "visualization", "flow", "video", "metadata", "audit"],
  script: ["characters", "visualization", "flow", "video", "metadata", "audit"],
  characters: ["visualization", "flow", "video", "audit"],
  visualization: ["flow", "video", "metadata", "audit"],
  flow: ["video", "audit"],
  video: ["audit"],
  metadata: ["audit"],
  audit: [],
};

export const stageLabels: Record<ProductionStage, string> = {
  synopsis: "시놉시스",
  script: "대본",
  characters: "캐릭터",
  visualization: "시각화",
  flow: "Flow",
  video: "영상",
  metadata: "메타데이터",
  audit: "최종 감사",
};

function now() {
  return new Date().toISOString();
}

function id(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T;
}

export function sentenceFingerprint(chunks: Record<number, { content: string }>, edits: Record<number, string>) {
  return Array.from({ length: 21 }, (_, index) => edits[index + 1] ?? chunks[index + 1]?.content ?? "").join("\n---chunk-boundary---\n");
}

export function deriveScriptSentences(chunks: Record<number, { content: string }>, edits: Record<number, string>): ScriptSentence[] {
  const rows: ScriptSentence[] = [];
  for (let chunk = 1; chunk <= 21; chunk += 1) {
    const source = edits[chunk] ?? chunks[chunk]?.content ?? "";
    source.split("\n").forEach((rawLine, lineIndex) => {
      const line = rawLine.trim();
      if (!line || /^#{1,3}\s/.test(line) || /^\[(CTA|END)\]$/.test(line) || /^_{3,}$/.test(line)) return;
      const dialogue = /^\[[^\]]+\]".+"$/.test(line);
      const pieces = dialogue ? [line] : line.split(/(?<=[.!?])\s+/).map((part) => part.trim()).filter((part) => part.length > 2);
      pieces.forEach((text, pieceIndex) => {
        if (text.length < 3) return;
        rows.push({ id: `c${String(chunk).padStart(2, "0")}-l${String(lineIndex + 1).padStart(3, "0")}-s${pieceIndex + 1}`, chunk, text, dialogue });
      });
    });
  }
  return rows;
}

export function createScenePlan(sentences: ScriptSentence[]): VisualScene[] {
  const scenes: VisualScene[] = [];
  for (let chunk = 1; chunk <= 21; chunk += 1) {
    const chunkSentences = sentences.filter((sentence) => sentence.chunk === chunk);
    for (let offset = 0; offset < chunkSentences.length; offset += 3) {
      const group = chunkSentences.slice(offset, offset + 3);
      if (!group.length) continue;
      scenes.push({
        number: scenes.length + 1,
        chunk,
        scriptSentenceIds: group.map((sentence) => sentence.id),
        dialogueIds: group.filter((sentence) => sentence.dialogue).map((sentence) => sentence.id),
        koText: group.map((sentence) => sentence.text).join(" "),
        enImagePrompt: "",
        promptSource: null,
        promptGeneratedAt: null,
        promptModel: null,
        imageUrl: "",
        imageGeneratedAt: null,
        promptOptimizationHistory: [],
      });
    }
  }
  return scenes;
}

export function createProductionWorkflow(title: string, fingerprint: string, sentences: ScriptSentence[]): ProductionWorkflow {
  return {
    schemaVersion: "1.0",
    title,
    scriptFingerprint: fingerprint,
    stages: {
      synopsis: stage("APPROVED"),
      script: stage("NEEDS_REVIEW"),
      characters: stage("NOT_STARTED"),
      visualization: stage("NOT_STARTED"),
      flow: stage("NOT_STARTED"),
      video: stage("NOT_STARTED"),
      metadata: stage("NOT_STARTED"),
      audit: stage("NOT_STARTED"),
    },
    sentences,
    scenes: [],
    characters: [
      { name: "강무진", importance: "main", sheetReady: false, characterSheet: "", imageReady: false, imageUrl: "", imageAlt: "", faceReferenceReady: false, fullBodyReferenceReady: false, supportAnchor: "", appearanceReviewStatus: "NOT_REVIEWED", appearanceReviewNote: "", appearanceReviewedAt: null },
      { name: "단여령", importance: "main", sheetReady: false, characterSheet: "", imageReady: false, imageUrl: "", imageAlt: "", faceReferenceReady: false, fullBodyReferenceReady: false, supportAnchor: "", appearanceReviewStatus: "NOT_REVIEWED", appearanceReviewNote: "", appearanceReviewedAt: null },
      { name: "복아", importance: "main", sheetReady: false, characterSheet: "", imageReady: false, imageUrl: "", imageAlt: "", faceReferenceReady: false, fullBodyReferenceReady: false, supportAnchor: "", appearanceReviewStatus: "NOT_REVIEWED", appearanceReviewNote: "", appearanceReviewedAt: null },
      { name: "백야", importance: "main", sheetReady: false, characterSheet: "", imageReady: false, imageUrl: "", imageAlt: "", faceReferenceReady: false, fullBodyReferenceReady: false, supportAnchor: "", appearanceReviewStatus: "NOT_REVIEWED", appearanceReviewNote: "", appearanceReviewedAt: null },
      { name: "관천원 집행대", importance: "support", sheetReady: false, characterSheet: "", imageReady: false, imageUrl: "", imageAlt: "", faceReferenceReady: false, fullBodyReferenceReady: false, supportAnchor: "", appearanceReviewStatus: "NOT_REVIEWED", appearanceReviewNote: "", appearanceReviewedAt: null },
    ],
    metadata: {
      titles: [
        { type: "의문형", text: "", scriptEvidence: "" },
        { type: "직설형", text: "", scriptEvidence: "" },
        { type: "숫자·역전형", text: "", scriptEvidence: "" },
      ],
      timeline: [],
      hashtags: [],
      signature: "🗡️ 무협스튜디오 — 강호는 멈추지 않는다.",
    },
    flowLines: [],
    videoLines: [],
    invalidations: [],
    commonAnchorConflictHistory: [],
    updatedAt: now(),
  };
}

export function normalizeProductionWorkflow(stored: Partial<ProductionWorkflow>, title: string, fingerprint: string, sentences: ScriptSentence[]): ProductionWorkflow {
  const base = createProductionWorkflow(title, fingerprint, sentences);
  const metadata = stored.metadata;
  return {
    ...base,
    ...stored,
    title: stored.title || title,
    scriptFingerprint: stored.scriptFingerprint || fingerprint,
    stages: { ...base.stages, ...(stored.stages ?? {}) },
    sentences: Array.isArray(stored.sentences) ? stored.sentences : sentences,
    scenes: Array.isArray(stored.scenes) ? stored.scenes.map((scene) => ({
      ...scene,
      chunk: Number.isInteger(scene.chunk) && scene.chunk >= 1 && scene.chunk <= 21 ? scene.chunk : Number(String(scene.scriptSentenceIds?.[0] ?? "").slice(1, 3)) || 1,
      promptSource: scene.promptSource === "manual" || scene.promptSource === "generated" ? scene.promptSource : null,
      promptGeneratedAt: scene.promptGeneratedAt ?? null,
      promptModel: scene.promptModel ?? null,
      imageUrl: scene.imageUrl ?? "",
      imageGeneratedAt: scene.imageGeneratedAt ?? null,
      promptOptimizationHistory: Array.isArray(scene.promptOptimizationHistory) ? scene.promptOptimizationHistory : [],
    })) : [],
    characters: Array.isArray(stored.characters)
      ? base.characters.map((baseCharacter) => {
        const storedCharacter: Partial<CharacterAsset> = stored.characters?.find((character) => character?.name === baseCharacter.name) ?? {};
        return {
          ...baseCharacter,
          ...storedCharacter,
          appearanceReviewStatus: storedCharacter.appearanceReviewStatus === "APPROVED" || storedCharacter.appearanceReviewStatus === "NEEDS_REVIEW" ? storedCharacter.appearanceReviewStatus : "NOT_REVIEWED",
          appearanceReviewNote: storedCharacter.appearanceReviewNote ?? "",
          appearanceReviewedAt: storedCharacter.appearanceReviewedAt ?? null,
        };
      })
      : base.characters,
    metadata: {
      ...base.metadata,
      ...metadata,
      titles: Array.isArray(metadata?.titles) && metadata.titles.length === 3 ? metadata.titles : base.metadata.titles,
      timeline: Array.isArray(metadata?.timeline) ? metadata.timeline : [],
      hashtags: Array.isArray(metadata?.hashtags) ? metadata.hashtags : [],
      signature: metadata?.signature ?? base.metadata.signature,
    },
    flowLines: Array.isArray(stored.flowLines) ? stored.flowLines : [],
    videoLines: Array.isArray(stored.videoLines) ? stored.videoLines : [],
    invalidations: Array.isArray(stored.invalidations) ? stored.invalidations : [],
    commonAnchorConflictHistory: Array.isArray(stored.commonAnchorConflictHistory) ? stored.commonAnchorConflictHistory : [],
    updatedAt: stored.updatedAt ?? now(),
  };
}

export function validateCharacterAssets(characters: CharacterAsset[]) {
  const issues: ProductionIssue[] = [];
  characters.filter((character) => character.importance === "main").forEach((character) => {
    if (!character.sheetReady || !character.imageReady || !character.faceReferenceReady || !character.fullBodyReferenceReady) {
      issues.push({ severity: "error", stage: "characters", code: "main_character_asset_missing", message: `${character.name}의 텍스트 시트, 이름 표기 이미지, 얼굴·전신 레퍼런스가 모두 준비되지 않았습니다.` });
    }
    if (character.sheetReady && !character.characterSheet.trim()) issues.push({ severity: "error", stage: "characters", code: "character_sheet_content_missing", message: `${character.name}의 캐릭터 시트 본문이 비어 있습니다.` });
    if (character.imageReady && !character.imageUrl.trim()) issues.push({ severity: "error", stage: "characters", code: "character_image_url_missing", message: `${character.name}의 인물 이미지 URL이 없어 미리보기를 만들 수 없습니다.` });
    if (character.imageReady && character.supportAnchor.trim() && character.appearanceReviewStatus !== "APPROVED") issues.push({ severity: "warning", stage: "characters", code: "character_appearance_review_pending", message: `${character.name}의 생성 이미지와 외형 앵커 비교 검수가 아직 승인되지 않았습니다.` });
  });
  characters.filter((character) => character.importance === "support").forEach((character) => {
    if (character.supportAnchor.trim().length < 20) {
      issues.push({ severity: "error", stage: "characters", code: "support_anchor_missing", message: `${character.name}의 영어 외형 앵커가 20자 미만입니다.` });
    }
  });
  return issues;
}

export function validateMetadata(metadata: MetadataDraft) {
  const issues: ProductionIssue[] = [];
  metadata.titles.forEach((title) => {
    if (!title.text.trim()) issues.push({ severity: "error", stage: "metadata", code: "title_missing", message: `${title.type} 제목이 비어 있습니다.` });
    if (!title.scriptEvidence.trim()) issues.push({ severity: "error", stage: "metadata", code: "title_evidence_missing", message: `${title.type} 제목의 대본 근거가 없습니다.` });
    if (title.type === "의문형" && title.text.trim() && !title.text.includes("?")) issues.push({ severity: "error", stage: "metadata", code: "question_title", message: "의문형 제목에는 물음표가 필요합니다." });
    if (title.type === "숫자·역전형" && title.text.trim() && !/[0-9]/.test(title.text)) issues.push({ severity: "error", stage: "metadata", code: "number_title", message: "숫자·역전형 제목에는 숫자가 필요합니다." });
  });
  if (metadata.timeline.length < 5 || metadata.timeline.length > 8) issues.push({ severity: "error", stage: "metadata", code: "timeline_count", message: `타임라인은 5~8개가 필요합니다. 현재 ${metadata.timeline.length}개입니다.` });
  if (metadata.hashtags.length !== 12 || metadata.hashtags.some((tag) => !tag.startsWith("#"))) issues.push({ severity: "error", stage: "metadata", code: "hashtag_count", message: `해시태그는 #으로 시작하는 12개가 필요합니다. 현재 ${metadata.hashtags.length}개입니다.` });
  if (metadata.signature !== "🗡️ 무협스튜디오 — 강호는 멈추지 않는다.") issues.push({ severity: "error", stage: "metadata", code: "signature", message: "고정 서명이 제작 규칙과 다릅니다." });
  return issues;
}

export function auditProduction(workflow: ProductionWorkflow): ProductionAudit {
  const issues: ProductionIssue[] = [];
  const sourceIds = new Set(workflow.sentences.map((sentence) => sentence.id));
  const dialogueIds = new Set(workflow.sentences.filter((sentence) => sentence.dialogue).map((sentence) => sentence.id));
  const mapped = workflow.scenes.flatMap((scene) => scene.scriptSentenceIds);
  const mappedSet = new Set(mapped);
  const mappedDialogue = workflow.scenes.flatMap((scene) => scene.dialogueIds);
  const visualStarted = workflow.scenes.length > 0 || ["NEEDS_REVIEW", "APPROVED"].includes(workflow.stages.visualization.status);
  const flowStarted = workflow.flowLines.length > 0 || ["NEEDS_REVIEW", "APPROVED"].includes(workflow.stages.flow.status);
  const videoStarted = workflow.videoLines.length > 0 || ["NEEDS_REVIEW", "APPROVED"].includes(workflow.stages.video.status);
  const charactersStarted = ["NEEDS_REVIEW", "APPROVED"].includes(workflow.stages.characters.status);
  const metadataStarted = ["NEEDS_REVIEW", "APPROVED"].includes(workflow.stages.metadata.status);

  if (visualStarted) {
    sourceIds.forEach((sentenceId) => {
      const count = mapped.filter((id) => id === sentenceId).length;
      if (count === 0) issues.push({ severity: "error", stage: "visualization", code: "sentence_unmapped", message: `대본 문장 ${sentenceId}가 시각화 장면에 매핑되지 않았습니다.` });
      if (count > 1) issues.push({ severity: "error", stage: "visualization", code: "sentence_duplicated", message: `대본 문장 ${sentenceId}가 ${count}개 장면에 중복 매핑됐습니다.` });
    });
    mappedSet.forEach((sentenceId) => {
      if (!sourceIds.has(sentenceId)) issues.push({ severity: "error", stage: "visualization", code: "unknown_sentence", message: `시각화에 존재하지 않는 문장 ID ${sentenceId}가 있습니다.` });
    });
    dialogueIds.forEach((sentenceId) => {
      if (!mappedDialogue.includes(sentenceId)) issues.push({ severity: "error", stage: "visualization", code: "dialogue_unmapped", message: `직접 대사 ${sentenceId}가 장면 대사 목록에 없습니다.` });
    });
  }
  workflow.scenes.forEach((scene, index) => {
    if (scene.number !== index + 1) issues.push({ severity: "error", stage: "visualization", code: "scene_sequence", message: `장면 번호 ${scene.number}이 연속 순서와 다릅니다.` });
    if (!Number.isInteger(scene.chunk) || scene.chunk < 1 || scene.chunk > 21) issues.push({ severity: "error", stage: "visualization", code: "scene_chunk_invalid", message: `장면 ${scene.number}의 청크 연결이 올바르지 않습니다.` });
    const linkedChunks = new Set(scene.scriptSentenceIds.map((sentenceId) => Number(sentenceId.slice(1, 3))));
    if (linkedChunks.size > 1 || (linkedChunks.size && !linkedChunks.has(scene.chunk))) issues.push({ severity: "error", stage: "visualization", code: "scene_cross_chunk", message: `장면 ${scene.number}이 청크 경계를 넘습니다.` });
    if (scene.scriptSentenceIds.length < 2 || scene.scriptSentenceIds.length > 3) issues.push({ severity: "warning", stage: "visualization", code: "scene_sentence_range", message: `장면 ${scene.number}은 문장 ${scene.scriptSentenceIds.length}개입니다. 기본 범위는 2~3개입니다.` });
    if (!scene.enImagePrompt.trim()) issues.push({ severity: "error", stage: "visualization", code: "scene_prompt_missing", message: `장면 ${scene.number}의 영어 이미지 프롬프트가 비어 있습니다.` });
  });
  if (flowStarted && workflow.flowLines.length !== workflow.scenes.length) issues.push({ severity: "error", stage: "flow", code: "flow_count", message: `Flow ${workflow.flowLines.length}줄과 시각화 ${workflow.scenes.length}장면의 수가 다릅니다.` });
  workflow.flowLines.forEach((line, index) => {
    if (!line.trim()) issues.push({ severity: "error", stage: "flow", code: "flow_blank", message: `Flow ${index + 1}행이 비어 있습니다.` });
    if (/\[?(CTA|END|장면|한국어 번역|영어 이미지 프롬프트)\]?/i.test(line)) issues.push({ severity: "error", stage: "flow", code: "flow_label", message: `Flow ${index + 1}행에 제거 대상 표식이 남았습니다.` });
  });
  if (videoStarted && workflow.videoLines.length !== workflow.scenes.length) issues.push({ severity: "error", stage: "video", code: "video_count", message: `영상 프롬프트 ${workflow.videoLines.length}줄과 시각화 ${workflow.scenes.length}장면의 수가 다릅니다.` });
  workflow.videoLines.forEach((line, index) => {
    if (/audio|sound|dialogue|speech|tts|lip.?sync|sfx|bgm|오디오|대사|음성|립싱크|효과음|배경음/i.test(line)) issues.push({ severity: "error", stage: "video", code: "video_audio_instruction", message: `영상 프롬프트 ${index + 1}행에 오디오·대사 지시가 있습니다.` });
  });
  if (charactersStarted) issues.push(...validateCharacterAssets(workflow.characters));
  if (metadataStarted) issues.push(...validateMetadata(workflow.metadata));
  return {
    sentenceCount: workflow.sentences.length,
    sceneCount: workflow.scenes.length,
    mappedSentenceCount: mappedSet.size,
    mappedDialogueCount: new Set(mappedDialogue).size,
    flowCount: workflow.flowLines.length,
    videoCount: workflow.videoLines.length,
    issues,
  };
}

export function invalidateDownstream(workflow: ProductionWorkflow, sourceStage: ProductionStage, reason: string) {
  const next = clone(workflow);
  const affectedStages = downstream[sourceStage];
  affectedStages.forEach((stageKey) => {
    const current = next.stages[stageKey];
    next.stages[stageKey] = { ...current, status: "INVALIDATED", approvedAt: null, invalidatedReason: reason };
  });
  if (affectedStages.length) next.invalidations.unshift({ id: id("invalidate"), sourceStage, affectedStages, reason, createdAt: now() });
  next.updatedAt = now();
  return next;
}

export function approveStage(workflow: ProductionWorkflow, stageKey: ProductionStage) {
  const next = clone(workflow);
  next.stages[stageKey] = { status: "APPROVED", version: next.stages[stageKey].version + 1, approvedAt: now(), invalidatedReason: null };
  next.updatedAt = now();
  return next;
}

export function setStageReview(workflow: ProductionWorkflow, stageKey: ProductionStage) {
  const next = clone(workflow);
  next.stages[stageKey] = { ...next.stages[stageKey], status: "NEEDS_REVIEW", invalidatedReason: null };
  next.updatedAt = now();
  return next;
}

export function buildScenePlan(workflow: ProductionWorkflow) {
  const next = invalidateDownstream(workflow, "visualization", "시각화 장면 계획을 새로 만들었습니다.");
  next.scenes = createScenePlan(next.sentences);
  next.flowLines = [];
  next.videoLines = [];
  next.stages.visualization = { ...next.stages.visualization, status: "NEEDS_REVIEW", invalidatedReason: null };
  next.updatedAt = now();
  return next;
}

export function updateScenePrompt(workflow: ProductionWorkflow, sceneNumber: number, prompt: string) {
  const next = invalidateDownstream(workflow, "visualization", `장면 ${sceneNumber}의 시각화 프롬프트가 변경됐습니다.`);
  next.scenes = next.scenes.map((scene) => scene.number === sceneNumber ? { ...scene, enImagePrompt: prompt, promptSource: prompt.trim() ? "manual" : null, promptGeneratedAt: null, promptModel: null } : scene);
  next.stages.visualization = { ...next.stages.visualization, status: "NEEDS_REVIEW", invalidatedReason: null };
  next.updatedAt = now();
  return next;
}

const promptDuplicateStopWords = new Set(["the", "and", "with", "from", "that", "this", "into", "over", "under", "for", "while", "then", "scene", "cinematic", "korean", "wuxia", "dark", "light", "shot", "camera"]);
const canonicalNegativeGuard = "no text, no watermark, no logo, no subtitles, no modern objects, no collage, no duplicate people, no extra limbs";

function promptTerms(value: string) {
  return value.toLowerCase().match(/[a-z][a-z-]{2,}/g)?.filter((term) => !promptDuplicateStopWords.has(term)) ?? [];
}

function trimAtWordBoundary(value: string, maxLength: number) {
  if (value.length <= maxLength) return value;
  const trimmed = value.slice(0, maxLength + 1);
  const boundary = Math.max(trimmed.lastIndexOf(","), trimmed.lastIndexOf(" "));
  return (boundary > Math.floor(maxLength * 0.6) ? trimmed.slice(0, boundary) : trimmed.slice(0, maxLength)).replace(/[\s,;:.-]+$/, "");
}

export function optimizeImagePrompt(prompt: string, maxLength = 1_600): { prompt: string; result: Omit<PromptOptimizationResult, "sceneNumber"> } {
  const original = prompt.trim();
  if (!original) return { prompt: "", result: { originalLength: 0, optimizedLength: 0, removedDuplicateClauses: 0, repeatedTerms: [], truncated: false } };
  const originalTerms = promptTerms(original);
  const repeatedTerms = Array.from(new Set(originalTerms.filter((term) => originalTerms.filter((candidate) => candidate === term).length > 2))).slice(0, 12);
  const clauses = original.split(/[,;]+/).map((part) => part.trim().replace(/\s+/g, " ")).filter(Boolean);
  const kept: string[] = [];
  const seenClauses = new Set<string>();
  let removedDuplicateClauses = 0;
  clauses.forEach((clause) => {
    const normalized = clause.toLowerCase().replace(/[^a-z0-9 ]/g, "").replace(/\s+/g, " ").trim();
    if (!normalized || /^(no )?(text|watermark|logo|subtitles|modern objects|collage|duplicate people|extra limbs)/i.test(clause)) return;
    const terms = new Set(promptTerms(clause));
    const hasNearDuplicate = kept.some((existing) => {
      const existingTerms = new Set(promptTerms(existing));
      const overlap = Array.from(terms).filter((term) => existingTerms.has(term)).length;
      return terms.size >= 3 && overlap / terms.size >= 0.8;
    });
    if (seenClauses.has(normalized) || hasNearDuplicate) {
      removedDuplicateClauses += 1;
      return;
    }
    seenClauses.add(normalized);
    kept.push(clause);
  });
  const bodyBudget = Math.max(80, maxLength - canonicalNegativeGuard.length - 2);
  let body = kept.join(", ");
  let truncated = false;
  while (body.length > bodyBudget && kept.length > 2) {
    kept.pop();
    body = kept.join(", ");
    truncated = true;
  }
  if (body.length > bodyBudget) {
    body = trimAtWordBoundary(body, bodyBudget);
    truncated = true;
  }
  const optimized = `${body || "cinematic wuxia character scene"}, ${canonicalNegativeGuard}`.replace(/\s+/g, " ").trim();
  return { prompt: optimized, result: { originalLength: original.length, optimizedLength: optimized.length, removedDuplicateClauses, repeatedTerms, truncated } };
}

export function autoOptimizeChunkScenePrompts(workflow: ProductionWorkflow, chunk: number): { workflow: ProductionWorkflow; summary: ChunkPromptOptimization } {
  assertChunk(chunk);
  const targets = workflow.scenes.filter((scene) => scene.chunk === chunk && scene.enImagePrompt.trim());
  if (!targets.length) throw new Error(`청크 ${chunk}에 자동 보정할 영어 프롬프트가 없습니다.`);
  const reports = new Map(targets.map((scene) => {
    const optimized = optimizeImagePrompt(scene.enImagePrompt);
    return [scene.number, { ...optimized, sceneNumber: scene.number }];
  }));
  const next = invalidateDownstream(workflow, "visualization", `청크 ${chunk}의 프롬프트 길이·중복어를 자동 보정했습니다.`);
  next.scenes = next.scenes.map((scene) => {
    const report = reports.get(scene.number);
    if (!report) return scene;
    const changed = scene.enImagePrompt !== report.prompt;
    const snapshot: PromptOptimizationSnapshot = {
      id: id("prompt-optimization"),
      createdAt: now(),
      beforePrompt: scene.enImagePrompt,
      afterPrompt: report.prompt,
      result: report.result,
    };
    return { ...scene, enImagePrompt: report.prompt, promptSource: "manual", promptGeneratedAt: null, promptModel: "auto-optimized", promptOptimizationHistory: changed ? [...scene.promptOptimizationHistory, snapshot] : scene.promptOptimizationHistory };
  });
  next.stages.visualization = { ...next.stages.visualization, status: "NEEDS_REVIEW", invalidatedReason: null };
  next.updatedAt = now();
  const results = Array.from(reports.values()).map(({ prompt: _prompt, result, sceneNumber }) => ({ sceneNumber, ...result }));
  return { workflow: next, summary: { chunk, changedCount: results.filter((result) => result.originalLength !== result.optimizedLength || result.removedDuplicateClauses > 0).length, results } };
}

export function restorePromptBeforeOptimization(workflow: ProductionWorkflow, sceneNumber: number, snapshotId?: string) {
  const scene = workflow.scenes.find((entry) => entry.number === sceneNumber);
  if (!scene) throw new Error(`장면 ${sceneNumber}을 찾을 수 없습니다.`);
  const snapshot = snapshotId ? scene.promptOptimizationHistory.find((entry) => entry.id === snapshotId) : scene.promptOptimizationHistory.at(-1);
  if (!snapshot) throw new Error(`장면 ${sceneNumber}의 복구할 자동 보정 이력이 없습니다.`);
  const next = invalidateDownstream(workflow, "visualization", `장면 ${sceneNumber} 프롬프트를 자동 보정 전 상태로 되돌렸습니다.`);
  next.scenes = next.scenes.map((entry) => entry.number === sceneNumber ? { ...entry, enImagePrompt: snapshot.beforePrompt, promptSource: "manual", promptGeneratedAt: null, promptModel: "optimization-reverted" } : entry);
  next.stages.visualization = { ...next.stages.visualization, status: "NEEDS_REVIEW", invalidatedReason: null };
  next.updatedAt = now();
  return next;
}

export function applyGeneratedChunkScenePrompts(workflow: ProductionWorkflow, chunk: number, prompts: Array<{ sceneNumber: number; prompt: string }>, model: string) {
  if (!Number.isInteger(chunk) || chunk < 1 || chunk > 21) throw new Error("청크 번호는 1부터 21 사이여야 합니다.");
  const expected = workflow.scenes.filter((scene) => scene.chunk === chunk).map((scene) => scene.number);
  const incoming = new Map(prompts.map((entry) => [entry.sceneNumber, entry.prompt.trim()]));
  if (incoming.size !== expected.length || expected.some((number) => !incoming.get(number))) throw new Error(`청크 ${chunk}의 장면 프롬프트가 누락되었거나 잘못 연결됐습니다.`);
  expected.forEach((number) => {
    const prompt = incoming.get(number) ?? "";
    if (prompt.length < 240 || prompt.length > 3_200) throw new Error(`청크 ${chunk} 장면 ${number}의 고밀도 프롬프트 길이가 허용 범위를 벗어났습니다.`);
    if (prompt.replace(/[^a-z]/gi, "").length < 20 || !/no text/i.test(prompt)) throw new Error(`청크 ${chunk} 장면 ${number}의 고밀도 프롬프트 구조가 올바르지 않습니다.`);
  });
  const next = invalidateDownstream(workflow, "visualization", `청크 ${chunk}의 고밀도 시각화 프롬프트를 생성했습니다.`);
  const generatedAt = now();
  next.scenes = next.scenes.map((scene) => scene.chunk === chunk ? { ...scene, enImagePrompt: incoming.get(scene.number) ?? "", promptSource: "generated", promptGeneratedAt: generatedAt, promptModel: model } : scene);
  next.stages.visualization = { ...next.stages.visualization, status: "NEEDS_REVIEW", invalidatedReason: null };
  next.updatedAt = generatedAt;
  return next;
}

export function updateSceneImage(workflow: ProductionWorkflow, sceneNumber: number, imageUrl: string) {
  const next = invalidateDownstream(workflow, "visualization", `장면 ${sceneNumber} 이미지가 생성 또는 교체됐습니다.`);
  next.scenes = next.scenes.map((scene) => scene.number === sceneNumber ? { ...scene, imageUrl, imageGeneratedAt: now() } : scene);
  next.stages.visualization = { ...next.stages.visualization, status: "NEEDS_REVIEW", invalidatedReason: null };
  next.updatedAt = now();
  return next;
}

export function regenerateFlow(workflow: ProductionWorkflow) {
  const next = invalidateDownstream(workflow, "flow", "승인 시각화에서 Flow를 전체 재생성했습니다.");
  next.flowLines = next.scenes.map((scene) => scene.enImagePrompt.trim());
  next.stages.flow = { ...next.stages.flow, status: "NEEDS_REVIEW", invalidatedReason: null };
  next.updatedAt = now();
  return next;
}

export function setVideoPrompts(workflow: ProductionWorkflow, prompts: string[]) {
  const next = invalidateDownstream(workflow, "video", "영상 프롬프트 목록이 변경됐습니다.");
  next.videoLines = prompts.map((prompt) => prompt.trim()).filter(Boolean);
  next.stages.video = { ...next.stages.video, status: "NEEDS_REVIEW", invalidatedReason: null };
  next.updatedAt = now();
  return next;
}

export function updateMetadata(workflow: ProductionWorkflow, metadata: MetadataDraft) {
  const next = invalidateDownstream(workflow, "metadata", "제목·설명란·썸네일 메타데이터가 변경됐습니다.");
  next.metadata = metadata;
  next.stages.metadata = { ...next.stages.metadata, status: "NEEDS_REVIEW", invalidatedReason: null };
  next.updatedAt = now();
  return next;
}

export function updateCharacterAsset(workflow: ProductionWorkflow, name: string, updates: Partial<CharacterAsset>) {
  const next = invalidateDownstream(workflow, "characters", `${name}의 캐릭터 시트 또는 이미지가 변경됐습니다.`);
  const sourceChanged = "imageUrl" in updates || "supportAnchor" in updates || "characterSheet" in updates || "imageReady" in updates;
  next.characters = next.characters.map((character) => character.name === name ? { ...character, ...updates, ...(sourceChanged ? { appearanceReviewStatus: "NOT_REVIEWED" as const, appearanceReviewNote: "", appearanceReviewedAt: null } : {}) } : character);
  next.stages.characters = { ...next.stages.characters, status: "NEEDS_REVIEW", invalidatedReason: null };
  next.updatedAt = now();
  return next;
}

export function batchUpdateCharacterAnchors(workflow: ProductionWorkflow, anchors: Record<string, string>) {
  const requested = Object.entries(anchors)
    .map(([name, value]) => [name, value.trim()] as const)
    .filter(([, value]) => value.length > 0);
  if (!requested.length) throw new Error("일괄 수정할 외형 앵커를 입력하세요.");
  const updates = new Map<string, string>();
  requested.forEach(([name, value]) => {
    const character = workflow.characters.find((entry) => entry.name === name);
    if (!character) throw new Error(`${name} 인물을 찾을 수 없습니다.`);
    if (value.length < 20) throw new Error(`${name}의 외형 앵커는 20자 이상이어야 합니다.`);
    updates.set(name, value);
  });
  const changedNames = Array.from(updates.entries())
    .filter(([name, value]) => workflow.characters.find((entry) => entry.name === name)?.supportAnchor !== value)
    .map(([name]) => name);
  if (!changedNames.length) throw new Error("변경된 외형 앵커가 없습니다.");
  const next = invalidateDownstream(workflow, "characters", `${changedNames.join("·")}의 공통 충돌 외형 앵커를 일괄 수정했습니다.`);
  next.characters = next.characters.map((character) => {
    const supportAnchor = updates.get(character.name);
    return supportAnchor === undefined ? character : { ...character, supportAnchor, appearanceReviewStatus: "NOT_REVIEWED" as const, appearanceReviewNote: "", appearanceReviewedAt: null };
  });
  next.stages.characters = { ...next.stages.characters, status: "NEEDS_REVIEW", invalidatedReason: null };
  next.updatedAt = now();
  return next;
}

export function resolveCommonAnchorConflict(workflow: ProductionWorkflow, conflict: CommonAnchorConflict, anchors: Record<string, string>) {
  const characterNames = conflict.characterNames.filter((name) => anchors[name]?.trim());
  if (!characterNames.length) throw new Error("공통 충돌을 수정할 인물 앵커를 입력하세요.");
  const beforeAnchors = Object.fromEntries(characterNames.map((name) => [name, workflow.characters.find((character) => character.name === name)?.supportAnchor ?? ""]));
  const afterAnchors = Object.fromEntries(characterNames.map((name) => [name, anchors[name].trim()]));
  const next = batchUpdateCharacterAnchors(workflow, afterAnchors);
  next.commonAnchorConflictHistory = [...next.commonAnchorConflictHistory, {
    id: id("common-anchor-resolution"),
    createdAt: now(),
    conflictKey: conflict.key,
    conflictMessage: conflict.message,
    characterNames,
    beforeAnchors,
    afterAnchors,
    affectedChunks: [...conflict.affectedChunks],
  }];
  next.updatedAt = now();
  return next;
}

export function restoreCommonAnchorConflictResolution(workflow: ProductionWorkflow, resolutionId: string) {
  const resolution = workflow.commonAnchorConflictHistory.find((entry) => entry.id === resolutionId);
  if (!resolution) throw new Error("복구할 공통 충돌 수정 이력을 찾을 수 없습니다.");
  return batchUpdateCharacterAnchors(workflow, resolution.beforeAnchors);
}

export function suggestCommonAnchorConflictAnchors(workflow: ProductionWorkflow, conflict: CommonAnchorConflict): Record<string, string> {
  const anchors = Object.fromEntries(conflict.characterNames.map((name, index) => {
    const character = workflow.characters.find((entry) => entry.name === name);
    const source = character?.supportAnchor.trim() ?? "";
    let suggestion = source;
    if (conflict.kind === "self_contradiction") {
      conflict.evidence.slice(1).forEach((evidence) => { suggestion = suggestion.replace(new RegExp(`\\b${evidence.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "gi"), ""); });
    } else if (conflict.kind === "duplicate_anchor" && index > 0) {
      suggestion = `${source}, distinctive ${name} silhouette`.replace(/,\s*,/g, ",");
    } else if (conflict.kind === "shared_visual_marker" && index > 0) {
      conflict.evidence.forEach((evidence) => { suggestion = suggestion.replace(new RegExp(`\\b${evidence.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "gi"), ""); });
      suggestion = `${suggestion}, distinctive ${name} silhouette`;
    }
    return [name, suggestion.replace(/\s*,\s*,+/g, ",").replace(/\s+/g, " ").replace(/^,\s*|,\s*$/g, "").trim()];
  }));
  return anchors;
}

export function reviewCharacterAppearance(workflow: ProductionWorkflow, name: string, status: Exclude<CharacterAppearanceReviewStatus, "NOT_REVIEWED">, note: string) {
  const next = clone(workflow);
  next.characters = next.characters.map((character) => character.name === name ? { ...character, appearanceReviewStatus: status, appearanceReviewNote: note.trim(), appearanceReviewedAt: now() } : character);
  next.updatedAt = now();
  return next;
}

export function buildFinalScriptExport(title: string, fingerprint: string, chunks: Record<number, { content: string }>, edits: Record<number, string>): FinalScriptExport {
  const exportedChunks = Array.from({ length: 21 }, (_, index) => {
    const chunk = index + 1;
    return { chunk, content: edits[chunk] ?? chunks[chunk]?.content ?? "", edited: Boolean(edits[chunk]) };
  });
  return {
    schemaVersion: "1.0",
    exportedAt: now(),
    title,
    scriptFingerprint: fingerprint,
    chunks: exportedChunks,
    sentences: deriveScriptSentences(chunks, edits),
  };
}

export function buildVisualizationExport(workflow: ProductionWorkflow): VisualizationExport {
  return {
    schemaVersion: "1.0",
    exportedAt: now(),
    title: workflow.title,
    scriptFingerprint: workflow.scriptFingerprint,
    stage: clone(workflow.stages.visualization),
    scenes: workflow.scenes.map((scene, index) => ({ ...scene, flowPrompt: workflow.flowLines[index] ?? null, videoPrompt: workflow.videoLines[index] ?? null })),
  };
}

export function buildVisualizationChunkExport(workflow: ProductionWorkflow, chunk: number): VisualizationChunkExport {
  if (!Number.isInteger(chunk) || chunk < 1 || chunk > 21) throw new Error("청크 번호는 1부터 21 사이여야 합니다.");
  return {
    schemaVersion: "1.1",
    exportedAt: now(),
    title: workflow.title,
    scriptFingerprint: workflow.scriptFingerprint,
    chunk,
    scenes: workflow.scenes.filter((scene) => scene.chunk === chunk).map((scene) => {
      const index = workflow.scenes.findIndex((entry) => entry.number === scene.number);
      return { ...scene, flowPrompt: workflow.flowLines[index] ?? null, videoPrompt: workflow.videoLines[index] ?? null };
    }),
  };
}

function assertChunk(chunk: number) {
  if (!Number.isInteger(chunk) || chunk < 1 || chunk > 21) throw new Error("청크 번호는 1부터 21 사이여야 합니다.");
}

const anchorStopWords = new Set(["adult", "young", "male", "female", "korean", "with", "wearing", "the", "and", "for", "from", "that", "this", "his", "her", "their", "dark", "light"]);

function anchorKeywords(anchor: string) {
  return Array.from(new Set(
    anchor.toLowerCase().match(/[a-z][a-z-]{2,}/g)?.filter((word) => !anchorStopWords.has(word)) ?? [],
  ));
}

const anchorConflictGroups = [
  { label: "성별", values: ["male", "female"] },
  { label: "머리색", values: ["black hair", "white hair", "silver hair", "gray hair", "brown hair", "red hair", "blonde hair"] },
  { label: "도포 색", values: ["navy robe", "white robe", "black robe", "red robe", "green robe"] },
  { label: "극단 연령", values: ["child", "young boy", "young girl", "elderly", "aged", "old"] },
] as const;

const anchorDistinctiveMarkers = ["scarred jaw", "eyepatch", "silver hair", "white hair", "navy robe", "white robe", "black robe", "red robe", "wooden pole", "long sword", "spear", "bow"];

function normalizedAnchor(value: string) {
  return value.toLowerCase().replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
}

function matchedAnchorValues(anchor: string, values: readonly string[]) {
  const source = normalizedAnchor(anchor);
  return values.filter((value) => new RegExp(`\\b${value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`).test(source));
}

export function auditSceneAnchorConflicts(workflow: ProductionWorkflow, chunk: number): ChunkAnchorConflictAudit {
  assertChunk(chunk);
  const conflicts: SceneAnchorConflict[] = [];
  workflow.scenes.filter((scene) => scene.chunk === chunk).forEach((scene) => {
    const participants = workflow.characters.filter((character) => character.importance === "main" && character.supportAnchor.trim() && scene.koText.includes(character.name));
    participants.forEach((character) => {
      anchorConflictGroups.forEach((group) => {
        const matched = matchedAnchorValues(character.supportAnchor, group.values);
        if (matched.length > 1) conflicts.push({ sceneNumber: scene.number, characterNames: [character.name], severity: "error", kind: "self_contradiction", message: `${character.name}의 ${group.label} 앵커가 서로 모순됩니다.`, evidence: matched });
      });
    });
    const normalized = participants.map((character) => ({ name: character.name, anchor: normalizedAnchor(character.supportAnchor) })).filter((entry) => entry.anchor);
    normalized.forEach((entry, index) => {
      normalized.slice(index + 1).forEach((other) => {
        if (entry.anchor === other.anchor) conflicts.push({ sceneNumber: scene.number, characterNames: [entry.name, other.name], severity: "error", kind: "duplicate_anchor", message: `${entry.name}과 ${other.name}의 외형 앵커가 동일해 생성 이미지에서 인물이 합쳐질 수 있습니다.`, evidence: [entry.anchor] });
      });
    });
    anchorDistinctiveMarkers.forEach((marker) => {
      const names = participants.filter((character) => normalizedAnchor(character.supportAnchor).includes(marker)).map((character) => character.name);
      if (names.length > 1) conflicts.push({ sceneNumber: scene.number, characterNames: names, severity: "warning", kind: "shared_visual_marker", message: `${names.join("·")}이(가) ${marker} 표식을 함께 사용합니다. 장면 프롬프트에서 인물별 위치·행동을 분리하세요.`, evidence: [marker] });
    });
  });
  return { chunk, conflicts };
}

export function auditCommonAnchorConflicts(workflow: ProductionWorkflow): CommonAnchorConflict[] {
  const grouped = new Map<string, CommonAnchorConflict>();
  for (let chunk = 1; chunk <= 21; chunk += 1) {
    auditSceneAnchorConflicts(workflow, chunk).conflicts.forEach((conflict) => {
      const characterNames = [...conflict.characterNames].sort();
      const evidence = [...conflict.evidence].sort();
      const key = [conflict.kind, characterNames.join("|"), evidence.join("|")].join("::");
      const current = grouped.get(key);
      if (current) {
        if (!current.affectedChunks.includes(chunk)) current.affectedChunks.push(chunk);
        if (!current.affectedSceneNumbers.includes(conflict.sceneNumber)) current.affectedSceneNumbers.push(conflict.sceneNumber);
        current.occurrenceCount += 1;
        if (conflict.severity === "error") current.severity = "error";
        return;
      }
      grouped.set(key, {
        key,
        kind: conflict.kind,
        severity: conflict.severity,
        characterNames,
        evidence,
        message: conflict.message,
        affectedChunks: [chunk],
        affectedSceneNumbers: [conflict.sceneNumber],
        occurrenceCount: 1,
      });
    });
  }
  return Array.from(grouped.values())
    .filter((entry) => entry.affectedChunks.length > 1)
    .map((entry) => ({ ...entry, affectedChunks: entry.affectedChunks.sort((a, b) => a - b), affectedSceneNumbers: entry.affectedSceneNumbers.sort((a, b) => a - b) }))
    .sort((left, right) => right.affectedChunks.length - left.affectedChunks.length || right.occurrenceCount - left.occurrenceCount);
}

export function estimateChunkGeneration(workflow: ProductionWorkflow, chunk: number): ChunkGenerationEstimate {
  assertChunk(chunk);
  const scenes = workflow.scenes.filter((scene) => scene.chunk === chunk);
  return {
    chunk,
    sceneCount: scenes.length,
    densePromptRequestCount: scenes.some((scene) => !scene.enImagePrompt.trim()) ? 1 : 0,
    imageGenerationRequestCount: scenes.filter((scene) => scene.enImagePrompt.trim() && !scene.imageUrl).length,
    generatedImageCount: scenes.filter((scene) => Boolean(scene.imageUrl)).length,
    imageModel: "GPT Image 2",
    imageQuality: "medium",
  };
}

export function auditChunkAppearance(workflow: ProductionWorkflow, chunk: number): ChunkAppearanceAudit {
  assertChunk(chunk);
  const chunkScenes = workflow.scenes.filter((scene) => scene.chunk === chunk && scene.enImagePrompt.trim());
  const checks = workflow.characters.filter((character) => character.importance === "main").map((character) => {
    const keywords = anchorKeywords(character.supportAnchor);
    if (!keywords.length) return { name: character.name, sceneCount: 0, score: null, matchedKeywords: [], missingKeywords: [], status: "anchor_missing" as const };
    const relevantScenes = chunkScenes.filter((scene) => scene.koText.includes(character.name) || scene.enImagePrompt.toLowerCase().includes(character.name.toLowerCase()));
    if (!relevantScenes.length) return { name: character.name, sceneCount: 0, score: null, matchedKeywords: [], missingKeywords: [], status: "not_in_chunk" as const };
    const source = relevantScenes.map((scene) => scene.enImagePrompt.toLowerCase()).join(" ");
    const matchedKeywords = keywords.filter((keyword) => source.includes(keyword));
    const missingKeywords = keywords.filter((keyword) => !matchedKeywords.includes(keyword));
    return {
      name: character.name,
      sceneCount: relevantScenes.length,
      score: Math.round((matchedKeywords.length / keywords.length) * 100),
      matchedKeywords,
      missingKeywords,
      status: "checked" as const,
    };
  });
  const scored = checks.filter((check) => check.score !== null).map((check) => check.score ?? 0);
  return { chunk, overallScore: scored.length ? Math.round(scored.reduce((sum, score) => sum + score, 0) / scored.length) : null, checks };
}

export function buildFlowChunkExport(workflow: ProductionWorkflow, chunk: number): FlowChunkExport {
  assertChunk(chunk);
  if (workflow.stages.visualization.status !== "APPROVED") throw new Error("Flow 청크 파일은 시각화 승인 후에 내보낼 수 있습니다.");
  const scenes = workflow.scenes.filter((scene) => scene.chunk === chunk);
  if (!scenes.length || scenes.some((scene) => !scene.enImagePrompt.trim())) throw new Error(`청크 ${chunk}에 Flow로 내보낼 고밀도 프롬프트가 부족합니다.`);
  return {
    schemaVersion: "1.0",
    exportedAt: now(),
    title: workflow.title,
    scriptFingerprint: workflow.scriptFingerprint,
    chunk,
    lines: scenes.map((scene) => ({ sceneNumber: scene.number, scriptSentenceIds: [...scene.scriptSentenceIds], prompt: scene.enImagePrompt.trim() })),
  };
}

export function buildFlowChunkZipBundle(workflow: ProductionWorkflow, chunk: number): FlowChunkZipBundle {
  const payload = buildFlowChunkExport(workflow, chunk);
  const prefix = `${payload.title.replace(/\s+/g, "_")}_청크_${String(chunk).padStart(2, "0")}_Flow`;
  return {
    filename: `${prefix}_묶음.zip`,
    files: {
      [`${prefix}.txt`]: payload.lines.map((line) => line.prompt).join("\n"),
      [`${prefix}_장면_ID_매핑.json`]: JSON.stringify(payload, null, 2),
    },
  };
}

function csvCell(value: string | number) {
  return `"${String(value).replace(/"/g, '""')}"`;
}

export function buildFlowMultiChunkZipBundle(workflow: ProductionWorkflow, chunks: number[]): FlowMultiChunkZipBundle {
  const selected = Array.from(new Set(chunks)).sort((a, b) => a - b);
  if (!selected.length) throw new Error("일괄 내보낼 청크를 하나 이상 선택하세요.");
  selected.forEach(assertChunk);
  const bundles = selected.map((chunk) => buildFlowChunkZipBundle(workflow, chunk));
  const titlePrefix = workflow.title.replace(/\s+/g, "_");
  const csvRows = ["title,chunk,scene_number,script_sentence_ids,prompt"];
  selected.forEach((chunk) => {
    const payload = buildFlowChunkExport(workflow, chunk);
    payload.lines.forEach((line) => csvRows.push([workflow.title, payload.chunk, line.sceneNumber, line.scriptSentenceIds.join("|"), line.prompt].map(csvCell).join(",")));
  });
  return {
    filename: `${titlePrefix}_청크_${selected.map((chunk) => String(chunk).padStart(2, "0")).join("-")}_Flow_일괄_묶음.zip`,
    files: { ...Object.assign({}, ...bundles.map((bundle) => bundle.files)), [`${titlePrefix}_Flow_전체_장면_매핑.csv`]: csvRows.join("\n") },
    chunks: selected,
  };
}

export function zipFlowChunkBundle(bundle: FlowChunkZipBundle) {
  return zipSync(Object.fromEntries(Object.entries(bundle.files).map(([filename, content]) => [filename, strToU8(content)])), { level: 6 });
}

export function zipFlowMultiChunkBundle(bundle: FlowMultiChunkZipBundle) {
  return zipSync(Object.fromEntries(Object.entries(bundle.files).map(([filename, content]) => [filename, strToU8(content)])), { level: 6 });
}
