/**
 * 강물의 장부 디자인: 한 번 저장한 원고도 강물처럼 사라지지 않도록,
 * 청크별 수정 순간을 작은 장부 행으로 보관하고 되돌릴 길을 남긴다.
 */

export type DraftVersion = {
  id: string;
  chunk: number;
  content: string;
  savedAt: string;
  reason: "수정본 저장" | "복원 전 자동 보관" | "버전 복원";
  characterCount: number;
  note?: string;
  pinned?: boolean;
};

export type DraftVersions = Record<number, DraftVersion[]>;

const MAX_VERSIONS_PER_CHUNK = 20;

function visibleCount(content: string) {
  return content.replace(/\s+/g, "").length;
}

export function captureDraftVersion(previous: DraftVersions, chunk: number, content: string, reason: DraftVersion["reason"], note?: string): DraftVersions {
  const current = previous[chunk] ?? [];
  const cleanNote = note?.trim().slice(0, 48) || undefined;
  if (!content.trim()) return previous;
  if (current.at(-1)?.content === content) {
    if (!cleanNote || current.at(-1)?.note === cleanNote) return previous;
    const last = current.at(-1)!;
    return { ...previous, [chunk]: [...current.slice(0, -1), { ...last, note: cleanNote }] };
  }
  const version: DraftVersion = {
    id: `${chunk}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    chunk,
    content,
    savedAt: new Date().toISOString(),
    reason,
    characterCount: visibleCount(content),
    note: cleanNote,
  };
  return { ...previous, [chunk]: [...current, version].slice(-MAX_VERSIONS_PER_CHUNK) };
}

export function toggleDraftVersionPin(previous: DraftVersions, chunk: number, versionId: string): DraftVersions {
  const current = previous[chunk] ?? [];
  return { ...previous, [chunk]: current.map((version) => version.id === versionId ? { ...version, pinned: !version.pinned } : version) };
}

export function findDraftVersions(versions: DraftVersion[], query: string) {
  const needle = query.trim().toLocaleLowerCase("ko-KR");
  return [...versions]
    .filter((version) => !needle || `${version.note ?? ""} ${version.reason}`.toLocaleLowerCase("ko-KR").includes(needle))
    .sort((left, right) => Number(Boolean(right.pinned)) - Number(Boolean(left.pinned)) || new Date(right.savedAt).getTime() - new Date(left.savedAt).getTime());
}

export function lineDiff(before: string, after: string) {
  const beforeLines = before.split("\n");
  const afterLines = after.split("\n");
  return Array.from({ length: Math.max(beforeLines.length, afterLines.length) }, (_, index) => ({
    line: index + 1,
    before: beforeLines[index] ?? "",
    after: afterLines[index] ?? "",
  })).filter((row) => row.before !== row.after);
}
