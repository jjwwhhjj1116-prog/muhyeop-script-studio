/**
 * 강물의 장부 디자인: 상태 장부는 대본과 분리된 사실 기록이다.
 * 이 모듈은 문장을 생성하지 않고, 청크 종료 상태만 정본·직전 장부와 대조한다.
 */
import type { ValidationIssue } from "./continuityValidator";

export type StateCharacter = {
  alive?: boolean;
  body_age?: number;
  actual_age?: number;
  mind_age?: number;
  injuries?: string[];
  possessions?: string[];
  abilities_used?: Record<string, number>;
};

export type StateRelationship = { stage?: number; label?: string; evidence?: string[] };

export type StateLedger = {
  chunk?: number;
  phase?: string;
  location?: string;
  time?: string;
  characters?: Record<string, StateCharacter>;
  relationships?: Record<string, StateRelationship>;
  world?: Record<string, unknown>;
  plot?: Record<string, unknown>;
  chunk_boundary?: { last_actions?: string[]; last_location?: string; next_required_end_state?: string };
  canon_events_this_chunk?: string[];
  notes_for_next_chunk?: string[];
};

export type StateLedgers = Record<number, StateLedger>;

export type StateValidationResult = {
  errors: ValidationIssue[];
  warnings: ValidationIssue[];
  checkedChunks: number;
  missingChunks: number[];
};

const chunks = Array.from({ length: 21 }, (_, index) => index + 1);
const ageCheckpoints: Record<number, Record<string, Record<string, number | boolean>>> = {
  1: { 강무진: { body_age: 24 }, 단여령: { body_age: 26 }, 복아: { mind_age: 20, body_age: 70 }, 백야: { body_age: 37 }, 위천록: { actual_age: 143, body_age: 32 } },
  5: { 강무진: { body_age: 34 }, 단여령: { body_age: 26 }, 복아: { mind_age: 20, body_age: 70 }, 백야: { body_age: 37 } },
  11: { 강무진: { body_age: 44 }, 단여령: { body_age: 26 }, 복아: { mind_age: 20, body_age: 70 }, 백야: { body_age: 37 } },
  15: { 강무진: { body_age: 54 }, 단여령: { body_age: 26 }, 복아: { mind_age: 20, body_age: 70 }, 백야: { body_age: 37 } },
  20: { 강무진: { body_age: 74 }, 단여령: { body_age: 46 }, 복아: { mind_age: 20, body_age: 70 }, 백야: { body_age: 47 }, 위천록: { actual_age: 143, body_age: 143, alive: false } },
  21: { 강무진: { body_age: 74 }, 단여령: { body_age: 46 }, 복아: { mind_age: 20, body_age: 20 }, 백야: { body_age: 47 }, 위천록: { alive: false } },
};

const relationshipMaxStage: Record<string, Record<number, number>> = {
  "강무진|단여령": { 1: 1, 5: 2, 10: 4, 11: 5, 15: 7, 20: 8, 21: 9 },
  "강무진|백야": { 4: 4, 10: 5, 11: 6, 15: 7, 20: 8 },
  "강무진|복아": { 1: 1, 5: 2, 7: 4, 20: 5, 21: 6 },
  "강무진|위천록": { 11: 3, 12: 4, 20: 6 },
};

const abilityTotals: Record<string, Record<number, number>> = {
  요광개로: { 5: 1, 11: 2, 15: 3, 20: 3, 21: 3 },
  칠성도강: { 20: 1, 21: 1 },
};

const deathChunks: Record<string, number> = { 허담: 11, 노철산: 18, 위천록: 20 };

function issue(list: ValidationIssue[], level: "error" | "warning", code: string, chunk: number, message: string, detail?: string) {
  list.push({ level, code, chunk, message, detail });
}

function checkpointValue(limits: Record<number, number>, chunk: number) {
  const eligible = Object.keys(limits).map(Number).filter((point) => point <= chunk);
  return eligible.length ? limits[Math.max(...eligible)] : undefined;
}

function asArray(value: unknown) {
  return Array.isArray(value) && value.every((item) => typeof item === "string") ? value : [];
}

function hasTransitionEvidence(state: StateLedger) {
  return asArray(state.canon_events_this_chunk).length > 0 || asArray(state.notes_for_next_chunk).length > 0 || asArray(state.chunk_boundary?.last_actions).length > 0;
}

export function validateStateLedgers(ledgers: StateLedgers): StateValidationResult {
  const errors: ValidationIssue[] = [];
  const warnings: ValidationIssue[] = [];
  const available = chunks.filter((chunk) => Boolean(ledgers[chunk]));
  const missingChunks = chunks.filter((chunk) => !ledgers[chunk]);

  missingChunks.forEach((chunk) => issue(errors, "error", "state_missing", chunk, `청크 ${String(chunk).padStart(2, "0")} 상태 장부 JSON이 없습니다.`));

  chunks.forEach((chunk) => {
    const state = ledgers[chunk];
    if (!state) return;
    if (state.chunk !== chunk) issue(errors, "error", "state_chunk", chunk, `장부의 chunk 값은 ${chunk}이어야 하나 ${String(state.chunk)}입니다.`);
    if (!state.characters || typeof state.characters !== "object") {
      issue(errors, "error", "state_schema", chunk, "characters 객체가 필요합니다.");
      return;
    }
    if (!state.relationships || typeof state.relationships !== "object") issue(errors, "error", "relationship_schema", chunk, "relationships 객체가 필요합니다.");
    if (!state.chunk_boundary || typeof state.chunk_boundary !== "object") issue(warnings, "warning", "boundary_schema", chunk, "chunk_boundary가 없어 다음 청크 연결 상태를 확인할 수 없습니다.");

    const expectedAges = ageCheckpoints[chunk] ?? {};
    Object.entries(expectedAges).forEach(([name, fields]) => {
      const character = state.characters?.[name];
      if (!character || typeof character !== "object") {
        issue(errors, "error", "state_character_missing", chunk, `정본 검수 대상 인물 ${name}이 장부에 없습니다.`);
        return;
      }
      Object.entries(fields).forEach(([field, expected]) => {
        if (character[field as keyof StateCharacter] !== expected) issue(errors, "error", "age_checkpoint", chunk, `${name}.${field} 값은 ${String(expected)}이어야 하나 ${String(character[field as keyof StateCharacter])}입니다.`);
      });
    });

    const previous = chunk > 1 ? ledgers[chunk - 1] : undefined;
    if (previous?.characters) {
      Object.entries(state.characters).forEach(([name, current]) => {
        const before = previous.characters?.[name];
        if (!before || !current) return;
        (["body_age", "actual_age", "mind_age"] as const).forEach((field) => {
          const oldValue = before[field];
          const newValue = current[field];
          const bokAhEndingException = name === "복아" && field === "body_age" && chunk === 21 && oldValue === 70 && newValue === 20;
          if (typeof oldValue === "number" && typeof newValue === "number" && newValue < oldValue && !bokAhEndingException) issue(errors, "error", "age_reversal", chunk, `${name}.${field}가 ${oldValue}에서 ${newValue}로 감소했습니다.`);
        });
        if (before.alive === false && current.alive !== false) issue(errors, "error", "resurrection", chunk, `${name}은 이전 청크에서 사망했는데 다시 생존 상태입니다.`);

        const lostPossessions = asArray(before.possessions).filter((item) => !asArray(current.possessions).includes(item));
        if (lostPossessions.length && !hasTransitionEvidence(state)) issue(warnings, "warning", "possession_transition", chunk, `${name}의 소지품 '${lostPossessions.join(", ")}'이 사라졌으나 사건·전환 기록이 없습니다.`);
        const healedInjuries = asArray(before.injuries).filter((item) => !asArray(current.injuries).includes(item));
        if (healedInjuries.length && !hasTransitionEvidence(state)) issue(warnings, "warning", "injury_transition", chunk, `${name}의 부상 '${healedInjuries.join(", ")}'이 사라졌으나 회복 기록이 없습니다.`);
      });
    }

    const hero = state.characters.강무진;
    const priorHero = previous?.characters?.강무진;
    if (!hero?.abilities_used || typeof hero.abilities_used !== "object") {
      issue(errors, "error", "ability_ledger", chunk, "강무진.abilities_used 객체가 필요합니다.");
    } else {
      Object.entries(abilityTotals).forEach(([ability, checkpoints]) => {
        const expected = checkpoints[chunk];
        const current = hero.abilities_used?.[ability];
        if (expected !== undefined && current !== expected) issue(errors, "error", "ability_count", chunk, `${ability} 누적 사용 횟수는 ${expected}회여야 하나 ${String(current)}회입니다.`);
        const previousTotal = priorHero?.abilities_used?.[ability];
        if (typeof current === "number" && typeof previousTotal === "number" && current < previousTotal) issue(errors, "error", "ability_count_reversal", chunk, `${ability} 누적 횟수가 이전 청크보다 감소했습니다.`);
      });
    }

    Object.entries(deathChunks).forEach(([name, deathChunk]) => {
      const character = state.characters?.[name];
      if (!character) return;
      if (chunk >= deathChunk && character.alive !== false) issue(errors, "error", "death_lock", chunk, `${name}은 청크 ${String(deathChunk).padStart(2, "0")} 이후 사망 상태여야 합니다.`);
      if (chunk < deathChunk && character.alive === false) issue(warnings, "warning", "early_death", chunk, `${name}의 사망 시점이 정본 청크 ${String(deathChunk).padStart(2, "0")}보다 빠릅니다.`);
    });

    Object.entries(relationshipMaxStage).forEach(([pair, limits]) => {
      const relationship = state.relationships?.[pair];
      if (!relationship) return;
      const allowed = checkpointValue(limits, chunk);
      if (typeof relationship.stage === "number" && allowed !== undefined && relationship.stage > allowed) issue(errors, "error", "relationship_jump", chunk, `${pair} 관계 단계 ${relationship.stage}는 청크 ${String(chunk).padStart(2, "0")}의 최대 허용 단계 ${allowed}를 넘습니다.`);
      const before = previous?.relationships?.[pair];
      if (typeof relationship.stage === "number" && typeof before?.stage === "number" && relationship.stage !== before.stage && !asArray(relationship.evidence).length) issue(warnings, "warning", "relationship_evidence", chunk, `${pair} 관계 단계가 ${before.stage}에서 ${relationship.stage}로 변했으나 evidence가 비어 있습니다.`);
    });
  });

  return { errors, warnings, checkedChunks: available.length, missingChunks };
}
