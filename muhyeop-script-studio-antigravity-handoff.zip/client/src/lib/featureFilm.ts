export type FeatureFilmSource = Record<number, { content: string }>;

export function buildFeatureFilmMarkdown(sourceChunks: FeatureFilmSource, editedChunks: Record<number, string> = {}) {
  const chunks = Array.from({ length: 21 }, (_, index) => index + 1);
  const missing = chunks.filter((chunk) => !sourceChunks[chunk]?.content?.trim());
  if (missing.length) throw new Error(`청크 ${missing.join(", ")} 원고가 없습니다.`);

  const revisedChunks = chunks.filter((chunk) => Boolean(editedChunks[chunk]));
  const chapterList = chunks
    .map((chunk) => `- 청크 ${String(chunk).padStart(2, "0")} · ${editedChunks[chunk] ? "수정본" : "정본 원고"}`)
    .join("\n");
  const merged = chunks
    .map((chunk) => {
      const chapter = editedChunks[chunk] ?? sourceChunks[chunk].content;
      const cleanChapter = chapter.replace(/^칠성탈명록\s*$/gim, "").trim();
      return `<!-- CHUNK ${String(chunk).padStart(2, "0")} / 21 -->\n\n${cleanChapter}`;
    })
    .join("\n\n---\n\n");

  return `# 칠성탈명록\n\n> 21개 청크의 현재 원고를 번호순으로 병합한 장편 마크다운입니다.\n> 수정본 ${revisedChunks.length}개를 포함합니다.\n\n## 병합 구성\n\n${chapterList}\n\n---\n\n${merged}`;
}
