import { AlertTriangle, CheckCircle2, ChevronLeft, ChevronRight, Clapperboard, Eye, FileDown, FileImage, FileJson, Film, GitBranch, Image, ListChecks, LoaderCircle, LockKeyhole, RefreshCw, ShieldCheck, Sparkles, Workflow, X } from "lucide-react";
import { ChangeEvent, useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { applyGeneratedChunkScenePrompts, approveStage, auditChunkAppearance, auditCommonAnchorConflicts, auditProduction, auditSceneAnchorConflicts, autoOptimizeChunkScenePrompts, batchUpdateCharacterAnchors, buildFinalScriptExport, buildFlowChunkZipBundle, buildFlowMultiChunkZipBundle, buildScenePlan, buildVisualizationChunkExport, buildVisualizationExport, createProductionWorkflow, deriveScriptSentences, estimateChunkGeneration, invalidateDownstream, normalizeProductionWorkflow, regenerateFlow, resolveCommonAnchorConflict, restoreCommonAnchorConflictResolution, restorePromptBeforeOptimization, reviewCharacterAppearance, setStageReview, setVideoPrompts, stageLabels, STAGE_KEYS, suggestCommonAnchorConflictAnchors, type CharacterAsset, type CommonAnchorConflict, type ChunkPromptOptimization, type ProductionStage, type ProductionWorkflow, type StageStatus, updateCharacterAsset, updateMetadata, updateSceneImage, updateScenePrompt, validateCharacterAssets, validateMetadata, zipFlowChunkBundle, zipFlowMultiChunkBundle } from "@/lib/productionWorkflow";

const STORAGE_KEY = "chilseong-production-workflow-v1";

type ImportedChunk = { content: string };

type ProductionPipelineProps = {
  title: string;
  importedChunks: Record<number, ImportedChunk>;
  editedChunks: Record<number, string>;
  scriptFingerprint: string;
  scriptReady: boolean;
};

const statusLabel: Record<StageStatus, string> = {
  NOT_STARTED: "대기",
  IN_PROGRESS: "진행 중",
  NEEDS_REVIEW: "검수 대기",
  APPROVED: "승인",
  INVALIDATED: "재생성 필요",
  FAILED: "실패",
};

function statusClass(status: StageStatus) {
  return status === "APPROVED" ? "is-approved" : status === "INVALIDATED" || status === "FAILED" ? "is-blocked" : status === "NEEDS_REVIEW" ? "is-review" : "";
}

export function ProductionPipeline({ title, importedChunks, editedChunks, scriptFingerprint, scriptReady }: ProductionPipelineProps) {
  const [workflow, setWorkflow] = useState<ProductionWorkflow>(() => createProductionWorkflow(title, scriptFingerprint, deriveScriptSentences(importedChunks, editedChunks)));
  const [hydrated, setHydrated] = useState(false);
  const [scenePage, setScenePage] = useState(0);
  const [expanded, setExpanded] = useState(false);
  const [transition, setTransition] = useState<{ from: string; to: string; action: string } | null>(null);
  const [previewCharacter, setPreviewCharacter] = useState<CharacterAsset | null>(null);
  const [failedPreviewUrl, setFailedPreviewUrl] = useState<string | null>(null);
  const [generatingCharacter, setGeneratingCharacter] = useState<string | null>(null);
  const [sceneGeneration, setSceneGeneration] = useState({ running: false, current: null as number | null, completed: 0, total: 0, failed: 0 });
  const [activePromptChunk, setActivePromptChunk] = useState(1);
  const [generatingPromptChunk, setGeneratingPromptChunk] = useState<number | null>(null);
  const [promptOptimization, setPromptOptimization] = useState<ChunkPromptOptimization | null>(null);
  const [appearanceNotes, setAppearanceNotes] = useState<Record<string, string>>({});
  const [selectedFlowChunks, setSelectedFlowChunks] = useState<number[]>([]);
  const [conflictAnchorDrafts, setConflictAnchorDrafts] = useState<Record<string, string>>({});
  const [commonConflictAnchorDrafts, setCommonConflictAnchorDrafts] = useState<Record<string, string>>({});
  const [commonConflictSeverityFilter, setCommonConflictSeverityFilter] = useState<"all" | "error" | "warning">("all");
  const [commonConflictMinChunks, setCommonConflictMinChunks] = useState(2);
  const [commonConflictSort, setCommonConflictSort] = useState<"impact_desc" | "impact_asc" | "severity">("impact_desc");
  const [selectedOptimizationSnapshots, setSelectedOptimizationSnapshots] = useState<Record<number, string>>({});
  const videoInputRef = useRef<HTMLInputElement>(null);
  const lastFingerprint = useRef(scriptFingerprint);
  const transitionTimer = useRef<number | null>(null);
  const audit = useMemo(() => auditProduction(workflow), [workflow]);
  const characterImageMutation = trpc.productionImages.generateCharacter.useMutation();
  const sceneImageMutation = trpc.productionImages.generateScene.useMutation();
  const densePromptMutation = trpc.productionImages.generateDenseChunkPrompts.useMutation();
  const scenePageSize = 4;
  const chunksWithScenes = useMemo(() => Array.from(new Set(workflow.scenes.map((scene) => scene.chunk))).sort((a, b) => a - b), [workflow.scenes]);
  const activeChunkScenes = useMemo(() => workflow.scenes.filter((scene) => scene.chunk === activePromptChunk), [activePromptChunk, workflow.scenes]);
  const sceneRows = activeChunkScenes.slice(scenePage * scenePageSize, scenePage * scenePageSize + scenePageSize);
  const pageCount = Math.max(1, Math.ceil(activeChunkScenes.length / scenePageSize));
  const generatedPromptCount = activeChunkScenes.filter((scene) => scene.promptSource === "generated" && scene.enImagePrompt.trim()).length;
  const chunkEstimate = useMemo(() => estimateChunkGeneration(workflow, activePromptChunk), [activePromptChunk, workflow]);
  const chunkAppearance = useMemo(() => auditChunkAppearance(workflow, activePromptChunk), [activePromptChunk, workflow]);
  const chunkAnchorConflicts = useMemo(() => auditSceneAnchorConflicts(workflow, activePromptChunk), [activePromptChunk, workflow]);
  const commonAnchorConflicts = useMemo(() => auditCommonAnchorConflicts(workflow), [workflow]);
  const visibleCommonAnchorConflicts = useMemo(() => commonAnchorConflicts
    .filter((conflict) => (commonConflictSeverityFilter === "all" || conflict.severity === commonConflictSeverityFilter) && conflict.affectedChunks.length >= commonConflictMinChunks)
    .sort((left, right) => commonConflictSort === "impact_asc"
      ? left.affectedChunks.length - right.affectedChunks.length || left.occurrenceCount - right.occurrenceCount
      : commonConflictSort === "severity"
        ? Number(right.severity === "error") - Number(left.severity === "error") || right.affectedChunks.length - left.affectedChunks.length
        : right.affectedChunks.length - left.affectedChunks.length || right.occurrenceCount - left.occurrenceCount), [commonAnchorConflicts, commonConflictMinChunks, commonConflictSeverityFilter, commonConflictSort]);
  const flowChunkReady = workflow.stages.visualization.status === "APPROVED" && activeChunkScenes.length > 0 && activeChunkScenes.every((scene) => scene.enImagePrompt.trim());
  const flowMultiChunkReady = workflow.stages.visualization.status === "APPROVED" && selectedFlowChunks.length > 0 && selectedFlowChunks.every((chunk) => {
    const scenes = workflow.scenes.filter((scene) => scene.chunk === chunk);
    return scenes.length > 0 && scenes.every((scene) => scene.enImagePrompt.trim());
  });
  const issuesByStage = useMemo(() => workflow ? audit.issues.reduce<Record<string, number>>((acc, issue) => ({ ...acc, [issue.stage]: (acc[issue.stage] ?? 0) + 1 }), {}) : {}, [audit.issues, workflow]);

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const sentences = deriveScriptSentences(importedChunks, editedChunks);
        setWorkflow(normalizeProductionWorkflow(JSON.parse(stored) as Partial<ProductionWorkflow>, title, scriptFingerprint, sentences));
      }
    } catch {
      window.localStorage.removeItem(STORAGE_KEY);
    } finally {
      setHydrated(true);
    }
  }, []);

  useEffect(() => {
    if (hydrated) window.localStorage.setItem(STORAGE_KEY, JSON.stringify(workflow));
  }, [hydrated, workflow]);

  useEffect(() => {
    if (!hydrated) return;
    setWorkflow((current) => current.title === title ? current : { ...current, title, updatedAt: new Date().toISOString() });
  }, [hydrated, title]);

  useEffect(() => {
    if (!hydrated || lastFingerprint.current === scriptFingerprint) return;
    lastFingerprint.current = scriptFingerprint;
    showTransition("대본", "캐릭터 이후 단계", "대본 변경을 기록하고 후속 산출물을 무효화");
    setWorkflow((current) => {
      const next = invalidateDownstream(current, "script", "대본 원고 또는 수정본이 변경됐습니다.");
      next.scriptFingerprint = scriptFingerprint;
      next.sentences = deriveScriptSentences(importedChunks, editedChunks);
      next.scenes = [];
      next.flowLines = [];
      next.videoLines = [];
      next.stages.script = { ...next.stages.script, status: "NEEDS_REVIEW", invalidatedReason: null };
      return next;
    });
    toast("대본 변경을 감지했습니다.", { description: "시각화부터 최종 감사까지 자동으로 재생성 대기 상태가 됐습니다." });
  }, [editedChunks, hydrated, importedChunks, scriptFingerprint]);

  useEffect(() => () => {
    if (transitionTimer.current) window.clearTimeout(transitionTimer.current);
  }, []);

  useEffect(() => {
    if (!chunksWithScenes.length || chunksWithScenes.includes(activePromptChunk)) return;
    setActivePromptChunk(chunksWithScenes[0]);
    setScenePage(0);
  }, [activePromptChunk, chunksWithScenes]);

  const previousStage = (stageKey: ProductionStage) => {
    const index = STAGE_KEYS.indexOf(stageKey);
    return index > 0 ? STAGE_KEYS[index - 1] : null;
  };

  const canOperate = (stageKey: ProductionStage) => {
    const previous = previousStage(stageKey);
    return !previous || workflow.stages[previous].status === "APPROVED";
  };

  const approvalBlock = (stageKey: ProductionStage): string | null => {
    if (!canOperate(stageKey)) return `${stageLabels[previousStage(stageKey)!]} 승인이 먼저 필요합니다.`;
    if (stageKey === "script" && !scriptReady) return "대본 연속성 검수를 먼저 통과해야 합니다.";
    if (stageKey === "characters" && validateCharacterAssets(workflow.characters).length) return "주요 인물 레퍼런스와 보조 인물 앵커를 모두 확인해야 합니다.";
    if (stageKey === "visualization") {
      if (!workflow.scenes.length) return "대본 문장을 기준으로 시각화 골격을 먼저 생성해야 합니다.";
      if (audit.issues.some((issue) => issue.stage === "visualization" && issue.severity === "error")) return "시각화 프롬프트·문장·대사 매핑 오류를 해결해야 합니다.";
    }
    if (stageKey === "flow") {
      if (!workflow.scenes.length || workflow.flowLines.length !== workflow.scenes.length) return "시각화 장면 수와 같은 Flow 전체 재생성이 필요합니다.";
      if (audit.issues.some((issue) => issue.stage === "flow" && issue.severity === "error")) return "Flow의 빈 줄과 표식 오류를 해결해야 합니다.";
    }
    if (stageKey === "video") {
      if (!workflow.scenes.length || workflow.videoLines.length !== workflow.scenes.length) return "시각화 장면 수와 같은 무음 영상 프롬프트 파일이 필요합니다.";
      if (audit.issues.some((issue) => issue.stage === "video" && issue.severity === "error")) return "영상 프롬프트의 오디오·대사 지시를 제거해야 합니다.";
    }
    if (stageKey === "metadata" && validateMetadata(workflow.metadata).length) return "제목 세 안, 대본 근거, 타임라인, 해시태그를 모두 채워야 합니다.";
    if (stageKey === "audit") {
      const required = ["script", "characters", "visualization", "flow", "video", "metadata"] as const;
      const unapproved = required.filter((key) => workflow.stages[key].status !== "APPROVED");
      if (unapproved.length) return `최종 감사 전 ${unapproved.map((key) => stageLabels[key]).join(", ")} 승인이 필요합니다.`;
      if (!workflow.scenes.length || !workflow.flowLines.length || !workflow.videoLines.length) return "장면, Flow, 영상 프롬프트 산출물이 모두 연결돼야 합니다.";
      if (audit.issues.some((issue) => issue.severity === "error")) return "최종 감사 오류를 모두 해결해야 합니다.";
    }
    return null;
  };

  const canApprove = (stageKey: ProductionStage) => approvalBlock(stageKey) === null;

  const showTransition = (from: string, to: string, action: string) => {
    if (transitionTimer.current) window.clearTimeout(transitionTimer.current);
    setTransition({ from, to, action });
    transitionTimer.current = window.setTimeout(() => {
      setTransition(null);
      transitionTimer.current = null;
    }, 720);
  };

  const downloadJson = (filename: string, payload: unknown) => {
    const url = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: "application/json;charset=utf-8" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1500);
  };

  const downloadText = (filename: string, text: string) => {
    const url = URL.createObjectURL(new Blob([text], { type: "text/plain;charset=utf-8" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1500);
  };

  const downloadZip = (filename: string, bytes: Uint8Array) => {
    const data = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
    const url = URL.createObjectURL(new Blob([data], { type: "application/zip" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1500);
  };

  const exportFinalScriptJson = () => {
    downloadJson(`${title.replace(/\s+/g, "_")}_최종대본.json`, buildFinalScriptExport(title, scriptFingerprint, importedChunks, editedChunks));
    toast("최종 대본 JSON을 내려받았습니다.", { description: "21청크 원문·수정 여부·문장 ID를 포함합니다." });
  };

  const exportVisualizationJson = () => {
    if (!workflow.scenes.length) {
      toast("시각화 장면이 아직 없습니다.", { description: "대본 승인 뒤 시각화 골격을 먼저 생성하세요." });
      return;
    }
    downloadJson(`${title.replace(/\s+/g, "_")}_시각화_장면.json`, buildVisualizationExport(workflow));
    toast("시각화 장면 JSON을 내려받았습니다.", { description: "문장 ID, 대사 매핑, 이미지·Flow·영상 프롬프트 연결을 포함합니다." });
  };

  const exportVisualizationChunkJson = () => {
    if (!activeChunkScenes.length) {
      toast(`청크 ${activePromptChunk}의 시각화 장면이 아직 없습니다.`, { description: "대본 승인 뒤 청크별 골격을 먼저 생성하세요." });
      return;
    }
    downloadJson(`${title.replace(/\s+/g, "_")}_청크_${String(activePromptChunk).padStart(2, "0")}_고밀도_시각화.json`, buildVisualizationChunkExport(workflow, activePromptChunk));
    toast(`청크 ${activePromptChunk} 시각화 JSON을 내려받았습니다.`, { description: "이 청크의 장면·문장 ID·고밀도 프롬프트만 담아 출력 오류를 격리합니다." });
  };

  const exportFlowChunkFiles = () => {
    try {
      const bundle = buildFlowChunkZipBundle(workflow, activePromptChunk);
      downloadZip(bundle.filename, zipFlowChunkBundle(bundle));
      toast(`청크 ${activePromptChunk} Flow ZIP을 내려받았습니다.`, { description: "Flow 입력용 txt와 장면 번호·원고 ID 매핑 JSON을 하나의 ZIP으로 묶었습니다." });
    } catch (error) {
      toast(`청크 ${activePromptChunk} Flow 파일을 내보낼 수 없습니다.`, { description: error instanceof Error ? error.message : "시각화 승인 상태를 확인하세요." });
    }
  };

  const toggleFlowChunk = (chunk: number) => {
    setSelectedFlowChunks((current) => current.includes(chunk) ? current.filter((entry) => entry !== chunk) : [...current, chunk].sort((a, b) => a - b));
  };

  const exportFlowMultiChunkPackage = () => {
    try {
      const bundle = buildFlowMultiChunkZipBundle(workflow, selectedFlowChunks);
      downloadZip(bundle.filename, zipFlowMultiChunkBundle(bundle));
      toast(`${bundle.chunks.length}개 청크 Flow 일괄 ZIP을 내려받았습니다.`, { description: "청크별 txt·장면 ID JSON과 전체 장면 매핑 CSV를 함께 묶었습니다." });
    } catch (error) {
      toast("Flow 일괄 ZIP을 내보낼 수 없습니다.", { description: error instanceof Error ? error.message : "선택 청크의 프롬프트와 시각화 승인 상태를 확인하세요." });
    }
  };

  const reviewStage = (stageKey: ProductionStage) => {
    if (!canOperate(stageKey)) {
      toast(`${stageLabels[previousStage(stageKey)!]} 승인이 먼저 필요합니다.`);
      return;
    }
    showTransition(stageLabels[stageKey], "검수 대기", "승인 조건과 후속 연결 상태 확인");
    setWorkflow((current) => setStageReview(current, stageKey));
    toast(`${stageLabels[stageKey]} 단계를 검수 대기로 전환했습니다.`);
  };

  const approve = (stageKey: ProductionStage) => {
    const blocked = approvalBlock(stageKey);
    if (blocked) {
      toast(`${stageLabels[stageKey]} 승인이 잠겼습니다.`, { description: blocked });
      return;
    }
    const stageIndex = STAGE_KEYS.indexOf(stageKey);
    const nextStage = STAGE_KEYS[stageIndex + 1];
    showTransition(stageLabels[stageKey], nextStage ? stageLabels[nextStage] : "제작 완료", "승인 기록과 다음 단계 준비");
    setWorkflow((current) => approveStage(current, stageKey));
    toast(`${stageLabels[stageKey]} 단계를 승인했습니다.`, { description: nextStage ? `${stageLabels[nextStage]} 단계가 열렸습니다.` : "최종 제작 감사를 완료했습니다." });
  };

  const buildScenes = () => {
    if (workflow.stages.script.status !== "APPROVED") {
      toast("승인된 대본에서만 시각화 골격을 만들 수 있습니다.");
      return;
    }
    showTransition("대본", "시각화", "문장 ID와 직접 대사를 장면으로 매핑");
    setWorkflow((current) => buildScenePlan(current));
    setActivePromptChunk(1);
    setScenePage(0);
    toast("대본 문장 ID를 청크별 시각화 골격으로 나눴습니다.", { description: "각 청크에서 고밀도 영어 프롬프트를 별도로 생성해 오류를 해당 청크 안에 가둡니다." });
  };

  const selectPromptChunk = (chunk: number) => {
    setActivePromptChunk(chunk);
    setScenePage(0);
  };

  const generateDensePromptsForChunk = async () => {
    const chunkScript = editedChunks[activePromptChunk] ?? importedChunks[activePromptChunk]?.content ?? "";
    if (!activeChunkScenes.length || !chunkScript.trim()) {
      toast(`청크 ${activePromptChunk}의 원고 또는 장면이 없습니다.`, { description: "대본을 연결한 뒤 청크별 골격을 먼저 생성하세요." });
      return;
    }
    setGeneratingPromptChunk(activePromptChunk);
    try {
      const result = await densePromptMutation.mutateAsync({
        title,
        chunk: activePromptChunk,
        chunkScript,
        scenes: activeChunkScenes.map((scene) => ({ number: scene.number, sentenceIds: scene.scriptSentenceIds, koreanEvidence: scene.koText, dialogueEvidence: scene.dialogueIds.length ? scene.koText : undefined })),
        characters: workflow.characters.map((character) => ({ name: character.name, characterSheet: character.characterSheet || undefined, appearanceAnchor: character.supportAnchor || undefined })),
      });
      showTransition(`청크 ${activePromptChunk}`, "시각화 · Flow · 영상", `${result.prompts.length}개 고밀도 프롬프트를 장면 ID에 연결`);
      const nextWorkflow = applyGeneratedChunkScenePrompts(workflow, activePromptChunk, result.prompts, result.model);
      setWorkflow(nextWorkflow);
      toast(`청크 ${activePromptChunk} 고밀도 프롬프트를 생성했습니다.`, { description: `${result.prompts.length}개 장면을 ${result.model}으로 생성했습니다. 다른 청크는 건드리지 않습니다.` });
    } catch (error) {
      toast(`청크 ${activePromptChunk} 프롬프트 생성을 완료하지 못했습니다.`, { description: error instanceof Error ? error.message : "잠시 뒤 이 청크만 다시 시도해 주세요." });
    } finally {
      setGeneratingPromptChunk(null);
    }
  };

  const onPromptChange = (sceneNumber: number, prompt: string) => {
    showTransition("시각화", "Flow · 영상 · 메타데이터", `장면 ${sceneNumber} 프롬프트 변경을 반영하고 하위 단계를 무효화`);
    setWorkflow((current) => updateScenePrompt(current, sceneNumber, prompt));
  };

  const optimizeActiveChunkPrompts = () => {
    try {
      const result = autoOptimizeChunkScenePrompts(workflow, activePromptChunk);
      showTransition("시각화", "Flow · 영상 · 메타데이터", `청크 ${activePromptChunk} 프롬프트 길이와 중복어를 자동 보정`);
      setWorkflow(result.workflow);
      setPromptOptimization(result.summary);
      toast(`청크 ${activePromptChunk} 프롬프트를 자동 보정했습니다.`, { description: `${result.summary.changedCount}개 장면의 반복 절과 길이를 정리하고 네거티브 가드를 표준화했습니다.` });
    } catch (error) {
      toast(`청크 ${activePromptChunk} 프롬프트를 보정할 수 없습니다.`, { description: error instanceof Error ? error.message : "영어 프롬프트를 먼저 입력하세요." });
    }
  };

  const restorePromptOptimization = (sceneNumber: number, snapshotId?: string) => {
    try {
      showTransition("시각화", "Flow · 영상 · 메타데이터", `장면 ${sceneNumber}을 선택한 자동 보정 이력으로 복구`);
      setWorkflow((current) => restorePromptBeforeOptimization(current, sceneNumber, snapshotId));
      toast(`장면 ${sceneNumber} 프롬프트를 선택한 보정 전 상태로 되돌렸습니다.`);
    } catch (error) {
      toast(`장면 ${sceneNumber} 프롬프트를 되돌릴 수 없습니다.`, { description: error instanceof Error ? error.message : "보정 이력을 확인하세요." });
    }
  };

  const saveConflictAnchor = (name: string) => {
    const character = workflow.characters.find((entry) => entry.name === name);
    const nextAnchor = (conflictAnchorDrafts[name] ?? character?.supportAnchor ?? "").trim();
    if (nextAnchor.length < 20) {
      toast(`${name}의 외형 앵커가 너무 짧습니다.`, { description: "영어 외형 앵커를 20자 이상 입력하세요." });
      return;
    }
    showTransition("캐릭터", "시각화 이후 단계", `${name}의 충돌 외형 앵커 수정과 장면 재검사`);
    setWorkflow((current) => updateCharacterAsset(current, name, { supportAnchor: nextAnchor }));
    setConflictAnchorDrafts((drafts) => ({ ...drafts, [name]: nextAnchor }));
    toast(`${name}의 외형 앵커를 저장하고 충돌을 다시 검사했습니다.`, { description: "남은 경고는 즉시 갱신됩니다. 캐릭터 수정으로 시각화 이후 단계는 검수 대기가 됩니다." });
  };

  const saveCommonConflictAnchors = (conflict: CommonAnchorConflict) => {
    const anchors = Object.fromEntries(conflict.characterNames.map((name) => [name, commonConflictAnchorDrafts[name] ?? workflow.characters.find((entry) => entry.name === name)?.supportAnchor ?? ""]));
    try {
      showTransition("캐릭터", "시각화 이후 단계", `${conflict.characterNames.join("·")}의 공통 충돌 앵커를 일괄 수정하고 전체 청크 재검사`);
      const nextWorkflow = resolveCommonAnchorConflict(workflow, conflict, anchors);
      setWorkflow(nextWorkflow);
      setCommonConflictAnchorDrafts((drafts) => ({ ...drafts, ...anchors }));
      const remaining = auditCommonAnchorConflicts(nextWorkflow).length;
      toast(`${conflict.characterNames.length}명 외형 앵커를 일괄 저장하고 21청크를 다시 검사했습니다.`, { description: remaining ? `공통 충돌 ${remaining}개가 남아 있습니다. 수정 이력에서 언제든 되돌릴 수 있습니다.` : "반복 공통 충돌이 모두 해소됐습니다. 수정 이력에서 언제든 되돌릴 수 있습니다." });
    } catch (error) {
      toast("공통 충돌 앵커를 일괄 수정할 수 없습니다.", { description: error instanceof Error ? error.message : "수정할 인물 앵커를 확인하세요." });
    }
  };

  const applyCommonConflictSuggestion = (conflict: CommonAnchorConflict) => {
    const suggestions = suggestCommonAnchorConflictAnchors(workflow, conflict);
    setCommonConflictAnchorDrafts((drafts) => ({ ...drafts, ...suggestions }));
    toast("충돌 수정안을 앵커 입력칸에 채웠습니다.", { description: "인물·소지품·관계에 맞는지 확인한 뒤 일괄 수정하세요." });
  };

  const restoreCommonConflictHistory = (resolutionId: string) => {
    try {
      showTransition("캐릭터", "시각화 이후 단계", "공통 충돌 수정 이력의 이전 앵커로 복구하고 전체 청크 재검사");
      const nextWorkflow = restoreCommonAnchorConflictResolution(workflow, resolutionId);
      setWorkflow(nextWorkflow);
      toast("공통 충돌 수정 이력의 이전 앵커로 복구했습니다.", { description: "21청크 충돌 결과와 시각화 이후 단계가 갱신됐습니다." });
    } catch (error) {
      toast("공통 충돌 수정 이력을 복구할 수 없습니다.", { description: error instanceof Error ? error.message : "이력 상태를 확인하세요." });
    }
  };

  const generateFlow = () => {
    const missing = workflow.scenes.filter((scene) => !scene.enImagePrompt.trim()).length;
    if (missing) {
      toast("영어 이미지 프롬프트가 비어 있습니다.", { description: `장면 ${missing}개를 채운 뒤 전체 Flow를 재생성하세요.` });
      return;
    }
    showTransition("시각화", "Flow · 영상", "승인된 장면 프롬프트에서 전체 Flow 재생성");
    setWorkflow((current) => regenerateFlow(current));
    toast("Flow를 전체 재생성했습니다.", { description: "부분 편집은 허용하지 않으며, 시각화 변경 뒤에는 다시 전체 재생성합니다." });
  };

  const importVideoPrompts = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    showTransition("Flow", "영상 · 최종 감사", "무음 영상 프롬프트를 장면 ID에 연결");
    setWorkflow((current) => setVideoPrompts(current, text.split(/\r?\n/)));
    event.target.value = "";
    toast("영상 프롬프트를 연결했습니다.", { description: "시각화 장면 수와 무음 규칙을 즉시 대조합니다." });
  };

  const updateMetadataField = (nextMetadata: ProductionWorkflow["metadata"]) => {
    showTransition("메타데이터", "최종 감사", "제목·설명란 변경을 기록하고 최종 감사를 무효화");
    setWorkflow((current) => updateMetadata(current, nextMetadata));
  };

  const resetWorkflow = () => {
    setWorkflow(createProductionWorkflow(title, scriptFingerprint, deriveScriptSentences(importedChunks, editedChunks)));
    toast("제작 대시보드 상태를 현재 원고 기준으로 초기화했습니다.");
  };

  const updateCharacter = (index: number, updates: Partial<CharacterAsset>) => {
    const character = workflow.characters[index];
    showTransition("캐릭터", "시각화 이후 단계", `${character?.name ?? "인물"} 자산 변경을 기록하고 하위 단계를 무효화`);
    setWorkflow((current) => updateCharacterAsset(current, character?.name ?? "", updates));
  };

  const saveAppearanceReview = (name: string, status: "APPROVED" | "NEEDS_REVIEW") => {
    const character = workflow.characters.find((entry) => entry.name === name);
    if (!character?.imageUrl.trim() || !character.supportAnchor.trim()) {
      toast(`${name}의 이미지와 외형 앵커가 모두 필요합니다.`, { description: "생성 이미지를 연결하고 영어 외형 앵커를 입력한 뒤 육안으로 비교하세요." });
      return;
    }
    setWorkflow((current) => reviewCharacterAppearance(current, name, status, appearanceNotes[name] ?? character.appearanceReviewNote));
    toast(status === "APPROVED" ? `${name} 외형 비교를 승인했습니다.` : `${name} 외형 비교를 보정 필요로 기록했습니다.`);
  };

  const generateCharacterImage = async (index: number) => {
    const character = workflow.characters[index];
    if (!character?.characterSheet.trim()) {
      toast("캐릭터 시트가 필요합니다.", { description: `${character?.name ?? "인물"}의 역할·외형·의상·무기 정보를 먼저 입력하세요.` });
      return;
    }
    setGeneratingCharacter(character.name);
    try {
      const result = await characterImageMutation.mutateAsync({ title, name: character.name, characterSheet: character.characterSheet, supportAnchor: character.supportAnchor || undefined });
      showTransition("캐릭터", "시각화 이후 단계", `${character.name}의 생성 이미지를 레퍼런스 자산으로 연결`);
      setWorkflow((current) => updateCharacterAsset(current, character.name, { imageUrl: result.url, imageAlt: `${character.name} 인물 이미지`, imageReady: true, faceReferenceReady: true, fullBodyReferenceReady: true }));
      toast(`${character.name} 인물 이미지를 생성했습니다.`, { description: "미리보기에서 시트와 이미지를 함께 확인하세요." });
    } catch (error) {
      toast(`${character.name} 이미지 생성을 완료하지 못했습니다.`, { description: error instanceof Error ? error.message : "다시 시도해 주세요." });
    } finally {
      setGeneratingCharacter(null);
    }
  };

  const generateSceneImage = async (sceneNumber: number) => {
    const scene = workflow.scenes.find((entry) => entry.number === sceneNumber);
    if (!scene?.enImagePrompt.trim()) {
      toast("영어 이미지 프롬프트가 필요합니다.", { description: `장면 ${sceneNumber}의 프롬프트를 먼저 입력하세요.` });
      return false;
    }
    const result = await sceneImageMutation.mutateAsync({ title, sceneNumber, scenePrompt: scene.enImagePrompt, sceneSummary: scene.koText });
    showTransition("시각화", "Flow · 영상 · 메타데이터", `장면 ${sceneNumber} 생성 이미지를 시각화 자산에 연결`);
    setWorkflow((current) => updateSceneImage(current, sceneNumber, result.url));
    return true;
  };

  const generateAllSceneImages = async (chunk = activePromptChunk) => {
    const targets = workflow.scenes.filter((scene) => scene.chunk === chunk && scene.enImagePrompt.trim());
    if (!targets.length) {
      toast(`청크 ${chunk}에 생성할 장면 프롬프트가 없습니다.`, { description: "이 청크의 고밀도 영어 프롬프트를 먼저 생성하거나 입력하세요." });
      return;
    }
    setSceneGeneration({ running: true, current: null, completed: 0, total: targets.length, failed: 0 });
    let completed = 0;
    let failed = 0;
    for (const scene of targets) {
      setSceneGeneration({ running: true, current: scene.number, completed, total: targets.length, failed });
      try {
        await generateSceneImage(scene.number);
        completed += 1;
      } catch {
        failed += 1;
      }
      setSceneGeneration({ running: true, current: scene.number, completed, total: targets.length, failed });
    }
    setSceneGeneration({ running: false, current: null, completed, total: targets.length, failed });
    toast(`청크 ${chunk} 장면 이미지 일괄 생성을 마쳤습니다.`, { description: failed ? `${completed}개 생성 · ${failed}개 실패. 실패 장면은 이 청크에서만 재시도하세요.` : `${completed}개 장면 이미지를 시각화 자산에 연결했습니다.` });
  };

  return (
    <section className="mt-5 rounded-2xl border border-[#d9c9b8] bg-[#fffdf7] p-4 shadow-[0_16px_35px_rgba(70,50,30,0.08)] sm:p-5" aria-label="무협 장편영화 제작 대시보드">
      <input ref={videoInputRef} className="hidden" type="file" accept=".txt,text/plain" onChange={(event) => void importVideoPrompts(event)} />
      <div className="flex flex-col gap-3 border-b border-[#ebdfd1] pb-4 lg:flex-row lg:items-start lg:justify-between">
        <div className="flex gap-3"><span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#263f3e] text-[#ffe7b0]"><Workflow size={20} /></span><div><p className="text-[11px] font-semibold tracking-[0.16em] text-[#a2543d]">PRODUCTION CONTROL</p><h2 className="font-serif text-xl font-semibold text-[#202827]">한 편의 영화 제작 대시보드</h2><p className="mt-1 text-sm leading-5 text-[#6c655d]">대본, 시각화, Flow, 영상 산출물을 문장 ID와 승인 버전으로 이어 갑니다.</p></div></div>
        <div className="flex flex-wrap gap-2"><button className="rounded-lg border border-[#c9b59f] bg-[#fffaf1] px-3 py-2 text-xs font-semibold text-[#59483e] transition hover:bg-[#f5eee4]" onClick={exportFinalScriptJson}><FileJson size={13} className="mr-1 inline" />최종 대본 JSON</button><button className="rounded-lg border border-[#d7c2b0] px-3 py-2 text-xs font-semibold text-[#59483e] transition hover:bg-[#f5eee4] disabled:opacity-40" disabled={!workflow.scenes.length} onClick={exportVisualizationJson}><FileDown size={13} className="mr-1 inline" />시각화 JSON</button><button className="rounded-lg border border-[#d7c2b0] px-3 py-2 text-xs font-semibold text-[#59483e] transition hover:bg-[#f5eee4]" onClick={() => setExpanded((value) => !value)}>{expanded ? "간단히 보기" : "제작 관리 열기"}</button><button className="rounded-lg border border-[#d7c2b0] px-3 py-2 text-xs font-semibold text-[#59483e] transition hover:bg-[#f5eee4]" onClick={resetWorkflow}><RefreshCw size={13} className="mr-1 inline" />현재 원고로 초기화</button></div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4 xl:grid-cols-8">
        {STAGE_KEYS.map((stageKey, index) => {
          const current = workflow.stages[stageKey];
          return <button key={stageKey} onClick={() => setExpanded(true)} className={`rounded-xl border px-2 py-3 text-left transition hover:-translate-y-0.5 ${statusClass(current.status)} ${current.status === "APPROVED" ? "border-emerald-300 bg-emerald-50" : current.status === "INVALIDATED" ? "border-rose-300 bg-rose-50" : current.status === "NEEDS_REVIEW" ? "border-amber-300 bg-amber-50" : "border-[#e6d8c9] bg-[#fcfaf4]"}`}><span className="text-[10px] font-bold tracking-wide text-[#9a7a63]">{String(index + 1).padStart(2, "0")}</span><b className="mt-1 block text-sm text-[#2a3432]">{stageLabels[stageKey]}</b><small className="mt-1 block text-[11px] text-[#6c655d]">{statusLabel[current.status]}{issuesByStage[stageKey] ? ` · 오류 ${issuesByStage[stageKey]}` : ""}</small></button>;
        })}
      </div>

      <div className="mt-4 grid gap-3 rounded-xl bg-[#f6f0e7] p-3 text-sm sm:grid-cols-3"><div><span className="text-[#8b6956]">대본 문장</span><b className="ml-2 text-[#243331]">{audit.sentenceCount.toLocaleString()}</b></div><div><span className="text-[#8b6956]">시각화 매핑</span><b className="ml-2 text-[#243331]">{audit.mappedSentenceCount.toLocaleString()} / {audit.sentenceCount.toLocaleString()}</b></div><div><span className="text-[#8b6956]">Flow · 영상</span><b className="ml-2 text-[#243331]">{audit.flowCount} · {audit.videoCount}</b></div></div>

      {expanded && <div className="mt-5 space-y-5">
        {workflow.scenes.length > 0 && <article className="rounded-xl border border-[#d9c9b8] bg-[#fff7ee] p-4"><div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between"><div><p className="text-xs font-bold tracking-[0.12em] text-[#a2543d]">CHUNK PROMPT LAB</p><h3 className="mt-1 font-serif text-lg font-semibold text-[#263331]">청크별 고밀도 장면 프롬프트</h3><p className="mt-1 max-w-3xl text-sm leading-6 text-[#6c655d]">전체 프롬프트를 한 번에 만들지 않습니다. 선택한 청크의 원고, 장면 근거, 인물 시트와 외형 앵커만 사용해 행동, 나이 상태, 소지품, 공간, 카메라, 조명, 질감, 네거티브 가드를 한 장면씩 고밀도로 작성합니다.</p></div><div className="flex flex-wrap items-center gap-2"><select aria-label="프롬프트 청크 선택" className="rounded-lg border border-[#d7c2b0] bg-white px-3 py-2 text-xs font-semibold text-[#59483e]" value={activePromptChunk} onChange={(event) => selectPromptChunk(Number(event.target.value))}>{chunksWithScenes.map((chunk) => <option key={chunk} value={chunk}>청크 {String(chunk).padStart(2, "0")} · {workflow.scenes.filter((scene) => scene.chunk === chunk).length}장면</option>)}</select><button className="rounded-lg border border-[#bd927c] bg-white px-3 py-2 text-xs font-semibold text-[#8f3f2e] disabled:opacity-40" disabled={!activeChunkScenes.length} onClick={exportVisualizationChunkJson}><FileDown size={13} className="mr-1 inline" />이 청크 JSON</button><button className="rounded-lg border border-[#60796f] bg-[#f2f8f3] px-3 py-2 text-xs font-semibold text-[#31594f] disabled:opacity-40" disabled={!flowChunkReady} title={flowChunkReady ? undefined : "청크의 고밀도 프롬프트를 채우고 시각화 단계를 승인한 뒤 내보낼 수 있습니다."} onClick={exportFlowChunkFiles}><FileDown size={13} className="mr-1 inline" />Flow ZIP</button><button className="rounded-lg border border-[#92725e] bg-white px-3 py-2 text-xs font-semibold text-[#6d4a39] disabled:opacity-40" disabled={!activeChunkScenes.some((scene) => scene.enImagePrompt.trim())} onClick={optimizeActiveChunkPrompts}><RefreshCw size={13} className="mr-1 inline" />길이·중복 자동 보정</button><button className="rounded-lg bg-[#a34734] px-3 py-2 text-xs font-semibold text-white disabled:opacity-40" disabled={!activeChunkScenes.length || generatingPromptChunk !== null} onClick={() => void generateDensePromptsForChunk()}>{generatingPromptChunk === activePromptChunk ? <><LoaderCircle size={13} className="mr-1 inline animate-spin" />고밀도 생성 중</> : <><Sparkles size={13} className="mr-1 inline" />이 청크 고밀도 생성</>}</button></div></div><div className="mt-3 grid gap-2 text-xs text-[#6c655d] sm:grid-cols-2 xl:grid-cols-4"><span className="rounded-lg bg-white px-3 py-2">청크 {String(activePromptChunk).padStart(2, "0")} · {chunkEstimate.sceneCount}장면</span><span className="rounded-lg bg-white px-3 py-2">고밀도 생성 {generatedPromptCount}/{activeChunkScenes.length}</span><span className="rounded-lg bg-white px-3 py-2">예상 이미지 생성 비용 단위 · {chunkEstimate.imageGenerationRequestCount}회 요청</span><span className="rounded-lg bg-white px-3 py-2">GPT Image 2 · Medium · 완료 {chunkEstimate.generatedImageCount}</span></div><p className="mt-2 text-[11px] text-[#806e61]">금액·크레딧은 외부 요금표에 따라 달라지므로 표시하지 않습니다. 이 수치는 실제 이미지 생성 요청 횟수로, 실행 전 비용 규모를 판단하는 기준입니다. 자동 보정은 장면당 1,600자 상한, 중복 절 제거, 네거티브 가드 표준화를 적용합니다.</p>{promptOptimization?.chunk === activePromptChunk && <div className="mt-3 rounded-lg border border-[#d6c1ad] bg-[#fffdf9] p-3 text-xs text-[#654f40]">자동 보정 {promptOptimization.changedCount}/{promptOptimization.results.length}장면 · {promptOptimization.results.reduce((sum, result) => sum + result.removedDuplicateClauses, 0)}개 반복 절 제거 · {promptOptimization.results.filter((result) => result.truncated).length}개 길이 축약</div>}<div className="mt-3 rounded-xl border border-[#e5d3c2] bg-white p-3"><div className="flex flex-wrap items-center justify-between gap-2"><div><p className="text-[11px] font-bold tracking-[0.12em] text-[#a2543d]">APPEARANCE ANCHOR CHECK</p><p className="mt-1 text-xs text-[#6c655d]">청크 안에서 등장한 주요 인물의 영어 외형 앵커 핵심어가 프롬프트에 남았는지 점검합니다.</p></div><b className="rounded-full bg-[#f6eee4] px-3 py-1 text-xs text-[#6a4b3a]">일치도 {chunkAppearance.overallScore ?? "—"}{chunkAppearance.overallScore !== null ? "%" : ""}</b></div><div className="mt-2 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">{chunkAppearance.checks.map((check) => <div className="rounded-lg bg-[#faf7f1] p-2 text-[11px] text-[#5d554d]" key={check.name}><b className="text-[#34403d]">{check.name}</b><span className="ml-1">{check.status === "checked" ? `${check.score}% · ${check.sceneCount}장면` : check.status === "anchor_missing" ? "외형 앵커 필요" : "이 청크 미등장"}</span>{check.status === "checked" && <p className="mt-1 leading-4">{check.missingKeywords.length ? <>누락: {check.missingKeywords.slice(0, 5).join(", ")}</> : "외형 앵커 핵심어 유지"}</p>}</div>)}</div></div></article>}
        {workflow.scenes.length > 0 && <article className="rounded-xl border border-[#d7c2b0] bg-[#fffdf9] p-4"><div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between"><div><p className="text-xs font-bold tracking-[0.12em] text-[#a2543d]">PROMPT OPTIMIZATION DIFF</p><h3 className="mt-1 font-serif text-lg font-semibold text-[#263331]">자동 보정 전후 비교 · 되돌리기</h3><p className="mt-1 text-sm leading-6 text-[#6c655d]">자동 보정이 실제로 바꾼 장면만 표시합니다. 왼쪽 원문과 오른쪽 보정 결과를 비교한 뒤 필요하면 해당 장면만 보정 전 상태로 복구하세요.</p></div><span className="rounded-full bg-[#f5eee4] px-3 py-1 text-xs font-semibold text-[#725544]">이 청크 이력 {activeChunkScenes.filter((scene) => scene.promptOptimizationHistory.length).length}장면</span></div>{activeChunkScenes.some((scene) => scene.promptOptimizationHistory.length) ? <div className="mt-4 space-y-3">{activeChunkScenes.filter((scene) => scene.promptOptimizationHistory.length).map((scene) => { const snapshot = scene.promptOptimizationHistory.at(-1)!; return <div className="rounded-xl border border-[#eadfd4] bg-white p-3" key={`optimization-${scene.number}-${snapshot.id}`}><div className="flex flex-wrap items-center justify-between gap-2"><b className="text-sm text-[#34403d]">장면 {scene.number}</b><span className="text-[11px] text-[#806e61]">{snapshot.result.originalLength}자 → {snapshot.result.optimizedLength}자 · 반복 절 {snapshot.result.removedDuplicateClauses}개 제거{snapshot.result.truncated ? " · 길이 축약" : ""}</span></div><div className="mt-2 grid gap-2 lg:grid-cols-2"><div><p className="mb-1 text-[10px] font-bold tracking-[0.12em] text-[#a2543d]">BEFORE · 보정 전</p><pre className="max-h-36 overflow-auto whitespace-pre-wrap break-words rounded-lg bg-[#faf2eb] p-2 text-xs leading-5 text-[#5b4b40]">{snapshot.beforePrompt}</pre></div><div><p className="mb-1 text-[10px] font-bold tracking-[0.12em] text-[#31594f]">AFTER · 보정 후</p><pre className="max-h-36 overflow-auto whitespace-pre-wrap break-words rounded-lg bg-[#f0f7f2] p-2 text-xs leading-5 text-[#384e45]">{snapshot.afterPrompt}</pre></div></div><button className="mt-3 rounded-lg border border-[#bd927c] bg-[#fff6ed] px-3 py-2 text-xs font-semibold text-[#8f3f2e]" onClick={() => restorePromptOptimization(scene.number)}><RefreshCw size={13} className="mr-1 inline" />보정 전으로 되돌리기</button></div>; })}</div> : <div className="mt-3 rounded-lg bg-white p-3 text-sm text-[#806e61]">이 청크에 아직 자동 보정 이력이 없습니다. 고밀도 프롬프트를 생성한 뒤 길이·중복 자동 보정을 실행하세요.</div>}</article>}

        {workflow.scenes.length > 0 && <article className={`rounded-xl border p-4 ${chunkAnchorConflicts.conflicts.length ? "border-rose-300 bg-rose-50" : "border-emerald-200 bg-emerald-50"}`}><div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between"><div><p className="text-xs font-bold tracking-[0.12em] text-[#a2543d]">SCENE ANCHOR CONFLICT WATCH</p><h3 className="mt-1 font-serif text-lg font-semibold text-[#263331]">장면별 인물 외형 앵커 충돌 경고</h3><p className="mt-1 text-sm leading-6 text-[#6c655d]">같은 장면에 등장한 인물의 앵커에서 성별·머리색·도포색·연령의 자기 모순, 동일 앵커, 구분이 어려운 공통 표식을 검사합니다.</p></div><b className={`rounded-full px-3 py-1 text-xs ${chunkAnchorConflicts.conflicts.length ? "bg-rose-100 text-rose-800" : "bg-emerald-100 text-emerald-800"}`}>{chunkAnchorConflicts.conflicts.length ? `경고 ${chunkAnchorConflicts.conflicts.length}건` : "충돌 없음"}</b></div>{chunkAnchorConflicts.conflicts.length ? <div className="mt-3 space-y-2">{chunkAnchorConflicts.conflicts.map((conflict, index) => <div className="rounded-lg bg-white p-3 text-xs text-[#5a4a40]" key={`${conflict.sceneNumber}-${conflict.kind}-${index}`}><b className="text-[#8f3f2e]">장면 {conflict.sceneNumber} · {conflict.severity === "error" ? "수정 필요" : "구분 권장"}</b><p className="mt-1 leading-5">{conflict.message}</p><p className="mt-1 text-[#806e61]">근거: {conflict.evidence.join(", ")}</p></div>)}</div> : <div className="mt-3 rounded-lg bg-white p-3 text-sm text-[#4c665a]">현재 청크에서 감지된 외형 앵커 충돌이 없습니다.</div>}</article>}

        {workflow.scenes.length > 0 && <article className="rounded-xl border border-[#c8d9cf] bg-[#f4fbf6] p-4"><div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between"><div><p className="text-xs font-bold tracking-[0.12em] text-[#31594f]">MULTI-CHUNK FLOW PACKAGE</p><h3 className="mt-1 font-serif text-lg font-semibold text-[#263331]">여러 청크 Flow CSV · ZIP 일괄 내보내기</h3><p className="mt-1 text-sm leading-6 text-[#6c655d]">선택한 청크별 Flow 입력 txt와 장면 ID 매핑 JSON, 선택분 전체를 합친 CSV를 단일 ZIP으로 내려받습니다.</p></div><button className="rounded-lg bg-[#31594f] px-3 py-2 text-xs font-semibold text-white disabled:opacity-40" disabled={!flowMultiChunkReady} title={flowMultiChunkReady ? undefined : "선택한 모든 청크의 고밀도 프롬프트를 채우고 시각화 단계를 승인한 뒤 내보낼 수 있습니다."} onClick={exportFlowMultiChunkPackage}><FileDown size={13} className="mr-1 inline" />Flow CSV·ZIP 일괄 내보내기</button></div><div className="mt-3 grid gap-2 sm:grid-cols-3 lg:grid-cols-7">{chunksWithScenes.map((chunk) => <label className={`flex cursor-pointer items-center gap-2 rounded-lg border px-3 py-2 text-xs font-semibold ${selectedFlowChunks.includes(chunk) ? "border-[#4e7c6d] bg-white text-[#31594f]" : "border-[#cfe0d6] bg-[#f9fdf9] text-[#5d6a63]"}`} key={`flow-chunk-${chunk}`}><input aria-label={`Flow 패키지 청크 ${chunk}`} type="checkbox" checked={selectedFlowChunks.includes(chunk)} onChange={() => toggleFlowChunk(chunk)} />청크 {String(chunk).padStart(2, "0")}</label>)}</div><p className="mt-3 text-[11px] text-[#527062]">선택 {selectedFlowChunks.length}개 청크 · ZIP 안에 청크별 txt·JSON과 전체 장면 매핑 CSV가 들어갑니다.</p></article>}

        {workflow.scenes.length > 0 && activeChunkScenes.some((scene) => scene.promptOptimizationHistory.length) && <article className="rounded-xl border border-[#d4c5ec] bg-[#faf8ff] p-4"><div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between"><div><p className="text-xs font-bold tracking-[0.12em] text-[#7047a4]">OPTIMIZATION VERSION VAULT</p><h3 className="mt-1 font-serif text-lg font-semibold text-[#263331]">자동 보정 이력 버전 선택 복구</h3><p className="mt-1 text-sm leading-6 text-[#6c655d]">같은 장면을 여러 번 보정한 경우에도 모든 이력을 보관합니다. 원하는 버전을 선택하면 그 버전의 보정 전 원문으로 정확히 되돌립니다.</p></div><span className="rounded-full bg-white px-3 py-1 text-xs font-semibold text-[#705483]">장면별 다중 이력</span></div><div className="mt-4 grid gap-3 lg:grid-cols-2">{activeChunkScenes.filter((scene) => scene.promptOptimizationHistory.length).map((scene) => { const selectedId = selectedOptimizationSnapshots[scene.number] ?? scene.promptOptimizationHistory.at(-1)!.id; const snapshot = scene.promptOptimizationHistory.find((entry) => entry.id === selectedId) ?? scene.promptOptimizationHistory.at(-1)!; return <div className="rounded-xl border border-[#e2d9f2] bg-white p-3" key={`version-vault-${scene.number}`}><div className="flex flex-wrap items-center justify-between gap-2"><b className="text-sm text-[#34403d]">장면 {scene.number}</b><span className="text-[11px] text-[#806e61]">총 {scene.promptOptimizationHistory.length}개 이력</span></div><label className="mt-2 block text-[11px] font-semibold text-[#62447e]">복구할 보정 이력<select aria-label={`장면 ${scene.number} 보정 이력 선택`} className="mt-1 w-full rounded-lg border border-[#d8cce9] bg-[#fcfaff] p-2 text-xs text-[#4b3e58]" value={selectedId} onChange={(event) => setSelectedOptimizationSnapshots((current) => ({ ...current, [scene.number]: event.target.value }))}>{scene.promptOptimizationHistory.map((entry, index) => <option value={entry.id} key={entry.id}>버전 {index + 1} · {new Date(entry.createdAt).toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit", second: "2-digit" })} · {entry.result.originalLength}자 → {entry.result.optimizedLength}자</option>)}</select></label><div className="mt-2 grid gap-2 sm:grid-cols-2"><p className="rounded-lg bg-[#faf2eb] p-2 text-[11px] leading-5 text-[#5b4b40]">선택 버전 원문<br />{snapshot.beforePrompt.slice(0, 180)}{snapshot.beforePrompt.length > 180 ? "…" : ""}</p><p className="rounded-lg bg-[#f0f7f2] p-2 text-[11px] leading-5 text-[#384e45]">선택 버전 결과<br />{snapshot.afterPrompt.slice(0, 180)}{snapshot.afterPrompt.length > 180 ? "…" : ""}</p></div><button className="mt-3 rounded-lg border border-[#8b69ab] bg-[#f8f2ff] px-3 py-2 text-xs font-semibold text-[#69458f]" onClick={() => restorePromptOptimization(scene.number, selectedId)}><RefreshCw size={13} className="mr-1 inline" />선택 이력으로 복구</button></div>; })}</div></article>}

        {workflow.scenes.length > 0 && chunkAnchorConflicts.conflicts.length > 0 && <article className="rounded-xl border border-[#eab6b0] bg-[#fff6f4] p-4"><div><p className="text-xs font-bold tracking-[0.12em] text-[#a34734]">CONFLICT ANCHOR QUICK FIX</p><h3 className="mt-1 font-serif text-lg font-semibold text-[#263331]">경고 창에서 외형 앵커 바로 수정</h3><p className="mt-1 text-sm leading-6 text-[#6c655d]">아래 인물은 현재 청크의 충돌 경고와 연결돼 있습니다. 앵커를 고친 뒤 저장하면 충돌 검사가 즉시 다시 실행됩니다.</p></div><div className="mt-4 grid gap-3 lg:grid-cols-2">{Array.from(new Set(chunkAnchorConflicts.conflicts.flatMap((conflict) => conflict.characterNames))).map((name) => { const character = workflow.characters.find((entry) => entry.name === name); if (!character) return null; return <div className="rounded-xl border border-[#f0d0ca] bg-white p-3" key={`quick-fix-${name}`}><b className="text-sm text-[#8f3f2e]">{name}</b><textarea aria-label={`${name} 충돌 앵커 수정`} className="mt-2 min-h-20 w-full rounded-lg border border-[#e4c9c1] bg-[#fffdfc] p-2 text-xs leading-5 text-[#403b36]" value={conflictAnchorDrafts[name] ?? character.supportAnchor} onChange={(event) => setConflictAnchorDrafts((drafts) => ({ ...drafts, [name]: event.target.value }))} placeholder="English appearance anchor" /><button className="mt-2 rounded-lg bg-[#a34734] px-3 py-2 text-xs font-semibold text-white" onClick={() => saveConflictAnchor(name)}><RefreshCw size={13} className="mr-1 inline" />저장 · 충돌 다시 검사</button></div>; })}</div></article>}

        {workflow.scenes.length > 0 && <article className={`rounded-xl border p-4 ${commonAnchorConflicts.length ? "border-violet-300 bg-violet-50" : "border-slate-200 bg-slate-50"}`}><div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between"><div><p className="text-xs font-bold tracking-[0.12em] text-[#7047a4]">COMMON ANCHOR CONFLICT BATCH FIX</p><h3 className="mt-1 font-serif text-lg font-semibold text-[#263331]">여러 청크 공통 충돌 일괄 수정</h3><p className="mt-1 text-sm leading-6 text-[#6c655d]">같은 인물·근거·충돌 유형이 두 청크 이상에서 반복될 때만 모아 표시합니다. 수정안을 한 번 입력하면 관련 인물 앵커에 함께 반영하고 21청크를 다시 검사합니다.</p></div><b className={`rounded-full px-3 py-1 text-xs ${commonAnchorConflicts.length ? "bg-violet-100 text-violet-800" : "bg-slate-200 text-slate-700"}`}>{commonAnchorConflicts.length ? `공통 충돌 ${commonAnchorConflicts.length}개` : "반복 충돌 없음"}</b></div>{commonAnchorConflicts.length ? <div className="mt-4 space-y-3">{commonAnchorConflicts.map((conflict) => <div className="rounded-xl border border-violet-200 bg-white p-3" key={conflict.key}><div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between"><div><b className="text-sm text-[#69458f]">{conflict.characterNames.join(" · ")} · 청크 {conflict.affectedChunks.map((chunk) => String(chunk).padStart(2, "0")).join(", ")}</b><p className="mt-1 text-xs leading-5 text-[#5f516a]">{conflict.message}</p><p className="mt-1 text-[11px] text-[#806e61]">근거: {conflict.evidence.join(", ")} · {conflict.occurrenceCount}개 장면에서 반복</p></div><span className="rounded-full bg-[#f3edff] px-2 py-1 text-[10px] font-semibold text-[#7047a4]">{conflict.severity === "error" ? "수정 필요" : "구분 권장"}</span></div><div className="mt-3 grid gap-3 lg:grid-cols-2">{conflict.characterNames.map((name) => { const character = workflow.characters.find((entry) => entry.name === name); if (!character) return null; return <label className="text-xs font-semibold text-[#564369]" key={`${conflict.key}-${name}`}>{name} 수정 앵커<textarea aria-label={`공통 충돌 ${name} 앵커 수정`} className="mt-1 min-h-20 w-full rounded-lg border border-violet-200 bg-[#fcfaff] p-2 text-xs font-normal leading-5 text-[#403b36]" value={commonConflictAnchorDrafts[name] ?? character.supportAnchor} onChange={(event) => setCommonConflictAnchorDrafts((drafts) => ({ ...drafts, [name]: event.target.value }))} placeholder="English appearance anchor" /></label>; })}</div><button className="mt-3 rounded-lg bg-[#7047a4] px-3 py-2 text-xs font-semibold text-white" onClick={() => saveCommonConflictAnchors(conflict)}><RefreshCw size={13} className="mr-1 inline" />이 공통 충돌 일괄 수정 · 전체 재검사</button></div>)}</div> : <div className="mt-3 rounded-lg bg-white p-3 text-sm text-[#5a6471]">두 청크 이상에서 같은 외형 앵커 충돌이 반복되면 이곳에서 일괄 수정할 수 있습니다.</div>}</article>}

        {workflow.scenes.length > 0 && <article className="rounded-xl border border-[#c7b8e5] bg-[#faf8ff] p-4"><div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between"><div><p className="text-xs font-bold tracking-[0.12em] text-[#62447e]">COMMON CONFLICT CONTROL CENTER</p><h3 className="mt-1 font-serif text-lg font-semibold text-[#263331]">공통 충돌 이력 · 필터 · 수정안</h3><p className="mt-1 max-w-3xl text-sm leading-6 text-[#6c655d]">반복 충돌을 심각도와 영향 청크 수로 좁혀 보세요. 수정안은 앵커 초안일 뿐이므로 인물 시트와 세계관에 맞는지 확인한 뒤 저장합니다. 저장된 일괄 수정은 아래 이력에서 이전 상태로 복구할 수 있습니다.</p></div><span className="rounded-full bg-white px-3 py-1 text-xs font-semibold text-[#62447e]">표시 {visibleCommonAnchorConflicts.length}/{commonAnchorConflicts.length}개</span></div><div className="mt-4 grid gap-2 sm:grid-cols-3"><label className="text-xs font-semibold text-[#5e4b71]">심각도<select aria-label="공통 충돌 심각도 필터" className="mt-1 w-full rounded-lg border border-[#d9cceb] bg-white p-2 text-xs text-[#4b3e58]" value={commonConflictSeverityFilter} onChange={(event) => setCommonConflictSeverityFilter(event.target.value as "all" | "error" | "warning")}><option value="all">전체</option><option value="error">수정 필요만</option><option value="warning">구분 권장만</option></select></label><label className="text-xs font-semibold text-[#5e4b71]">영향 청크 수<select aria-label="공통 충돌 영향 청크 필터" className="mt-1 w-full rounded-lg border border-[#d9cceb] bg-white p-2 text-xs text-[#4b3e58]" value={commonConflictMinChunks} onChange={(event) => setCommonConflictMinChunks(Number(event.target.value))}><option value={2}>2개 이상</option><option value={3}>3개 이상</option><option value={5}>5개 이상</option></select></label><label className="text-xs font-semibold text-[#5e4b71]">정렬<select aria-label="공통 충돌 정렬" className="mt-1 w-full rounded-lg border border-[#d9cceb] bg-white p-2 text-xs text-[#4b3e58]" value={commonConflictSort} onChange={(event) => setCommonConflictSort(event.target.value as "impact_desc" | "impact_asc" | "severity")}><option value="impact_desc">영향 청크 많은 순</option><option value="impact_asc">영향 청크 적은 순</option><option value="severity">심각도 우선</option></select></label></div>{visibleCommonAnchorConflicts.length ? <div className="mt-4 space-y-3">{visibleCommonAnchorConflicts.map((conflict) => <div className="rounded-xl border border-[#e0d7ef] bg-white p-3" key={`control-${conflict.key}`}><div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between"><div><b className="text-sm text-[#62447e]">{conflict.characterNames.join(" · ")} · 영향 청크 {conflict.affectedChunks.length}개</b><p className="mt-1 text-xs leading-5 text-[#5f516a]">{conflict.message}</p><p className="mt-1 text-[11px] text-[#806e61]">청크 {conflict.affectedChunks.map((chunk) => String(chunk).padStart(2, "0")).join(", ")} · 근거 {conflict.evidence.join(", ")} · {conflict.occurrenceCount}개 장면</p></div><span className={`rounded-full px-2 py-1 text-[10px] font-semibold ${conflict.severity === "error" ? "bg-rose-100 text-rose-800" : "bg-amber-100 text-amber-800"}`}>{conflict.severity === "error" ? "수정 필요" : "구분 권장"}</span></div><div className="mt-3 grid gap-3 lg:grid-cols-2">{conflict.characterNames.map((name) => { const character = workflow.characters.find((entry) => entry.name === name); if (!character) return null; return <label className="text-xs font-semibold text-[#564369]" key={`control-${conflict.key}-${name}`}>{name} 앵커 초안<textarea aria-label={`공통 충돌 제안 ${name} 앵커 수정`} className="mt-1 min-h-20 w-full rounded-lg border border-violet-200 bg-[#fcfaff] p-2 text-xs font-normal leading-5 text-[#403b36]" value={commonConflictAnchorDrafts[name] ?? character.supportAnchor} onChange={(event) => setCommonConflictAnchorDrafts((drafts) => ({ ...drafts, [name]: event.target.value }))} /></label>; })}</div><div className="mt-3 flex flex-wrap gap-2"><button className="rounded-lg border border-[#8d6cad] bg-[#f7f0ff] px-3 py-2 text-xs font-semibold text-[#69458f]" onClick={() => applyCommonConflictSuggestion(conflict)}><Sparkles size={13} className="mr-1 inline" />수정안 채우기</button><button className="rounded-lg bg-[#7047a4] px-3 py-2 text-xs font-semibold text-white" onClick={() => saveCommonConflictAnchors(conflict)}><RefreshCw size={13} className="mr-1 inline" />이 충돌 일괄 수정 · 전체 재검사</button></div></div>)}</div> : <div className="mt-4 rounded-lg bg-white p-3 text-sm text-[#5f6670]">현재 필터 조건에 맞는 공통 충돌이 없습니다.</div>}<div className="mt-5 border-t border-[#e4dcf0] pt-4"><div className="flex flex-wrap items-center justify-between gap-2"><div><p className="text-[11px] font-bold tracking-[0.12em] text-[#62447e]">BATCH FIX HISTORY</p><p className="mt-1 text-xs text-[#6c655d]">최근 공통 충돌 일괄 수정 {workflow.commonAnchorConflictHistory.length}건</p></div></div>{workflow.commonAnchorConflictHistory.length ? <div className="mt-3 space-y-2">{workflow.commonAnchorConflictHistory.slice().reverse().map((entry) => <div className="flex flex-col gap-2 rounded-lg border border-[#e2d9ef] bg-white p-3 sm:flex-row sm:items-center sm:justify-between" key={entry.id}><div><b className="text-xs text-[#514060]">{entry.characterNames.join(" · ")} · 청크 {entry.affectedChunks.map((chunk) => String(chunk).padStart(2, "0")).join(", ")}</b><p className="mt-1 text-[11px] text-[#806e61]">{new Date(entry.createdAt).toLocaleString("ko-KR")} · {entry.conflictMessage}</p></div><button className="rounded-lg border border-[#8d6cad] bg-[#f8f2ff] px-3 py-2 text-xs font-semibold text-[#69458f]" onClick={() => restoreCommonConflictHistory(entry.id)}><RefreshCw size={13} className="mr-1 inline" />이 이력으로 복구</button></div>)}</div> : <p className="mt-3 rounded-lg bg-white p-3 text-sm text-[#6c655d]">공통 충돌을 일괄 수정하면 전후 앵커와 영향 청크가 여기에 기록됩니다.</p>}</div></article>}

        <div className="grid gap-3 lg:grid-cols-[1.15fr_1fr]">
          <article className="rounded-xl border border-[#e5d8ca] bg-white p-4"><div className="flex items-start justify-between gap-3"><div><p className="text-xs font-bold tracking-[0.12em] text-[#a2543d]">01 · 대본 승인</p><h3 className="mt-1 font-serif text-lg font-semibold text-[#263331]">정본과 상태 장부를 통과한 원고</h3></div><ShieldCheck size={20} className="text-[#55756c]" /></div><p className="mt-2 text-sm leading-6 text-[#6c655d]">현재 연속성 검수 결과를 대본 승인 조건으로 사용합니다. 대본이 바뀌면 캐릭터 이후 모든 산출물이 자동으로 재생성 대기가 됩니다.</p><div className="mt-3 flex flex-wrap gap-2"><button className="rounded-lg bg-[#263f3e] px-3 py-2 text-xs font-semibold text-white disabled:opacity-40" disabled={!scriptReady} onClick={() => approve("script")}>{scriptReady ? "대본 승인" : "연속성 검수 필요"}</button><button className="rounded-lg border border-[#d7c2b0] px-3 py-2 text-xs font-semibold text-[#59483e]" onClick={() => reviewStage("script")}>검수 대기 표시</button></div></article>
          <article className="rounded-xl border border-[#e5d8ca] bg-white p-4"><div className="flex items-start justify-between gap-3"><div><p className="text-xs font-bold tracking-[0.12em] text-[#a2543d]">02 · 캐릭터 승인</p><h3 className="mt-1 font-serif text-lg font-semibold text-[#263331]">주요 인물만 이미지 레퍼런스</h3></div><Image size={20} className="text-[#55756c]" /></div><div className="mt-3 space-y-2">{workflow.characters.map((character, index) => <div className="rounded-lg bg-[#faf7f1] p-2" key={character.name}><div className="flex items-center justify-between gap-2"><b className="text-sm text-[#34403d]">{character.name}</b><span className="text-[11px] text-[#8b6956]">{character.importance === "main" ? "주요 인물" : "보조 앵커"}</span></div>{character.importance === "main" ? <><div className="mt-2 grid grid-cols-2 gap-1 text-[11px] text-[#62584e]">{[["텍스트 시트", "sheetReady"], ["한글명·Medium 이미지", "imageReady"], ["얼굴 레퍼런스", "faceReferenceReady"], ["전신 레퍼런스", "fullBodyReferenceReady"]].map(([label, key]) => <label key={key} className="flex items-center gap-1"><input type="checkbox" checked={Boolean(character[key as keyof typeof character])} onChange={(event) => updateCharacter(index, { [key]: event.target.checked } as Partial<CharacterAsset>)} />{label}</label>)}</div><textarea className="mt-2 min-h-16 w-full rounded border border-[#dfd3c5] bg-white p-2 text-xs text-[#403b36]" value={character.characterSheet} onChange={(event) => updateCharacter(index, { characterSheet: event.target.value })} placeholder="캐릭터 시트: 역할, 나이, 외형, 의상, 무기, 감정선" /><input className="mt-2 w-full rounded border border-[#dfd3c5] bg-white p-2 text-xs text-[#403b36]" value={character.supportAnchor} onChange={(event) => updateCharacter(index, { supportAnchor: event.target.value })} placeholder="English full appearance anchor for generated image" /><input className="mt-2 w-full rounded border border-[#dfd3c5] bg-white p-2 text-xs text-[#403b36]" value={character.imageUrl} onChange={(event) => updateCharacter(index, { imageUrl: event.target.value })} placeholder="생성된 인물 이미지 URL 또는 /manus-storage/... 경로" /><input className="mt-2 w-full rounded border border-[#dfd3c5] bg-white p-2 text-xs text-[#403b36]" value={character.imageAlt} onChange={(event) => updateCharacter(index, { imageAlt: event.target.value })} placeholder="이미지 설명 (선택)" /><button className="mt-2 rounded-md border border-[#cdb9a5] px-2 py-1 text-[11px] font-semibold text-[#59483e] disabled:opacity-40" disabled={!character.characterSheet.trim() && !character.imageUrl.trim()} onClick={() => { setFailedPreviewUrl(null); setPreviewCharacter(character); }}><Eye size={12} className="mr-1 inline" />시트·이미지 미리보기</button></> : <textarea className="mt-2 min-h-14 w-full rounded border border-[#dfd3c5] bg-white p-2 text-xs text-[#403b36]" value={character.supportAnchor} onChange={(event) => updateCharacter(index, { supportAnchor: event.target.value })} placeholder="English full appearance anchor, at least 20 characters" />}</div>)}</div><button className="mt-3 rounded-lg bg-[#263f3e] px-3 py-2 text-xs font-semibold text-white disabled:opacity-40" disabled={!canApprove("characters")} title={approvalBlock("characters") ?? undefined} onClick={() => approve("characters")}>캐릭터 승인</button></article>
        </div>

        <article className="rounded-xl border border-[#d9c9b8] bg-[#fffaf3] p-4"><div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between"><div><p className="text-xs font-bold tracking-[0.12em] text-[#a2543d]">CHARACTER IMAGE LAB</p><h3 className="mt-1 font-serif text-lg font-semibold text-[#263331]">주요 인물 이미지 생성</h3><p className="mt-1 text-sm leading-6 text-[#6c655d]">위 캐릭터 카드에 저장한 시트와 외형 앵커를 사용해 이름이 들어간 Medium 품질 레퍼런스 이미지를 만듭니다.</p></div><span className="rounded-full bg-[#f4e1d5] px-3 py-1 text-xs font-semibold text-[#8f3f2e]">주요 인물 {workflow.characters.filter((character) => character.importance === "main").length}명</span></div><div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">{workflow.characters.filter((character) => character.importance === "main").map((character) => { const index = workflow.characters.findIndex((entry) => entry.name === character.name); return <div className="overflow-hidden rounded-xl border border-[#e4d8ca] bg-white" key={character.name}>{character.imageUrl ? <img src={character.imageUrl} alt={`${character.name} 생성 인물 이미지`} className="h-36 w-full object-cover" /> : <div className="flex h-36 items-center justify-center bg-[#f6f0e7] text-center text-xs text-[#806e61]"><FileImage size={18} className="mr-1" />이미지 대기</div>}<div className="p-3"><div className="flex items-center justify-between"><b className="text-sm text-[#34403d]">{character.name}</b><span className="text-[11px] text-[#8b6956]">{character.characterSheet.trim() ? "시트 연결됨" : "시트 필요"}</span></div><button className="mt-2 w-full rounded-lg bg-[#a34734] px-3 py-2 text-xs font-semibold text-white disabled:opacity-40" disabled={!character.characterSheet.trim() || generatingCharacter === character.name} onClick={() => void generateCharacterImage(index)}>{generatingCharacter === character.name ? <><LoaderCircle size={13} className="mr-1 inline animate-spin" />생성 중</> : <><FileImage size={13} className="mr-1 inline" />{character.imageUrl ? "인물 이미지 재생성" : "인물 이미지 생성"}</>}</button><button className="mt-2 w-full rounded-lg border border-[#d7c2b0] px-3 py-2 text-xs font-semibold text-[#59483e] disabled:opacity-40" disabled={!character.characterSheet.trim() && !character.imageUrl.trim()} onClick={() => { setFailedPreviewUrl(null); setPreviewCharacter(character); }}><Eye size={13} className="mr-1 inline" />시트·이미지 미리보기</button></div></div>; })}</div></article>

        <article className="rounded-xl border border-[#cfc0ae] bg-[#f9f4eb] p-4"><div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between"><div><p className="text-xs font-bold tracking-[0.12em] text-[#a2543d]">CHARACTER VISUAL REVIEW</p><h3 className="mt-1 font-serif text-lg font-semibold text-[#263331]">인물 이미지 · 외형 앵커 육안 검수</h3><p className="mt-1 text-sm leading-6 text-[#6c655d]">생성된 인물 이미지를 영어 외형 앵커와 나란히 비교합니다. 턱 흉터, 머리색, 의상, 무기, 연령 인상처럼 화면에서 확인한 차이를 메모하고 승인 또는 보정 필요로 기록하세요.</p></div><span className="rounded-full bg-white px-3 py-1 text-xs font-semibold text-[#725544]">이미지·앵커가 모두 있는 인물만 판정</span></div><div className="mt-4 grid gap-3 lg:grid-cols-2">{workflow.characters.filter((character) => character.importance === "main").map((character) => { const promptCheck = chunkAppearance.checks.find((check) => check.name === character.name); return <div className="grid overflow-hidden rounded-xl border border-[#dfd1c2] bg-white sm:grid-cols-[180px_1fr]" key={`appearance-review-${character.name}`}>{character.imageUrl ? <img src={character.imageUrl} alt={`${character.name} 외형 검수용 생성 이미지`} className="h-48 w-full object-cover sm:h-full" /> : <div className="flex min-h-44 items-center justify-center bg-[#f1e9dd] p-4 text-center text-xs text-[#806e61]"><FileImage size={18} className="mr-1" />생성 이미지가 필요합니다.</div>}<div className="p-3"><div className="flex flex-wrap items-center justify-between gap-2"><b className="text-sm text-[#34403d]">{character.name}</b><span className={`rounded-full px-2 py-1 text-[10px] font-semibold ${character.appearanceReviewStatus === "APPROVED" ? "bg-emerald-100 text-emerald-800" : character.appearanceReviewStatus === "NEEDS_REVIEW" ? "bg-rose-100 text-rose-800" : "bg-amber-100 text-amber-800"}`}>{character.appearanceReviewStatus === "APPROVED" ? "외형 승인" : character.appearanceReviewStatus === "NEEDS_REVIEW" ? "보정 필요" : "검수 대기"}</span></div><p className="mt-2 text-[10px] font-bold tracking-[0.12em] text-[#a2543d]">ENGLISH APPEARANCE ANCHOR</p><p className="mt-1 rounded-lg bg-[#faf7f1] p-2 text-xs leading-5 text-[#534a42]">{character.supportAnchor || "외형 앵커를 먼저 입력하세요."}</p><p className="mt-2 text-[11px] text-[#6c655d]">프롬프트 핵심어: {promptCheck?.status === "checked" ? `${promptCheck.score}% · ${promptCheck.missingKeywords.length ? `누락 ${promptCheck.missingKeywords.join(", ")}` : "유지"}` : "이 청크에서 비교할 프롬프트가 없습니다."}</p><textarea aria-label={`${character.name} 외형 검수 메모`} className="mt-2 min-h-16 w-full rounded-lg border border-[#dfd3c5] bg-[#fffefb] p-2 text-xs leading-5 text-[#403b36]" value={appearanceNotes[character.name] ?? character.appearanceReviewNote} onChange={(event) => setAppearanceNotes((notes) => ({ ...notes, [character.name]: event.target.value }))} placeholder="예: 턱 흉터와 남색 도포는 일치. 머리 길이는 다음 생성에서 짧게." /><div className="mt-2 flex flex-wrap gap-2"><button className="rounded-md bg-[#31594f] px-2.5 py-1.5 text-[11px] font-semibold text-white disabled:opacity-40" disabled={!character.imageUrl || !character.supportAnchor} onClick={() => saveAppearanceReview(character.name, "APPROVED")}>일치 승인</button><button className="rounded-md border border-[#bd927c] bg-[#fff6ed] px-2.5 py-1.5 text-[11px] font-semibold text-[#8f3f2e] disabled:opacity-40" disabled={!character.imageUrl || !character.supportAnchor} onClick={() => saveAppearanceReview(character.name, "NEEDS_REVIEW")}>보정 필요</button></div></div></div>; })}</div></article>

        <article className="rounded-xl border border-[#e5d8ca] bg-white p-4"><div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between"><div><p className="text-xs font-bold tracking-[0.12em] text-[#a2543d]">03 · 시각화 매핑</p><h3 className="mt-1 font-serif text-lg font-semibold text-[#263331]">대본 2~3문장과 직접 대사를 한 번씩만 장면에 배치</h3><p className="mt-1 text-sm text-[#6c655d]">시각화 장면은 최대 25장면 단위로 내보낼 수 있으며, 대사 누락과 중복을 감사표에서 바로 잡습니다.</p></div><div className="flex flex-wrap gap-2"><button className="rounded-lg border border-[#d7c2b0] px-3 py-2 text-xs font-semibold text-[#59483e] disabled:opacity-40" disabled={!workflow.scenes.length} onClick={exportVisualizationJson}><FileJson size={13} className="mr-1 inline" />장면 JSON</button><button className="rounded-lg bg-[#a34734] px-3 py-2 text-xs font-semibold text-white disabled:opacity-40" disabled={workflow.stages.script.status !== "APPROVED"} onClick={buildScenes}><Sparkles size={13} className="mr-1 inline" />시각화 골격 생성</button></div></div>
          {workflow.scenes.length > 0 && <><div className="mt-4 space-y-3">{sceneRows.map((scene) => <div className="rounded-xl border border-[#e9dfd4] p-3" key={scene.number}><div className="flex items-start justify-between gap-3"><div><b className="text-sm text-[#3b423f]">장면 {scene.number}</b><span className="ml-2 text-[11px] text-[#8a7465]">문장 {scene.scriptSentenceIds.length}개 · 대사 {scene.dialogueIds.length}개</span><p className="mt-1 text-xs leading-5 text-[#6c655d]">{scene.koText}</p></div><span className="rounded-full bg-[#f5eee4] px-2 py-1 text-[10px] font-semibold text-[#8b6956]">{scene.scriptSentenceIds.join(" · ")}</span></div><textarea className="mt-2 min-h-20 w-full rounded-lg border border-[#dfd3c5] bg-[#fffefb] p-2 text-xs leading-5 text-[#343b38]" value={scene.enImagePrompt} onChange={(event) => onPromptChange(scene.number, event.target.value)} placeholder="English image prompt. Keep continuity, character references, props, location, and action." /></div>)}</div><div className="mt-3 flex items-center justify-between"><button className="rounded-md border border-[#d7c2b0] p-2 disabled:opacity-40" disabled={scenePage === 0} onClick={() => setScenePage((page) => page - 1)} aria-label="이전 장면"><ChevronLeft size={15} /></button><span className="text-xs text-[#6c655d]">장면 {scenePage * scenePageSize + 1}~{Math.min((scenePage + 1) * scenePageSize, workflow.scenes.length)} / {workflow.scenes.length} · 시각화 청크 {Math.ceil(workflow.scenes.length / 25)}개</span><button className="rounded-md border border-[#d7c2b0] p-2 disabled:opacity-40" disabled={scenePage >= pageCount - 1} onClick={() => setScenePage((page) => page + 1)} aria-label="다음 장면"><ChevronRight size={15} /></button></div><div className="mt-3 flex flex-wrap gap-2"><button className="rounded-lg border border-[#d7c2b0] px-3 py-2 text-xs font-semibold text-[#59483e]" onClick={() => reviewStage("visualization")}>시각화 검수</button><button className="rounded-lg bg-[#263f3e] px-3 py-2 text-xs font-semibold text-white disabled:opacity-40" disabled={!canApprove("visualization")} title={approvalBlock("visualization") ?? undefined} onClick={() => approve("visualization")}>시각화 승인</button></div></>}</article>

        {workflow.scenes.length > 0 && <article className="rounded-xl border border-[#d9c9b8] bg-[#fffaf3] p-4"><div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between"><div><p className="text-xs font-bold tracking-[0.12em] text-[#a2543d]">SCENE IMAGE LAB</p><h3 className="mt-1 font-serif text-lg font-semibold text-[#263331]">장면 이미지 일괄 생성</h3><p className="mt-1 text-sm leading-6 text-[#6c655d]">영어 시각화 프롬프트가 있는 장면만 차례로 생성해 문장 ID에 연결합니다. 빈 프롬프트는 건너뜁니다.</p></div><button className="rounded-lg bg-[#a34734] px-3 py-2 text-xs font-semibold text-white disabled:opacity-40" disabled={!workflow.scenes.some((scene) => scene.enImagePrompt.trim()) || sceneGeneration.running} onClick={() => void generateAllSceneImages()}>{sceneGeneration.running ? <><LoaderCircle size={13} className="mr-1 inline animate-spin" />장면 {sceneGeneration.current ?? ""} 생성 {sceneGeneration.completed}/{sceneGeneration.total}</> : <><FileImage size={13} className="mr-1 inline" />프롬프트 장면 일괄 생성</>}</button></div>{sceneGeneration.total > 0 && <div className="mt-3 rounded-lg border border-[#ead4c3] bg-white p-3 text-xs text-[#6b5b50]">진행 {sceneGeneration.completed}/{sceneGeneration.total} · 실패 {sceneGeneration.failed}<span className="mt-2 block h-1.5 overflow-hidden rounded-full bg-[#eadfd5]"><span className="block h-full bg-[#a34734]" style={{ width: `${Math.round(((sceneGeneration.completed + sceneGeneration.failed) / sceneGeneration.total) * 100)}%` }} /></span></div>}<div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">{sceneRows.map((scene) => <div className="overflow-hidden rounded-xl border border-[#e4d8ca] bg-white" key={`image-${scene.number}`}>{scene.imageUrl ? <img src={scene.imageUrl} alt={`장면 ${scene.number} 생성 이미지`} className="h-32 w-full object-cover" /> : <div className="flex h-32 items-center justify-center bg-[#f6f0e7] text-center text-xs text-[#806e61]"><FileImage size={18} className="mr-1" />이미지 대기</div>}<div className="p-3"><div className="flex items-center justify-between"><b className="text-sm text-[#34403d]">장면 {scene.number}</b><span className="text-[11px] text-[#8b6956]">{scene.imageUrl ? "생성 완료" : "프롬프트 대기"}</span></div><p className="mt-1 line-clamp-2 text-xs leading-5 text-[#6c655d]">{scene.koText}</p><button className="mt-2 w-full rounded-lg border border-[#bd927c] bg-[#fff5ed] px-3 py-2 text-xs font-semibold text-[#8f3f2e] disabled:opacity-40" disabled={!scene.enImagePrompt.trim() || sceneGeneration.running} onClick={() => void generateSceneImage(scene.number)}>{sceneGeneration.running && sceneGeneration.current === scene.number ? <><LoaderCircle size={13} className="mr-1 inline animate-spin" />생성 중</> : <><FileImage size={13} className="mr-1 inline" />{scene.imageUrl ? "이 장면 재생성" : "이 장면 생성"}</>}</button></div></div>)}</div></article>}

        <div className="grid gap-3 lg:grid-cols-2"><article className="rounded-xl border border-[#e5d8ca] bg-white p-4"><div className="flex items-start justify-between"><div><p className="text-xs font-bold tracking-[0.12em] text-[#a2543d]">04 · Flow 전체 재생성</p><h3 className="mt-1 font-serif text-lg font-semibold text-[#263331]">승인 시각화의 영어 프롬프트만 유지</h3></div><RefreshCw size={19} className="text-[#55756c]" /></div><p className="mt-2 text-sm leading-6 text-[#6c655d]">장면 수와 줄 수를 맞추고 CTA, END, 라벨을 제거합니다. 부분 수정은 막고 시각화 원본에서 전체 재생성합니다.</p><button className="mt-3 rounded-lg bg-[#263f3e] px-3 py-2 text-xs font-semibold text-white disabled:opacity-40" disabled={workflow.stages.visualization.status !== "APPROVED"} onClick={generateFlow}>Flow 전체 재생성</button><div className="mt-3 rounded-lg bg-[#faf7f1] p-2 text-xs text-[#6c655d]">현재 {workflow.flowLines.length}줄 · 시각화 {workflow.scenes.length}장면</div><button className="mt-3 rounded-lg border border-[#d7c2b0] px-3 py-2 text-xs font-semibold text-[#59483e] disabled:opacity-40" disabled={!canApprove("flow")} title={approvalBlock("flow") ?? undefined} onClick={() => approve("flow")}>Flow 승인</button></article>
          <article className="rounded-xl border border-[#e5d8ca] bg-white p-4"><div className="flex items-start justify-between"><div><p className="text-xs font-bold tracking-[0.12em] text-[#a2543d]">05 · 무음 영상 프롬프트</p><h3 className="mt-1 font-serif text-lg font-semibold text-[#263331]">장면당 카메라, 행동, 종료 상태 하나</h3></div><Film size={19} className="text-[#55756c]" /></div><p className="mt-2 text-sm leading-6 text-[#6c655d]">줄마다 한 장면의 움직임만 담은 txt를 가져옵니다. 오디오, 대사, TTS, 립싱크, 효과음 지시는 자동 차단합니다.</p><button className="mt-3 rounded-lg border border-[#d7c2b0] px-3 py-2 text-xs font-semibold text-[#59483e]" onClick={() => videoInputRef.current?.click()} disabled={workflow.stages.flow.status !== "APPROVED"}><FileDown size={13} className="mr-1 inline" />영상 프롬프트 txt 가져오기</button><div className="mt-3 rounded-lg bg-[#faf7f1] p-2 text-xs text-[#6c655d]">현재 {workflow.videoLines.length}줄 · 시각화 {workflow.scenes.length}장면</div><button className="mt-3 rounded-lg bg-[#263f3e] px-3 py-2 text-xs font-semibold text-white disabled:opacity-40" disabled={!canApprove("video")} title={approvalBlock("video") ?? undefined} onClick={() => approve("video")}>영상 프롬프트 승인</button></article></div>

        <article className="rounded-xl border border-[#e5d8ca] bg-white p-4"><div className="flex items-start justify-between gap-3"><div><p className="text-xs font-bold tracking-[0.12em] text-[#a2543d]">06 · 제목·설명란·썸네일</p><h3 className="mt-1 font-serif text-lg font-semibold text-[#263331]">서로 다른 세 가지 클릭 약속과 대본 근거</h3><p className="mt-1 text-sm leading-6 text-[#6c655d]">의문형, 직설형, 숫자·역전형 제목은 각각 대본 근거를 연결합니다. 타임라인 5~8개, 해시태그 12개, 고정 서명을 검수합니다.</p></div><Clapperboard size={20} className="shrink-0 text-[#55756c]" /></div><div className="mt-3 grid gap-2 lg:grid-cols-3">{workflow.metadata.titles.map((title, index) => <div className="rounded-lg bg-[#faf7f1] p-3" key={title.type}><b className="text-sm text-[#39423f]">{title.type}</b><input className="mt-2 w-full rounded border border-[#dfd3c5] bg-white p-2 text-xs" value={title.text} onChange={(event) => updateMetadataField({ ...workflow.metadata, titles: workflow.metadata.titles.map((entry, itemIndex) => itemIndex === index ? { ...entry, text: event.target.value } : entry) })} placeholder="제목 입력" /><input className="mt-2 w-full rounded border border-[#dfd3c5] bg-white p-2 text-xs" value={title.scriptEvidence} onChange={(event) => updateMetadataField({ ...workflow.metadata, titles: workflow.metadata.titles.map((entry, itemIndex) => itemIndex === index ? { ...entry, scriptEvidence: event.target.value } : entry) })} placeholder="대본 근거 문장 또는 사건" /></div>)}</div><div className="mt-3 grid gap-2 lg:grid-cols-2"><label className="text-xs font-semibold text-[#5c5148]">타임라인 · 줄마다 하나<textarea className="mt-1 min-h-24 w-full rounded border border-[#dfd3c5] bg-white p-2 text-xs font-normal" value={workflow.metadata.timeline.join("\n")} onChange={(event) => updateMetadataField({ ...workflow.metadata, timeline: event.target.value.split(/\r?\n/).map((value) => value.trim()).filter(Boolean) })} placeholder="00:00 별이 떨어진 밤" /></label><label className="text-xs font-semibold text-[#5c5148]">해시태그 · 쉼표로 12개<textarea className="mt-1 min-h-24 w-full rounded border border-[#dfd3c5] bg-white p-2 text-xs font-normal" value={workflow.metadata.hashtags.join(", ")} onChange={(event) => updateMetadataField({ ...workflow.metadata, hashtags: event.target.value.split(",").map((value) => value.trim()).filter(Boolean) })} placeholder="#무협, #오디오북" /></label></div><div className="mt-3 flex flex-wrap items-center gap-2"><button className="rounded-lg border border-[#d7c2b0] px-3 py-2 text-xs font-semibold text-[#59483e]" onClick={() => reviewStage("metadata")}>메타데이터 검수</button><button className="rounded-lg bg-[#263f3e] px-3 py-2 text-xs font-semibold text-white disabled:opacity-40" disabled={!canApprove("metadata")} title={approvalBlock("metadata") ?? undefined} onClick={() => approve("metadata")}>메타데이터 승인</button><span className="text-xs text-[#8b7465]">타임라인 {workflow.metadata.timeline.length}/5~8 · 해시태그 {workflow.metadata.hashtags.length}/12</span></div></article>

        <article className="rounded-xl border border-[#e5d8ca] bg-white p-4"><div className="flex flex-col justify-between gap-3 sm:flex-row"><div><p className="text-xs font-bold tracking-[0.12em] text-[#a2543d]">07 · 최종 감사</p><h3 className="mt-1 font-serif text-lg font-semibold text-[#263331]">대본 문장부터 영상 프롬프트까지 일대일 검수</h3></div><div className="flex items-center gap-2"><span className={`rounded-full px-3 py-1 text-xs font-semibold ${workflow.scenes.length === 0 ? "bg-slate-100 text-slate-700" : audit.issues.filter((issue) => issue.severity === "error").length ? "bg-rose-100 text-rose-800" : "bg-emerald-100 text-emerald-800"}`}>{workflow.scenes.length === 0 ? "산출물 대기" : audit.issues.filter((issue) => issue.severity === "error").length ? `오류 ${audit.issues.filter((issue) => issue.severity === "error").length}개` : "오류 없음"}</span><button className="rounded-lg bg-[#263f3e] px-3 py-2 text-xs font-semibold text-white disabled:opacity-40" disabled={!canApprove("audit")} title={approvalBlock("audit") ?? undefined} onClick={() => approve("audit")}><CheckCircle2 size={13} className="mr-1 inline" />최종 감사 승인</button></div></div><div className="mt-3 grid gap-2 sm:grid-cols-2 xl:grid-cols-4"><div className="rounded-lg bg-[#f7f2e9] p-3 text-xs text-[#665e55]"><b className="block text-base text-[#243331]">{audit.mappedSentenceCount} / {audit.sentenceCount}</b>대본 문장 매핑</div><div className="rounded-lg bg-[#f7f2e9] p-3 text-xs text-[#665e55]"><b className="block text-base text-[#243331]">{audit.mappedDialogueCount}</b>직접 대사 매핑</div><div className="rounded-lg bg-[#f7f2e9] p-3 text-xs text-[#665e55]"><b className="block text-base text-[#243331]">{audit.flowCount} / {audit.sceneCount}</b>Flow 일치</div><div className="rounded-lg bg-[#f7f2e9] p-3 text-xs text-[#665e55]"><b className="block text-base text-[#243331]">{audit.videoCount} / {audit.sceneCount}</b>영상 일치</div></div>{audit.issues.length > 0 ? <div className="mt-3 max-h-64 overflow-auto rounded-lg border border-[#ead7c8] bg-[#fffaf5]">{audit.issues.slice(0, 30).map((issue, index) => <div className="flex gap-2 border-b border-[#f0e2d6] p-2 text-xs last:border-0" key={`${issue.code}-${index}`}>{issue.severity === "error" ? <AlertTriangle size={14} className="mt-0.5 shrink-0 text-[#b54736]" /> : <ListChecks size={14} className="mt-0.5 shrink-0 text-[#a47a2f]" />}<span><b>{stageLabels[issue.stage]}</b> · {issue.message}</span></div>)}</div> : <div className="mt-3 rounded-lg bg-slate-50 p-3 text-sm text-slate-700"><LockKeyhole size={15} className="mr-1 inline" />시각화, Flow, 영상, 메타데이터 산출물이 연결되면 최종 일대일 감사를 시작합니다.</div>}</article>

        {workflow.invalidations.length > 0 && <article className="rounded-xl border border-[#ead7c8] bg-[#fffaf5] p-4"><div className="flex items-center gap-2"><GitBranch size={17} className="text-[#a34734]" /><h3 className="font-serif text-lg font-semibold text-[#3f332d]">무효화 이력</h3></div><div className="mt-2 space-y-2">{workflow.invalidations.slice(0, 6).map((event) => <div className="rounded-lg border border-[#f1e1d2] bg-white p-2 text-xs" key={event.id}><b>{stageLabels[event.sourceStage]}</b> 변경 · {event.reason}<span className="ml-2 text-[#8b7465]">→ {event.affectedStages.map((stageKey) => stageLabels[stageKey]).join(", ")}</span></div>)}</div></article>}
      </div>}
      {transition && <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#1d2927]/45 p-4" role="status" aria-live="polite"><div className="w-full max-w-sm rounded-2xl border border-[#f2dec2] bg-[#fffdf8] p-5 text-center shadow-2xl"><span className="mx-auto flex h-12 w-12 items-center justify-center rounded-full border-4 border-[#e8c7a3] border-t-[#a34734] animate-spin"><Workflow size={18} className="text-[#a34734]" /></span><p className="mt-4 text-xs font-bold tracking-[0.14em] text-[#a2543d]">WORKFLOW TRANSITION</p><h3 className="mt-1 font-serif text-xl font-semibold text-[#263331]">{transition.from} → {transition.to}</h3><p className="mt-2 text-sm text-[#6c655d]">{transition.action} 중입니다. 다음 단계의 산출물 연결 상태를 확인합니다.</p><div className="mt-4 h-1.5 overflow-hidden rounded-full bg-[#eee2d5]"><span className="block h-full w-2/3 rounded-full bg-[#a34734] animate-pulse" /></div></div></div>}
      {previewCharacter && <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#1d2927]/55 p-4" role="dialog" aria-modal="true" aria-label={`${previewCharacter.name} 캐릭터 미리보기`}><div className="max-h-[88vh] w-full max-w-3xl overflow-auto rounded-2xl border border-[#ead8c3] bg-[#fffdf8] p-4 shadow-2xl sm:p-6"><div className="flex items-start justify-between gap-3 border-b border-[#eadfd2] pb-3"><div><p className="text-xs font-bold tracking-[0.14em] text-[#a2543d]">CHARACTER PREVIEW</p><h3 className="mt-1 font-serif text-2xl font-semibold text-[#263331]">{previewCharacter.name}</h3></div><button className="rounded-lg border border-[#d7c2b0] p-2 text-[#59483e]" onClick={() => setPreviewCharacter(null)} aria-label="캐릭터 미리보기 닫기"><X size={18} /></button></div><div className="mt-4 grid gap-4 md:grid-cols-[1fr_1.15fr]"><div className="min-h-56 overflow-hidden rounded-xl border border-[#e8dccf] bg-[#f3ede4]">{previewCharacter.imageUrl && failedPreviewUrl !== previewCharacter.imageUrl ? <img src={previewCharacter.imageUrl} alt={previewCharacter.imageAlt || `${previewCharacter.name} 인물 이미지`} className="h-full min-h-56 w-full object-cover" onError={() => setFailedPreviewUrl(previewCharacter.imageUrl)} /> : <div className="flex min-h-56 items-center justify-center p-5 text-center text-sm leading-6 text-[#786b5f]"><Image size={22} className="mr-2" />{previewCharacter.imageUrl ? "이미지 주소를 불러오지 못했습니다. 생성 결과 URL을 확인하세요." : "생성된 인물 이미지 URL을 입력하면 여기에서 바로 확인합니다."}</div>}</div><div><p className="text-xs font-bold tracking-[0.12em] text-[#a2543d]">캐릭터 시트</p><p className="mt-2 whitespace-pre-wrap rounded-xl bg-[#f8f2e9] p-4 text-sm leading-7 text-[#443f39]">{previewCharacter.characterSheet || "아직 저장된 캐릭터 시트가 없습니다."}</p>{previewCharacter.supportAnchor && <div className="mt-3 rounded-xl border border-[#ead8c8] bg-[#fffaf4] p-3"><p className="text-[11px] font-bold tracking-[0.12em] text-[#a2543d]">ENGLISH APPEARANCE ANCHOR</p><p className="mt-1 whitespace-pre-wrap text-xs leading-5 text-[#62584e]">{previewCharacter.supportAnchor}</p></div>}<div className="mt-3 flex flex-wrap gap-2 text-xs text-[#6c655d]"><span className="rounded-full bg-[#ecf4ef] px-2 py-1">한글명 이미지 {previewCharacter.imageReady ? "확인" : "대기"}</span><span className="rounded-full bg-[#f5eee4] px-2 py-1">얼굴 {previewCharacter.faceReferenceReady ? "확인" : "대기"}</span><span className="rounded-full bg-[#f5eee4] px-2 py-1">전신 {previewCharacter.fullBodyReferenceReady ? "확인" : "대기"}</span></div></div></div></div></div>}
    </section>
  );
}
