/**
 * 강물의 장부 디자인: 밝은 한지 본문과 먹빛 도구 영역을 대비시키고,
 * 주홍 인장과 흐르는 선으로 청크·상태·대본을 하나의 물길처럼 연결한다.
 */
import { ChangeEvent, DragEvent, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowUpRight,
  AlertTriangle,
  ArchiveRestore,
  BookDown,
  BookMarked,
  BookOpenText,
  Check,
  ChevronDown,
  CircleDotDashed,
  Download,
  FileText,
  FileUp,
  FileJson,
  Flag,
  HeartPulse,
  Menu,
  MoreHorizontal,
  PencilLine,
  Play,
  RotateCcw,
  Route,
  Save,
  ScanSearch,
  ShieldCheck,
  Sparkles,
  Trash2,
  UploadCloud,
  Waves,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { validateChilseongDrafts, type ValidationIssue, type ValidationReport } from "@/lib/continuityValidator";
import { validateStateLedgers, type StateLedger, type StateLedgers } from "@/lib/stateLedgerValidator";
import { applyCastSuggestions, inspectRhythmWithRanges, parseCastTable, previewRelationshipSuggestions, styleGuidance, updateStyleProfile, type CastParseReport, type RhythmNotice, type StyleProfile } from "@/lib/writingAssistant";
import { captureDraftVersion, findDraftVersions, lineDiff, toggleDraftVersionPin, type DraftVersion, type DraftVersions } from "@/lib/draftVersions";
import { defaultImportedChunks, defaultStateLedgers } from "@/lib/defaultProjectData";
import { defaultStyleScoreReport } from "@/lib/defaultStyleScores";
import { buildFeatureFilmMarkdown } from "@/lib/featureFilm";
import { sentenceFingerprint } from "@/lib/productionWorkflow";
import { trpc } from "@/lib/trpc";
import { ProductionPipeline } from "@/components/ProductionPipeline";

const STORAGE_KEY = "chilseong-script-studio-imported-chunks-v1";
const EDITED_STORAGE_KEY = "chilseong-script-studio-edited-chunks-v1";
const DRAFT_VERSIONS_STORAGE_KEY = "chilseong-script-studio-draft-versions-v1";
const STATE_LEDGER_STORAGE_KEY = "chilseong-script-studio-state-ledgers-v1";
const PROJECT_BRIEF_STORAGE_KEY = "chilseong-script-studio-project-brief-v1";
const STYLE_PROFILE_STORAGE_KEY = "chilseong-script-studio-style-profile-v1";
const BACKUP_SCHEMA = "chilseong-script-studio-backup-v1";
const chunks = Array.from({ length: 21 }, (_, index) => index + 1);

const assets = {
  hero: "/manus-storage/chilseong-hero-river_2078f38d.jpg",
  ledger: "/manus-storage/chilseong-ledger-still-life_24f2632e.jpg",
  map: "/manus-storage/chilseong-star-map_9d54e4d4.jpg",
  river: "/manus-storage/chilseong-river-detail_65b734a8.jpg",
  logo: "/manus-storage/chilseong-logo-mark_3b05df6e.png",
};

type ImportedChunk = {
  chunk: number;
  title: string;
  content: string;
  sourceName: string;
  importedAt: string;
};

type ImportedChunks = Record<number, ImportedChunk>;

type AiStyleScore = {
  overall: number;
  hook: number;
  companionVoice: number;
  dialogue: number;
  rhythm: number;
  martialAppeal: number;
  tts: number;
  summary: string;
  strengths: string[];
  issues: string[];
  model: string;
  chunk: number;
};

type BatchRewriteState = {
  running: boolean;
  stopRequested: boolean;
  currentChunk: number | null;
  completed: number[];
  error: string | null;
};

function cloneDefault<T>(data: T): T {
  return JSON.parse(JSON.stringify(data)) as T;
}

function briefExcerpt(content: string, evidence: string) {
  const index = content.indexOf(evidence);
  if (index < 0) return { line: 0, excerpt: evidence };
  const start = Math.max(0, content.lastIndexOf("\n", Math.max(0, index - 260)) + 1);
  const nextBreak = content.indexOf("\n", index + evidence.length + 260);
  const end = nextBreak < 0 ? content.length : nextBreak;
  return { line: content.slice(0, index).split("\n").length, excerpt: content.slice(start, end).trim() };
}
type ProjectBrief = { sourceName: string; content: string; importedAt: string };
type ProjectValidationReport = ValidationReport & { stateCheckedChunks: number; stateMissingChunks: number[] };
type IssueFocus = { issue: ValidationIssue; start: number; end: number; label: string };

function currentWorkTitle(brief: ProjectBrief | null) {
  const heading = brief?.content.match(/^#\s+(.+)$/m)?.[1]?.trim();
  if (heading) return heading.slice(0, 80);
  const filename = brief?.sourceName.replace(/\.(md|txt)$/i, "").trim();
  return filename || "칠성탈명록";
}

const baseDraftPassages = [
  {
    label: "Hook · 별이 떨어진 밤",
    lines: [
      '[복아|놀람]"아저씨, 나 아직 스무 살이야."',
      "목소리는 스무 살 그대로였다. 강무진 팔에 매달린 얼굴은, 그러나 일흔 살 노인의 것이었다.",
      "밤을 가르던 빛이 강 한복판으로 떨어진 뒤, 마을은 늙어 버렸다.",
    ],
  },
  {
    label: "강가 · 구조",
    lines: [
      "강무진은 복아를 낡은 배 바닥에 눕히고 밧줄을 풀었다. 삿대 끝이 진흙을 밀자 배가 옆으로 튀었다.",
      "물살이 여인의 몸을 아래로 끌었다. 강무진은 발뒤꿈치를 배의 못에 걸고 팔을 당겼다.",
      "복아는 떨리는 손으로 밧줄을 감았다.",
    ],
  },
  {
    label: "CTA · 수명세",
    lines: [
      '[허담|내추럴]"별이 내린 땅의 세월은 관천원의 것이다. 남은 것까지 거두어라."',
      "허담은 쓰러진 주민들보다, 배 위에 남은 사람 수를 먼저 세었다.",
    ],
  },
  {
    label: "Intro · 사공의 원칙",
    lines: [
      '[강무진|FIRM]"내 배에 오른 사람은, 무슨 일이 있어도 건너편에 내려준다."',
      "그는 손을 멈추지 않았다. 먼저 사람을 건너게 해야 했다. 이유는 나중이었다.",
      '[강무진|내추럴]"찾는다. 살아 있으면, 반드시 태운다."',
    ],
  },
];

const baseChunkOneMarkdown = `[청크 01/21]

칠성탈명록

## Hook

[복아|놀람]"아저씨, 나 아직 스무 살이야."

목소리는 스무 살 그대로였다. 강무진 팔에 매달린 얼굴은, 그러나 일흔 살 노인의 것이었다.

밤을 가르던 빛이 강 한복판으로 떨어진 뒤, 마을은 늙어 버렸다.

강무진은 복아를 낡은 배 바닥에 눕히고 밧줄을 풀었다. 삿대 끝이 진흙을 밀자 배가 옆으로 튀었다.

물살이 여인의 몸을 아래로 끌었다. 강무진은 발뒤꿈치를 배의 못에 걸고 팔을 당겼다.

복아는 떨리는 손으로 밧줄을 감았다.

[허담|내추럴]"별이 내린 땅의 세월은 관천원의 것이다. 남은 것까지 거두어라."

[CTA]

허담은 쓰러진 주민들보다, 배 위에 남은 사람 수를 먼저 세었다.

## Intro

[강무진|FIRM]"내 배에 오른 사람은, 무슨 일이 있어도 건너편에 내려준다."

그는 손을 멈추지 않았다. 먼저 사람을 건너게 해야 했다. 이유는 나중이었다.

[강무진|내추럴]"찾는다. 살아 있으면, 반드시 태운다."`;

const ledgerRows = [
  { name: "강무진", detail: "육체 24세 · 요광개로 0회", tone: "ink" },
  { name: "복아", detail: "실제·정신 20세 · 육체 70세", tone: "vermilion" },
  { name: "단여령", detail: "아직 현장 밖 · 감시 진입 전", tone: "slate" },
  { name: "백야", detail: "추격 경로 확인 · 첫 결투 전", tone: "slate" },
];

function extractChunkNumber(fileName: string, markdown: string) {
  const nameMatch = fileName.match(/chunk[\s_-]*0?(\d{1,2})/i);
  const contentMatch = markdown.match(/\[\s*청크\s*0?(\d{1,2})(?:\s*\/\s*21)?\s*\]/i);
  const chunk = Number(nameMatch?.[1] ?? contentMatch?.[1]);
  return Number.isInteger(chunk) && chunk >= 2 && chunk <= 21 ? chunk : null;
}

function extractTitle(markdown: string, chunk: number) {
  const heading = markdown.match(/^#{1,3}\s+(.+)$/m)?.[1]?.trim();
  const firstText = markdown
    .split("\n")
    .map((line) => line.trim())
    .find((line) => line && !line.startsWith("[") && line !== "칠성탈명록");
  const candidate = heading || firstText || `청크 ${String(chunk).padStart(2, "0")}`;
  return candidate.replace(/^#+\s*/, "").slice(0, 32);
}

function contentBlocks(markdown: string) {
  return markdown
    .replace(/^\[\s*청크\s*0?\d{1,2}(?:\s*\/\s*21)?\s*\]\s*$/gim, "")
    .replace(/^칠성탈명록\s*$/gim, "")
    .split(/\n\s*\n/)
    .map((block) => block.replace(/^#{1,3}\s+/gm, "").trim())
    .filter(Boolean);
}

function downloadMarkdown(content: string, filename: string) {
  const normalized = content.endsWith("\n") ? content : `${content}\n`;
  const blob = new Blob([normalized], { type: "text/markdown;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1_500);
}

function downloadJson(data: unknown, filename: string) {
  const blob = new Blob([`${JSON.stringify(data, null, 2)}\n`], { type: "application/json;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}

function stateChunkFromFile(fileName: string, state: StateLedger) {
  const nameMatch = fileName.match(/(?:state[_ -]?)?chunk[_ -]?0?(\d{1,2})/i);
  const chunk = Number(state.chunk ?? nameMatch?.[1]);
  return Number.isInteger(chunk) && chunk >= 1 && chunk <= 21 ? chunk : null;
}

function lineRange(text: string, lineNumber: number) {
  const rows = text.split("\n");
  const safeIndex = Math.min(Math.max(lineNumber - 1, 0), rows.length - 1);
  const start = rows.slice(0, safeIndex).reduce((total, row) => total + row.length + 1, 0);
  return { start, end: start + rows[safeIndex].length };
}

function locateIssueInDraft(issue: ValidationIssue, text: string): Omit<IssueFocus, "issue"> {
  const quoted = issue.message.match(/'([^']+)'/)?.[1];
  const heading = issue.message.match(/(##\s*(?:Hook|Intro|Body|Climax|End))/)?.[1];
  const marker = issue.message.match(/(\[(?:CTA|END)\])/ )?.[1];
  const ability = issue.message.match(/(요광개로|칠성도강)/)?.[1];
  const person = issue.message.match(/(강무진|단여령|복아|백야|위천록|노철산|허담|설란)/)?.[1];
  const row = issue.message.match(/(\d+)행/)?.[1];
  const candidates = [issue.detail, quoted, heading, marker, ability, person].filter((value): value is string => Boolean(value));
  const target = candidates.find((value) => text.includes(value));
  if (target) {
    const start = text.indexOf(target);
    return { start, end: start + target.length, label: target };
  }
  if (row) {
    const range = lineRange(text, Number(row));
    return { ...range, label: `${row}행` };
  }
  const firstLine = lineRange(text, 1);
  return { ...firstLine, label: "이 청크의 시작" };
}

function inspectRhythm(text: string) {
  const sentences = text.replace(/\[[^\]]+\]"[^"]*"/g, "").split(/[.!?]\s*/).map((sentence) => sentence.trim()).filter((sentence) => sentence.length > 2);
  const notices: string[] = [];
  for (let index = 0; index < sentences.length - 2; index += 1) {
    const run = sentences.slice(index, index + 3);
    if (run.every((sentence) => sentence.replace(/\s/g, "").length <= 15)) notices.push(`짧은 문장 3연속 · ${index + 1}~${index + 3}문장`);
  }
  for (let index = 0; index < sentences.length - 3; index += 1) {
    const run = sentences.slice(index, index + 4);
    const endings = run.map((sentence) => sentence.match(/(았다|었다|였다|한다|된다|이다)$/)?.[1]).filter(Boolean);
    if (endings.length === 4 && new Set(endings).size === 1) notices.push(`같은 종결어미 4연속 · ${index + 1}~${index + 4}문장`);
    const lengths = run.map((sentence) => sentence.replace(/\s/g, "").length);
    if (Math.max(...lengths) - Math.min(...lengths) <= 6) notices.push(`비슷한 길이 문장 4연속 · ${index + 1}~${index + 4}문장`);
  }
  return Array.from(new Set(notices)).slice(0, 12);
}

export default function Home() {
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [activePassage, setActivePassage] = useState(0);
  const [activeChunk, setActiveChunk] = useState(1);
  const [activeView, setActiveView] = useState<"draft" | "ledger" | "river">("draft");
  const [importedChunks, setImportedChunks] = useState<ImportedChunks>(() => cloneDefault(defaultImportedChunks as ImportedChunks));
  const [editedChunks, setEditedChunks] = useState<Record<number, string>>({});
  const [draftVersions, setDraftVersions] = useState<DraftVersions>({});
  const [stateLedgers, setStateLedgers] = useState<StateLedgers>(() => cloneDefault(defaultStateLedgers as unknown as StateLedgers));
  const [projectBrief, setProjectBrief] = useState<ProjectBrief | null>(null);
  const [castParseReport, setCastParseReport] = useState<CastParseReport | null>(null);
  const [styleProfile, setStyleProfile] = useState<StyleProfile | null>(null);
  const [isDragging, setDragging] = useState(false);
  const [hasHydrated, setHasHydrated] = useState(false);
  const [isEditing, setEditing] = useState(false);
  const [draftText, setDraftText] = useState("");
  const [issueFocus, setIssueFocus] = useState<IssueFocus | null>(null);
  const [isLedgerEditing, setLedgerEditing] = useState(false);
  const [ledgerText, setLedgerText] = useState("");
  const [isLedgerFormOpen, setLedgerFormOpen] = useState(false);
  const [ledgerForm, setLedgerForm] = useState({ location: "", heroAge: "", bokAhMind: "20", bokAhBody: "70", possessions: "", relationshipStage: "" });
  const [selectedIssue, setSelectedIssue] = useState<ValidationIssue | null>(null);
  const [isDiffOpen, setDiffOpen] = useState(false);
  const [isVersionsOpen, setVersionsOpen] = useState(false);
  const [selectedVersionId, setSelectedVersionId] = useState<string | null>(null);
  const [versionMemo, setVersionMemo] = useState("");
  const [versionQuery, setVersionQuery] = useState("");
  const [isRelationshipPreviewOpen, setRelationshipPreviewOpen] = useState(false);
  const [briefEvidenceFocus, setBriefEvidenceFocus] = useState<string | null>(null);
  const [rhythmNotices, setRhythmNotices] = useState<RhythmNotice[]>([]);
  const [validationReport, setValidationReport] = useState<ProjectValidationReport | null>(null);
  const [aiStyleScore, setAiStyleScore] = useState<AiStyleScore | null>(null);
  const [batchRewriteState, setBatchRewriteState] = useState<BatchRewriteState>({ running: false, stopRequested: false, currentChunk: null, completed: [], error: null });
  const activeWorkTitle = useMemo(() => currentWorkTitle(projectBrief), [projectBrief]);
  const inputRef = useRef<HTMLInputElement>(null);
  const stateInputRef = useRef<HTMLInputElement>(null);
  const briefInputRef = useRef<HTMLInputElement>(null);
  const backupInputRef = useRef<HTMLInputElement>(null);
  const editorRef = useRef<HTMLTextAreaElement>(null);
  const briefSourceRef = useRef<HTMLElement>(null);
  const batchStopRef = useRef(false);

  const rewriteMutation = trpc.manuscript.rewrite.useMutation({
    onSuccess: (result) => {
      setDraftText(result.rewrittenMarkdown);
      setVersionMemo(`AI 전면 재작성 · ${result.model}`);
      setIssueFocus(null);
      setEditing(true);
      toast(`청크 ${String(activeChunk).padStart(2, "0")} 전면 재작성 후보를 편집창에 열었습니다.`, { description: "원본은 바뀌지 않았습니다. 비교한 뒤 저장해야 수정본으로 반영됩니다." });
    },
    onError: (error) => toast("전면 재작성 후보를 만들지 못했습니다.", { description: error.message }),
  });

  const scoreMutation = trpc.manuscript.score.useMutation({
    onSuccess: (result) => {
      setAiStyleScore({ ...result, chunk: activeChunk });
      toast(`청크 ${String(activeChunk).padStart(2, "0")} 문체 점수 평가가 완료되었습니다.`, { description: `종합 ${result.overall}점 · ${result.model}` });
    },
    onError: (error) => toast("문체 점수를 계산하지 못했습니다.", { description: error.message }),
  });

  const batchRewriteMutation = trpc.manuscript.rewrite.useMutation();

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (stored) setImportedChunks({ ...cloneDefault(defaultImportedChunks as ImportedChunks), ...JSON.parse(stored) });
      const edited = window.localStorage.getItem(EDITED_STORAGE_KEY);
      if (edited) setEditedChunks(JSON.parse(edited));
      const storedVersions = window.localStorage.getItem(DRAFT_VERSIONS_STORAGE_KEY);
      if (storedVersions) setDraftVersions(JSON.parse(storedVersions));
      const storedStates = window.localStorage.getItem(STATE_LEDGER_STORAGE_KEY);
      if (storedStates) setStateLedgers({ ...cloneDefault(defaultStateLedgers as unknown as StateLedgers), ...JSON.parse(storedStates) });
      const storedBrief = window.localStorage.getItem(PROJECT_BRIEF_STORAGE_KEY);
      if (storedBrief) {
        const parsedBrief = JSON.parse(storedBrief) as ProjectBrief;
        setProjectBrief(parsedBrief);
        setCastParseReport(parseCastTable(parsedBrief.content));
      }
      const storedStyle = window.localStorage.getItem(STYLE_PROFILE_STORAGE_KEY);
      if (storedStyle) setStyleProfile(JSON.parse(storedStyle));
    } catch {
      window.localStorage.removeItem(STORAGE_KEY);
      window.localStorage.removeItem(EDITED_STORAGE_KEY);
      window.localStorage.removeItem(DRAFT_VERSIONS_STORAGE_KEY);
      window.localStorage.removeItem(STATE_LEDGER_STORAGE_KEY);
      setImportedChunks(cloneDefault(defaultImportedChunks as ImportedChunks));
      setStateLedgers(cloneDefault(defaultStateLedgers as unknown as StateLedgers));
      toast("기본 21청크 원고와 장부를 열었습니다.", { description: "이전 브라우저 보관본은 읽을 수 없어 정본 기본 탑재본으로 안전하게 복구했습니다." });
    } finally {
      setHasHydrated(true);
    }
  }, []);

  useEffect(() => {
    if (hasHydrated) window.localStorage.setItem(STORAGE_KEY, JSON.stringify(importedChunks));
  }, [hasHydrated, importedChunks]);

  useEffect(() => {
    if (hasHydrated) window.localStorage.setItem(EDITED_STORAGE_KEY, JSON.stringify(editedChunks));
  }, [editedChunks, hasHydrated]);

  useEffect(() => {
    if (hasHydrated) window.localStorage.setItem(DRAFT_VERSIONS_STORAGE_KEY, JSON.stringify(draftVersions));
  }, [draftVersions, hasHydrated]);

  useEffect(() => {
    if (hasHydrated) window.localStorage.setItem(STATE_LEDGER_STORAGE_KEY, JSON.stringify(stateLedgers));
  }, [hasHydrated, stateLedgers]);

  useEffect(() => {
    if (hasHydrated) window.localStorage.setItem(PROJECT_BRIEF_STORAGE_KEY, JSON.stringify(projectBrief));
  }, [hasHydrated, projectBrief]);

  useEffect(() => {
    if (hasHydrated) window.localStorage.setItem(STYLE_PROFILE_STORAGE_KEY, JSON.stringify(styleProfile));
  }, [hasHydrated, styleProfile]);

  useEffect(() => {
    setValidationReport(null);
  }, [editedChunks, importedChunks, stateLedgers]);

  useEffect(() => {
    if (!isEditing || !issueFocus || !editorRef.current) return;
    const timer = window.setTimeout(() => {
      const editor = editorRef.current;
      if (!editor) return;
      editor.focus({ preventScroll: true });
      editor.setSelectionRange(issueFocus.start, issueFocus.end);
      const lineNumber = editor.value.slice(0, issueFocus.start).split("\n").length - 1;
      const lineHeight = Number.parseFloat(window.getComputedStyle(editor).lineHeight) || 28;
      editor.scrollTop = Math.max(0, lineNumber * lineHeight - editor.clientHeight * 0.42);
      editor.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 90);
    return () => window.clearTimeout(timer);
  }, [activeChunk, isEditing, issueFocus]);

  const activeImported = importedChunks[activeChunk];
  const sourceContent = activeImported?.content ?? defaultImportedChunks[1].content;
  const activeContent = editedChunks[activeChunk] ?? sourceContent;
  const activeMeta = useMemo(() => baseDraftPassages[activePassage], [activePassage]);
  const importedCount = Object.keys(importedChunks).length;
  const activeLedger = stateLedgers[activeChunk];
  const activeLedgerRows = activeLedger?.characters
    ? Object.entries(activeLedger.characters).slice(0, 4).map(([name, character]) => ({ name, detail: `${character.body_age ?? "?"}세 · ${character.alive === false ? "사망" : "생존"}`, tone: character.alive === false ? "vermilion" : "ink" }))
    : ledgerRows;
  const importedBlocks = useMemo(() => (activeContent ? contentBlocks(activeContent) : []), [activeContent]);
  const hasLocalEdit = Boolean(editedChunks[activeChunk]);
  const loadedChunks = useMemo(() => chunks.filter((chunk) => Boolean(importedChunks[chunk])), [importedChunks]);
  const missingChunks = useMemo(() => chunks.filter((chunk) => !loadedChunks.includes(chunk)), [loadedChunks]);
  const revisedChunks = useMemo(() => loadedChunks.filter((chunk) => Boolean(editedChunks[chunk])), [editedChunks, loadedChunks]);
  const stateLedgerCount = Object.keys(stateLedgers).length;
  const mergeReady = loadedChunks.length === 21;
  const validationPassed = Boolean(validationReport?.passed);
  const selectedIssueText = selectedIssue?.chunk ? (editedChunks[selectedIssue.chunk] ?? importedChunks[selectedIssue.chunk]?.content ?? "") : "";
  const selectedIssueRange = selectedIssue && selectedIssueText ? locateIssueInDraft(selectedIssue, selectedIssueText) : null;
  const selectedIssueStartLine = selectedIssueRange ? selectedIssueText.slice(0, selectedIssueRange.start).split("\n").length - 1 : 0;
  const selectedIssueLines = selectedIssueRange ? selectedIssueText.split("\n").slice(Math.max(0, selectedIssueStartLine - 2), selectedIssueStartLine + 3) : [];
  const sourceLines = sourceContent.split("\n");
  const editedLines = activeContent.split("\n");
  const diffRows = hasLocalEdit ? Array.from({ length: Math.max(sourceLines.length, editedLines.length) }, (_, index) => ({ before: sourceLines[index] ?? "", after: editedLines[index] ?? "", line: index + 1 })).filter((row) => row.before !== row.after) : [];
  const activeVersions = draftVersions[activeChunk] ?? [];
  const filteredVersions = findDraftVersions(activeVersions, versionQuery);
  const selectedVersion = activeVersions.find((version) => version.id === selectedVersionId) ?? activeVersions.at(-1) ?? null;
  const selectedVersionDiff = selectedVersion ? lineDiff(selectedVersion.content, activeContent) : [];
  const relationshipPreview = activeLedger && castParseReport ? previewRelationshipSuggestions(activeLedger, castParseReport) : [];
  const focusedBriefSource = projectBrief && briefEvidenceFocus ? briefExcerpt(projectBrief.content, briefEvidenceFocus) : null;
  const publishedStyleScore = defaultStyleScoreReport.scores.find((score) => score.chunk === activeChunk);
  const publishedOverallAverage = Math.round((defaultStyleScoreReport.scores.reduce((sum, score) => sum + score.overall, 0) / defaultStyleScoreReport.scores.length) * 10) / 10;

  const openFilePicker = () => inputRef.current?.click();
  const openStateFilePicker = () => stateInputRef.current?.click();
  const openBriefFilePicker = () => briefInputRef.current?.click();
  const openBackupFilePicker = () => backupInputRef.current?.click();

  const revealRelationshipEvidence = (evidence: string) => {
    if (!projectBrief) {
      toast("연결된 기획본이 없습니다.", { description: "먼저 GPT 기획본을 가져오면 관계 근거 원문으로 이동할 수 있습니다." });
      return;
    }
    setBriefEvidenceFocus(evidence);
    window.setTimeout(() => briefSourceRef.current?.scrollIntoView({ behavior: "smooth", block: "center" }), 0);
  };

  const selectChunk = (chunk: number) => {
    if (chunk > 1 && !importedChunks[chunk]) {
      toast(`청크 ${String(chunk).padStart(2, "0")} 원고가 아직 없습니다.`, {
        description: "상단의 원고 가져오기에서 해당 마크다운 파일을 선택해 주세요.",
      });
      openFilePicker();
      return;
    }
    setActiveChunk(chunk);
    setActivePassage(0);
    setActiveView("draft");
    setEditing(false);
    setSidebarOpen(false);
    window.setTimeout(() => document.getElementById("script")?.scrollIntoView({ behavior: "smooth", block: "start" }), 40);
  };

  const importFiles = async (fileList: FileList | File[]) => {
    const files = Array.from(fileList).filter((file) => /\.(md|markdown)$/i.test(file.name));
    if (!files.length) {
      toast("마크다운 파일을 선택해 주세요.", { description: "예: chunk_02.md 또는 chunk_21.md" });
      return;
    }

    const results = await Promise.all(
      files.map(async (file) => ({ file, content: await file.text() })),
    );
    const next: ImportedChunks = {};
    const invalid: string[] = [];

    results.forEach(({ file, content }) => {
      const chunk = extractChunkNumber(file.name, content);
      if (!chunk) {
        invalid.push(file.name);
        return;
      }
      next[chunk] = {
        chunk,
        title: extractTitle(content, chunk),
        content,
        sourceName: file.name,
        importedAt: new Date().toISOString(),
      };
    });

    if (Object.keys(next).length) {
      setImportedChunks((previous) => ({ ...previous, ...next }));
      setEditedChunks((previous) => {
        const cleared = { ...previous };
        Object.keys(next).forEach((chunk) => delete cleared[Number(chunk)]);
        return cleared;
      });
      setDraftVersions((previous) => {
        const cleared = { ...previous };
        Object.keys(next).forEach((chunk) => delete cleared[Number(chunk)]);
        return cleared;
      });
      const importedNumbers = Object.keys(next).map(Number).sort((a, b) => a - b);
      setActiveChunk(importedNumbers[0]);
      setActivePassage(0);
      setActiveView("draft");
      toast(`${importedNumbers.length}개 청크를 연결했습니다.`, {
        description: `청크 ${importedNumbers.map((chunk) => String(chunk).padStart(2, "0")).join(", ")}이 물길 지도에 반영되었습니다.`,
      });
    }
    if (invalid.length) {
      toast(`${invalid.length}개 파일은 건너뛰었습니다.`, {
        description: "파일명에 chunk_02 같은 청크 번호를 넣거나 첫 줄에 [청크 02/21]을 넣어 주세요.",
      });
    }
  };

  const handleInput = (event: ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) void importFiles(event.target.files);
    event.target.value = "";
  };

  const importStateFiles = async (fileList: FileList | File[]) => {
    const files = Array.from(fileList).filter((file) => file.type === "application/json" || /\.json$/i.test(file.name));
    if (!files.length) {
      toast("상태 장부 JSON 파일을 선택해 주세요.", { description: "예: state_chunk_02.json 또는 chunk_02.json" });
      return;
    }
    const results = await Promise.all(files.map(async (file) => ({ file, text: await file.text() })));
    const next: StateLedgers = {};
    const invalid: string[] = [];
    results.forEach(({ file, text }) => {
      try {
        const state = JSON.parse(text) as StateLedger;
        const chunk = stateChunkFromFile(file.name, state);
        if (!chunk || !state.characters || !state.relationships) {
          invalid.push(file.name);
          return;
        }
        next[chunk] = { ...state, chunk };
      } catch {
        invalid.push(file.name);
      }
    });
    if (Object.keys(next).length) {
      setStateLedgers((previous) => ({ ...previous, ...next }));
      const imported = Object.keys(next).map(Number).sort((a, b) => a - b);
      toast(`${imported.length}개 상태 장부를 연결했습니다.`, { description: `청크 ${imported.map((chunk) => String(chunk).padStart(2, "0")).join(", ")}의 연령·관계·소지품 검수가 활성화됩니다.` });
    }
    if (invalid.length) toast(`${invalid.length}개 장부는 건너뛰었습니다.`, { description: "chunk 값, characters, relationships가 있는 정본 JSON인지 확인해 주세요." });
  };

  const handleStateInput = (event: ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) void importStateFiles(event.target.files);
    event.target.value = "";
  };

  const handleBriefInput = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const content = await file.text();
    if (!content.trim()) {
      toast("비어 있는 기획본은 가져올 수 없습니다.");
      return;
    }
    setProjectBrief({ sourceName: file.name, content, importedAt: new Date().toISOString() });
    const report = parseCastTable(content);
    setCastParseReport(report);
    toast("GPT 기획본을 작업실에 연결했습니다.", { description: report.suggestions.length ? `인물 ${report.suggestions.map((item) => item.name).join(", ")} 정보를 읽었습니다. 장부 자동 채움을 실행해 검증하세요.` : "인물표 정보를 찾지 못했습니다. 기획본에 이름과 연령을 추가해 주세요." });
    event.target.value = "";
  };

  const exportWorkspaceBackup = () => {
    downloadJson({ schema: BACKUP_SCHEMA, createdAt: new Date().toISOString(), projectBrief, importedChunks, editedChunks, draftVersions, stateLedgers, styleProfile }, "칠성탈명록_작업실_백업.json");
    toast("작업실 백업 파일을 준비했습니다.", { description: "대본, 수정본, 상태 장부, GPT 기획본을 한 파일에 담았습니다." });
  };

  const restoreWorkspaceBackup = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      const backup = JSON.parse(await file.text()) as { schema?: string; projectBrief?: ProjectBrief | null; importedChunks?: ImportedChunks; editedChunks?: Record<number, string>; draftVersions?: DraftVersions; stateLedgers?: StateLedgers; styleProfile?: StyleProfile | null };
      if (backup.schema !== BACKUP_SCHEMA || !backup.importedChunks || !backup.editedChunks || !backup.stateLedgers) throw new Error("invalid");
      setImportedChunks(backup.importedChunks);
      setEditedChunks(backup.editedChunks);
      setDraftVersions(backup.draftVersions ?? {});
      setStateLedgers(backup.stateLedgers);
      setProjectBrief(backup.projectBrief ?? null);
      setCastParseReport(backup.projectBrief ? parseCastTable(backup.projectBrief.content) : null);
      setStyleProfile(backup.styleProfile ?? null);
      setActiveChunk(1);
      setActiveView("draft");
      toast("작업실 백업을 복원했습니다.", { description: "현재 브라우저의 대본·장부·기획본이 백업 내용으로 교체되었습니다." });
    } catch {
      toast("작업실 백업을 읽지 못했습니다.", { description: "이 웹에서 내보낸 칠성탈명록_작업실_백업.json 파일인지 확인해 주세요." });
    } finally {
      event.target.value = "";
    }
  };

  const clearImported = () => {
    setImportedChunks(cloneDefault(defaultImportedChunks as ImportedChunks));
    setEditedChunks({});
    setDraftVersions({});
    setActiveChunk(1);
    toast("개인 수정본을 비우고 기본 탑재 원고로 되돌렸습니다.", { description: "21청크 정본 인수 원고와 상태 장부는 항상 남아 있습니다." });
  };

  const restoreCanonicalWorkspace = () => {
    if (!window.confirm("이 브라우저의 개인 수정본·버전·상태 장부 수정을 비우고 최신 정본으로 복구합니다. 계속할까요?")) return;
    setImportedChunks(cloneDefault(defaultImportedChunks as ImportedChunks));
    setEditedChunks({});
    setDraftVersions({});
    setStateLedgers(cloneDefault(defaultStateLedgers as unknown as StateLedgers));
    setValidationReport(null);
    setActiveChunk(1);
    setActiveView("draft");
    toast("최신 정본 작업실로 복구했습니다.", { description: "이제 전체 검수 뒤 현재 작업실 통합본도 내려받을 수 있습니다." });
  };

  const clearStateLedgers = () => {
    setStateLedgers(cloneDefault(defaultStateLedgers as unknown as StateLedgers));
    toast("개인 장부 수정을 비우고 기본 상태 장부로 되돌렸습니다.", { description: "21청크 정본 장부는 항상 연결된 상태로 유지됩니다." });
  };

  const startEditing = () => {
    if (!activeContent) return;
    setIssueFocus(null);
    setDraftText(activeContent);
    setEditing(true);
  };

  const startLedgerEditing = () => {
    if (!activeLedger) {
      toast("먼저 상태 장부 JSON을 가져와 주세요.", { description: `청크 ${String(activeChunk).padStart(2, "0")}의 장부를 연결하면 웹에서 바로 수정할 수 있습니다.` });
      openStateFilePicker();
      return;
    }
    setLedgerText(JSON.stringify(activeLedger, null, 2));
    setLedgerEditing(true);
  };

  const saveLedger = () => {
    try {
      const parsed = JSON.parse(ledgerText) as StateLedger;
      if (!parsed.characters || !parsed.relationships) throw new Error("schema");
      setStateLedgers((previous) => ({ ...previous, [activeChunk]: { ...parsed, chunk: activeChunk } }));
      setLedgerEditing(false);
      toast(`청크 ${String(activeChunk).padStart(2, "0")} 상태 장부를 보관했습니다.`, { description: "연령·관계·소지품 정밀 검수에 즉시 반영됩니다." });
    } catch {
      toast("상태 장부 JSON 형식이 맞지 않습니다.", { description: "characters와 relationships 객체를 유지한 유효한 JSON인지 확인해 주세요." });
    }
  };

  const exportLedger = () => {
    if (!activeLedger) return;
    downloadJson(activeLedger, `state_chunk_${String(activeChunk).padStart(2, "0")}.json`);
    toast(`state_chunk_${String(activeChunk).padStart(2, "0")}.json 파일을 준비했습니다.`);
  };

  const openLedgerForm = () => {
    if (!activeLedger) return openStateFilePicker();
    const hero = activeLedger.characters?.강무진;
    const bokAh = activeLedger.characters?.복아;
    const relation = activeLedger.relationships?.["강무진|복아"];
    setLedgerForm({ location: activeLedger.location ?? "", heroAge: String(hero?.body_age ?? ""), bokAhMind: String(bokAh?.mind_age ?? 20), bokAhBody: String(bokAh?.body_age ?? 70), possessions: (hero?.possessions ?? []).join(", "), relationshipStage: String(relation?.stage ?? "") });
    setLedgerFormOpen(true);
  };

  const saveLedgerForm = () => {
    if (!activeLedger) return;
    setStateLedgers((previous) => ({ ...previous, [activeChunk]: { ...activeLedger, location: ledgerForm.location, characters: { ...activeLedger.characters, 강무진: { ...activeLedger.characters?.강무진, body_age: Number(ledgerForm.heroAge), possessions: ledgerForm.possessions.split(",").map((item) => item.trim()).filter(Boolean) }, 복아: { ...activeLedger.characters?.복아, mind_age: Number(ledgerForm.bokAhMind), actual_age: 20, body_age: Number(ledgerForm.bokAhBody) } }, relationships: { ...activeLedger.relationships, "강무진|복아": { ...activeLedger.relationships?.["강무진|복아"], stage: Number(ledgerForm.relationshipStage) } } } }));
    setLedgerFormOpen(false);
    toast("장부 폼 수정본을 보관했습니다.");
  };

  const applyPlanningCast = () => {
    if (!projectBrief) return openBriefFilePicker();
    if (!activeLedger) {
      toast("먼저 현재 청크의 상태 장부를 연결해 주세요.", { description: "인물표는 연결된 장부의 인물 항목에만 적용됩니다." });
      openStateFilePicker();
      return;
    }
    const report = castParseReport ?? parseCastTable(projectBrief.content);
    setCastParseReport(report);
    const applied = applyCastSuggestions(activeLedger, report);
    if (!applied.applied.length) {
      toast("새로 채울 인물표 항목이 없습니다.", { description: applied.skipped.length ? applied.skipped.join(" · ") : "기획본에 적용 가능한 이름·연령·소지품·관계 단계 항목이 없습니다." });
      return;
    }
    setStateLedgers((previous) => ({ ...previous, [activeChunk]: applied.ledger }));
    toast(`${applied.applied.join(", ")} 정보를 장부에 반영했습니다.`, { description: "현재 청크의 관계 상한을 넘는 제안은 건너뛰고, 반영된 관계에는 기획본 근거를 남겼습니다. 정밀 검수를 다시 실행해 주세요." });
  };

  const runRhythmCheck = () => {
    const notices = inspectRhythmWithRanges(activeContent, styleProfile);
    setRhythmNotices(notices);
    toast(notices.length ? `문장 리듬 확인 ${notices.length}건` : "반복 리듬 자동 경고가 없습니다.");
  };

  const requestFullRewrite = () => {
    if (!activeContent) {
      toast("재작성할 원고가 없습니다.");
      return;
    }
    rewriteMutation.mutate({ chunk: activeChunk, content: activeContent, projectBrief: projectBrief?.content.slice(0, 5_000) });
  };

  const requestStyleScore = () => {
    if (!activeContent) {
      toast("평가할 원고가 없습니다.");
      return;
    }
    scoreMutation.mutate({ chunk: activeChunk, content: activeContent, projectBrief: projectBrief?.content.slice(0, 5_000) });
  };

  const startBatchRewrite = async () => {
    if (batchRewriteState.running) return;
    const loaded = chunks.filter((chunk) => Boolean(importedChunks[chunk]));
    if (loaded.length !== 21) {
      toast("21청크 원고가 모두 연결된 뒤 전면 재작성을 시작할 수 있습니다.");
      return;
    }
    const completed = batchRewriteState.completed.filter((chunk) => loaded.includes(chunk));
    const queue = loaded.filter((chunk) => !completed.includes(chunk));
    if (!queue.length) {
      toast("21청크 전면 재작성이 이미 완료되었습니다.");
      return;
    }
    batchStopRef.current = false;
    let nextCompleted = [...completed];
    setBatchRewriteState({ running: true, stopRequested: false, currentChunk: queue[0] ?? null, completed: nextCompleted, error: null });

    for (const chunk of queue) {
      if (batchStopRef.current) break;
      const content = editedChunks[chunk] ?? importedChunks[chunk]?.content;
      if (!content) continue;
      setBatchRewriteState({ running: true, stopRequested: false, currentChunk: chunk, completed: nextCompleted, error: null });
      try {
        const result = await batchRewriteMutation.mutateAsync({ chunk, content, projectBrief: projectBrief?.content.slice(0, 5_000) });
        setEditedChunks((previous) => ({ ...previous, [chunk]: result.rewrittenMarkdown }));
        setDraftVersions((previous) => captureDraftVersion(previous, chunk, result.rewrittenMarkdown, "수정본 저장", `AI 전면 재작성 · ${result.model}`));
        nextCompleted = [...nextCompleted, chunk];
        setBatchRewriteState({ running: true, stopRequested: false, currentChunk: chunk, completed: nextCompleted, error: null });
      } catch (error) {
        const message = error instanceof Error ? error.message : "알 수 없는 오류";
        setBatchRewriteState({ running: false, stopRequested: false, currentChunk: null, completed: nextCompleted, error: message });
        toast(`청크 ${String(chunk).padStart(2, "0")}에서 배치 재작성이 멈췄습니다.`, { description: "이미 완료된 청크는 보관됐습니다. 재개를 누르면 다음 청크부터 이어갑니다." });
        return;
      }
    }

    const interrupted = batchStopRef.current;
    setBatchRewriteState({ running: false, stopRequested: false, currentChunk: null, completed: nextCompleted, error: null });
    toast(interrupted ? "전면 재작성 배치를 중단했습니다." : "21청크 전면 재작성 후보를 모두 보관했습니다.", { description: interrupted ? `완료 ${nextCompleted.length}/21 · 재개하면 다음 청크부터 이어갑니다.` : "각 청크는 버전 장부에서 원문과 비교·복원할 수 있습니다." });
  };

  const requestBatchStop = () => {
    batchStopRef.current = true;
    setBatchRewriteState((previous) => ({ ...previous, stopRequested: true }));
    toast("현재 청크를 마친 뒤 배치 재작성을 멈춥니다.");
  };

  const createBriefDraft = () => {
    if (!projectBrief) return openBriefFilePicker();
    const excerpt = projectBrief.content.replace(/\s+/g, " ").slice(0, 420);
    const rhythmCue = styleProfile?.averageSentenceLength && styleProfile.averageSentenceLength <= 19
      ? "짧은 문장으로 결단을 찍고, 바로 다음 문장에서 행동의 결과를 잇는다."
      : styleProfile?.averageSentenceLength && styleProfile.averageSentenceLength >= 30
        ? "공간과 행동을 한 문장에 묶되, 결정적 결과에서는 짧게 내려찍는다."
        : "짧은 문장과 중간 길이 문장을 섞어 행동과 반응이 한 호흡에 이어지게 한다.";
    const heading = activeChunk === 1 ? "## Hook" : activeChunk === 20 ? "## Climax" : activeChunk === 21 ? "[END]\n## End" : "";
    const endingCue = styleProfile?.preferredEndings.length ? `사용자가 자주 남긴 종결어미는 ${styleProfile.preferredEndings.map((item) => item.ending).join(", ")}다. 한 문단에 몰지 않는다.` : "";
    const seeded = `[청크 ${String(activeChunk).padStart(2, "0")}/21]\n\n${heading}\n\n${excerpt}\n\n${rhythmCue} ${endingCue}`.replace(/\n{3,}/g, "\n\n");
    setEditedChunks((previous) => ({ ...previous, [activeChunk]: seeded }));
    setDraftText(seeded);
    setEditing(true);
    toast(`청크 ${String(activeChunk).padStart(2, "0")} 기획 초안을 만들었습니다.`);
  };

  const openIssueInEditor = (issue: ValidationIssue) => {
    if (!issue.chunk) {
      toast("전체 원고 오류입니다.", { description: "개별 청크가 아닌 병합 구조·반복·분량을 먼저 확인해 주세요." });
      return;
    }
    const text = editedChunks[issue.chunk] ?? importedChunks[issue.chunk]?.content ?? "";
    if (!text) {
      toast(`청크 ${String(issue.chunk).padStart(2, "0")} 원고가 없습니다.`, { description: "오류 위치로 이동하려면 먼저 해당 마크다운을 가져와야 합니다." });
      openFilePicker();
      return;
    }
    const range = locateIssueInDraft(issue, text);
    setSelectedIssue(issue);
    setActiveChunk(issue.chunk);
    setActivePassage(0);
    setActiveView("draft");
    setSidebarOpen(false);
    setDraftText(text);
    setIssueFocus({ issue, ...range });
    setEditing(true);
    window.setTimeout(() => document.getElementById("script")?.scrollIntoView({ behavior: "smooth", block: "center" }), 40);
    toast(`청크 ${String(issue.chunk).padStart(2, "0")}의 '${range.label}' 위치로 이동했습니다.`, { description: issue.code.includes("state") || issue.code.includes("age") || issue.code.includes("relationship") ? "상태 장부 오류는 대본의 첫 관련 표현을 선택합니다. 장부 값도 함께 수정해 주세요." : "선택된 문장을 수정한 뒤 수정본 저장과 전체 검수를 다시 실행하세요." });
  };

  const saveDraft = () => {
    if (!draftText.trim()) {
      toast("빈 대본은 저장할 수 없습니다.");
      return;
    }
    setDraftVersions((previous) => captureDraftVersion(previous, activeChunk, draftText, "수정본 저장", versionMemo));
    setEditedChunks((previous) => ({ ...previous, [activeChunk]: draftText }));
    setStyleProfile((previous) => updateStyleProfile(previous, sourceContent, draftText));
    setVersionMemo("");
    setEditing(false);
    toast(`청크 ${String(activeChunk).padStart(2, "0")} 수정본을 보관했습니다.`, { description: "현재 브라우저에 자동 저장되며 마크다운으로 바로 내려받을 수 있습니다." });
  };

  const restoreDraftVersion = (version: DraftVersion) => {
    if (version.content === activeContent) {
      toast("현재 원고와 같은 버전입니다.");
      return;
    }
    setDraftVersions((previous) => captureDraftVersion(captureDraftVersion(previous, activeChunk, activeContent, "복원 전 자동 보관"), activeChunk, version.content, "버전 복원"));
    setEditedChunks((previous) => ({ ...previous, [activeChunk]: version.content }));
    setDraftText(version.content);
    setEditing(false);
    setVersionsOpen(false);
    toast(`청크 ${String(activeChunk).padStart(2, "0")}을 선택한 보관본으로 복원했습니다.`, { description: "복원 직전 원고도 자동 스냅샷으로 남겼습니다." });
  };

  const openRhythmInEditor = (notice: RhythmNotice) => {
    const issue: ValidationIssue = { level: "warning", code: "rhythm", chunk: activeChunk, message: `${notice.label} · ${notice.summary}` };
    setDraftText(activeContent);
    setIssueFocus({ issue, start: notice.start, end: notice.end, label: notice.label });
    setEditing(true);
    window.setTimeout(() => document.getElementById("script")?.scrollIntoView({ behavior: "smooth", block: "center" }), 40);
  };

  const resetDraft = () => {
    setEditedChunks((previous) => {
      const next = { ...previous };
      delete next[activeChunk];
      return next;
    });
    setDraftText(sourceContent);
    setEditing(false);
    toast("가져온 원본으로 되돌렸습니다.");
  };

  const exportMarkdown = () => {
    if (!activeContent) {
      toast("내보낼 원고가 없습니다.");
      return;
    }
    downloadMarkdown(activeContent, `chunk_${String(activeChunk).padStart(2, "0")}.md`);
    toast(`chunk_${String(activeChunk).padStart(2, "0")}.md 파일을 준비했습니다.`, { description: hasLocalEdit ? "수정본이 포함되었습니다." : "현재 원고를 그대로 내보냈습니다." });
  };

  const validateWorkspace = (): ProjectValidationReport => {
    const draftReport = validateChilseongDrafts(importedChunks, editedChunks, importedChunks[1]?.content ?? baseChunkOneMarkdown);
    const stateReport = validateStateLedgers(stateLedgers);
    return {
      ...draftReport,
      errors: [...draftReport.errors, ...stateReport.errors],
      warnings: [...draftReport.warnings, ...stateReport.warnings],
      stateCheckedChunks: stateReport.checkedChunks,
      stateMissingChunks: stateReport.missingChunks,
      passed: draftReport.errors.length === 0 && draftReport.missingChunks.length === 0 && stateReport.errors.length === 0 && stateReport.missingChunks.length === 0,
    };
  };

  const exportFeatureFilm = () => {
    if (!mergeReady) {
      toast("아직 모든 청크가 연결되지 않았습니다.", {
        description: `청크 ${missingChunks.map((chunk) => String(chunk).padStart(2, "0")).join(", ")}을 가져오면 장편 병합 파일을 만들 수 있습니다.`,
      });
      return;
    }
    const report = validateWorkspace();
    setValidationReport(report);
    if (!report.passed) {
      window.setTimeout(() => document.getElementById("validation-recovery")?.scrollIntoView({ behavior: "smooth", block: "center" }), 0);
      toast("현재 작업실 통합본은 잠겼습니다.", { description: `오류 ${report.errors.length}개를 먼저 확인하거나, 아래의 최신 정본 직접 받기를 이용하세요.` });
      return;
    }
    const featureFilmMarkdown = buildFeatureFilmMarkdown(importedChunks, editedChunks);
    downloadMarkdown(featureFilmMarkdown, "칠성탈명록_장편_통합본.md");
    toast("장편 통합본을 준비했습니다.", { description: `21개 청크와 수정본 ${revisedChunks.length}개가 번호순으로 병합되었습니다.` });
  };

  const exportCanonicalFeatureFilm = () => {
    const featureFilmMarkdown = buildFeatureFilmMarkdown(defaultImportedChunks as ImportedChunks);
    downloadMarkdown(featureFilmMarkdown, "칠성탈명록_완성본.md");
    toast("최신 정본 통합본을 준비했습니다.", { description: "이 브라우저의 이전 원고·수정본·장부와 무관한 최신 21청크 정본입니다." });
  };

  const runContinuityCheck = () => {
    const report = validateWorkspace();
    setValidationReport(report);
    if (report.passed) {
      toast("연속성 검수를 통과했습니다.", { description: `오류 없이 병합할 수 있습니다. 경고 ${report.warnings.length}개는 수동으로 확인해 주세요.` });
      return;
    }
    toast("연속성 검수에서 확인할 항목이 발견되었습니다.", { description: `오류 ${report.errors.length}개, 경고 ${report.warnings.length}개를 대본 아래 장부에서 확인하세요.` });
  };

  const displayTitle = activeChunk === 1 ? "Hook · 별이 떨어진 밤" : activeContent ? extractTitle(activeContent, activeChunk) : "원고를 기다리는 물길";
  const heroTitle = activeChunk === 1 ? "세월은 장부에 남고,\n장면은 강을 건넌다." : activeImported ? extractTitle(activeContent, activeChunk) : "다음 청크의\n원고를 가져오세요.";
  const heroDescription = activeImported
    ? `${activeImported.sourceName}에서 연결했습니다. 가져온 원고는 이 브라우저의 장부에 보관됩니다.`
    : "별이 추락한 은사촌. 사공 강무진이 늙어 버린 사람들을 실은 배를 어둠 너머로 민다.";

  return (
    <div className="studio-shell min-h-screen bg-[#f1eee5] text-[#1c2527]">
      <input ref={inputRef} className="file-input" type="file" multiple accept=".md,.markdown,text/markdown" onChange={handleInput} />
      <input ref={stateInputRef} className="file-input" type="file" multiple accept=".json,application/json" onChange={handleStateInput} />
      <input ref={briefInputRef} className="file-input" type="file" accept=".md,.markdown,text/markdown,.txt,text/plain" onChange={handleBriefInput} />
      <input ref={backupInputRef} className="file-input" type="file" accept=".json,application/json" onChange={restoreWorkspaceBackup} />
      <header className="topbar">
        <button aria-label="청크 인덱스 열기" className="mobile-menu-button" onClick={() => setSidebarOpen(true)}><Menu size={21} /></button>
        <a className="brand-lockup" href="#top" aria-label="무협스튜디오 처음으로">
          <span className="brand-seal" aria-hidden="true"><img className="brand-mark" src={assets.logo} alt="" /><i className="seal-pole" /><span className="seal-ripples">{Array.from({ length: 7 }, (_, index) => <i key={index} />)}</span></span>
          <span><strong>무협스튜디오</strong><em>장편 제작 작업실</em></span>
        </a>
        <div className="topbar-status"><span className="pulse-dot" /><span>연속성 장부 연결됨</span></div>
        <div className="topbar-actions">
          <button className="import-action" onClick={openFilePicker}><FileUp size={16} /> 원고 가져오기</button>
          <button className="quiet-action" onClick={() => toast("공유 링크 준비 중", { description: "현재 화면은 개인 스튜디오용 정적 미리보기입니다." })}><ArrowUpRight size={16} /> 공유</button>
          <button className="ink-action" onClick={() => document.getElementById("script")?.scrollIntoView({ behavior: "smooth" })}><BookOpenText size={16} /> 대본 열기</button>
        </div>
      </header>

      <div className="site-layout">
        <aside className={`chapter-rail ${isSidebarOpen ? "is-open" : ""}`} aria-label="청크 인덱스">
          <div className="rail-heading"><span>물길 지도</span><button aria-label="청크 인덱스 닫기" className="rail-close" onClick={() => setSidebarOpen(false)}><X size={19} /></button></div>
          <p className="rail-kicker">한 편의 영화 · 21개 출력 청크</p>
          <nav className="chapter-list">
            {chunks.map((chunk) => {
              const available = Boolean(importedChunks[chunk]);
              const active = chunk === activeChunk;
              const title = importedChunks[chunk]?.title ?? `청크 ${String(chunk).padStart(2, "0")}`;
              return (
                <button className={`chapter-entry ${active ? "is-active" : ""} ${available ? "is-loaded" : ""}`} onClick={() => selectChunk(chunk)} key={chunk} aria-current={active ? "page" : undefined}>
                  <span className="chapter-no">{String(chunk).padStart(2, "0")}</span>
                  <span className="chapter-copy"><b>{title}</b><small>{available ? (editedChunks[chunk] ? "수정본 보관됨" : chunk === 1 ? "Hook · CTA · Intro" : "정본 원고 연결됨") : "대본 대기"}</small></span>
                  {active ? <span className="chapter-current">현재</span> : available ? <Check size={15} className="chapter-check" /> : <MoreHorizontal size={17} />}
                </button>
              );
            })}
          </nav>
          <div className="rail-footer"><img src={assets.map} alt="일곱 별과 물길을 표현한 수묵 지도" /><span>기본 탑재 원고 {importedCount}/21</span></div>
        </aside>

        <main id="top" className="workspace">
          <section className="hero-panel">
            <img className="hero-art" src={assets.hero} alt="별빛이 흐르는 밤 강가의 낡은 배" />
            <div className="hero-veil" />
            <div className="hero-current-lines" aria-hidden="true"><i /><i /><i /><i /><i /><i /><i /></div>
            <div className="hero-meta"><span className="meta-rule" /><span>한 편의 영화 · {activeChunk > 1 ? "연결 원고" : "첫 물길"}</span></div>
            <div className="hero-content">
              <p className="section-eyebrow">CHUNK {String(activeChunk).padStart(2, "0")} / 21</p>
              <h1>{heroTitle.split("\n").map((line) => <span key={line}>{line}<br /></span>)}</h1>
              <p>{heroDescription}</p>
              <div className="flow-legend" aria-label="세 갈래 작업 구조"><span>01 물길 지도</span><i /><span>02 대본 롤</span><i /><span>03 연속성 장부</span></div>
              <div className="hero-controls">
                <button className="vermilion-action" onClick={() => document.getElementById("script")?.scrollIntoView({ behavior: "smooth" })}><Play size={15} fill="currentColor" /> 청크 {activeChunk} 읽기</button>
                <button className="hero-link" onClick={openFilePicker}><UploadCloud size={16} /> 원고 추가하기</button>
              </div>
            </div>
            <div className="hero-bottom-line"><span>{activeImported ? `원본 파일 · ${activeImported.sourceName}` : "은사촌 · 요광 추락 직후"}</span><span>{activeImported ? "브라우저에 보관됨" : "목표 3,000자"}</span></div>
          </section>

          <section className={`import-strip ${isDragging ? "is-dragging" : ""}`} onDragEnter={(event) => { event.preventDefault(); setDragging(true); }} onDragOver={(event) => event.preventDefault()} onDragLeave={() => setDragging(false)} onDrop={(event) => { event.preventDefault(); setDragging(false); void importFiles(event.dataTransfer.files); }}>
            <span className="import-stamp"><UploadCloud size={18} /></span>
            <div className="import-copy"><b>기본 21청크 원고가 연결되었습니다</b><span>새 마크다운을 놓으면 해당 청크 원본을 덮어쓰고, 수정본은 별도로 버전 보관합니다.</span></div>
            <div className="import-summary"><strong>{importedCount}</strong><span> / 21 탑재됨</span></div>
            <button className="import-select" onClick={openFilePicker}>원고 교체</button>
            <button className="clear-imports" onClick={clearImported} title="개인 수정본을 비우고 기본 원고로 복원"><RotateCcw size={15} /></button>
          </section>

          <section className="project-brief-handoff" aria-label="무협기획안 상위 제작 단계">
            <div className="project-brief-handoff-head"><div><p className="section-eyebrow ink-eyebrow">01 · 상위 카테고리</p><h2>무협기획안</h2><p>작품 세계관, 인물, 결말 잠금, 흥행 장치를 먼저 첨부합니다. 기획안 제목은 현재 작품명이 되고, 아래 대본 작성·상태 장부·제작 대시보드의 기준점으로 이어집니다.</p></div><button className="project-brief-upload" onClick={openBriefFilePicker}><BookMarked size={16} />{projectBrief ? "무협기획안 교체" : "무협기획안 첨부"}</button></div>
            <div className="project-brief-handoff-flow"><span className="is-active">01 무협기획안</span><i>→</i><span>02 상태 장부</span><i>→</i><span>03 청크 대본 작성</span><i>→</i><span>04 제작 대시보드</span></div>
            {projectBrief ? <div className="project-brief-loaded"><div><b>{activeWorkTitle}</b><small>{projectBrief.sourceName} · {new Date(projectBrief.importedAt).toLocaleString("ko-KR")}</small></div><pre>{projectBrief.content.slice(0, 520)}{projectBrief.content.length > 520 ? "\n…" : ""}</pre></div> : <div className="project-brief-empty"><FileText size={18} />md 또는 txt 기획안을 첨부하면 작품 제목·인물표·관계 근거가 하위 작업에 연결됩니다.</div>}
          </section>

          <section className="workspace-kit" aria-label="무협기획안 기반 작업실 파일 관리">
            <div className="workspace-kit-heading"><span className="workspace-kit-seal"><BookMarked size={20} /></span><div><p className="section-eyebrow ink-eyebrow">02 · 하위 작업</p><b>무협기획안을 기준으로 상태 장부와 청크 대본을 이어갑니다.</b></div></div>
            <div className="workspace-kit-actions">
              <button className={`workspace-file ${projectBrief ? "is-loaded" : ""}`} onClick={openBriefFilePicker}><BookMarked size={16} /><span><b>{projectBrief ? "무협기획안 연결됨" : "무협기획안 첨부하기"}</b><small>{projectBrief ? projectBrief.sourceName : "기획안을 md 또는 txt로 가져오기"}</small></span></button>
              <button className={`workspace-file ${(castParseReport?.suggestions.length || castParseReport?.relationships.length) ? "is-loaded" : ""}`} onClick={applyPlanningCast}><FileJson size={16} /><span><b>인물표 장부 반영</b><small>{(castParseReport?.suggestions.length || castParseReport?.relationships.length) ? `인물 ${castParseReport?.suggestions.length ?? 0}명 · 관계 ${castParseReport?.relationships.length ?? 0}건 추출` : "기획본의 이름·연령·소지품·관계 채움"}</small></span></button>
              <button className={`workspace-file ${stateLedgerCount === 21 ? "is-loaded" : ""}`} onClick={openStateFilePicker}><FileJson size={16} /><span><b>상태 장부 {stateLedgerCount}/21</b><small>연령·관계·소지품 JSON 연결</small></span></button>
              <button className="workspace-file" onClick={exportWorkspaceBackup}><Download size={16} /><span><b>작업실 백업</b><small>대본·수정본·장부·기획본 저장</small></span></button>
              <button className="workspace-file" onClick={openBackupFilePicker}><ArchiveRestore size={16} /><span><b>백업 복원</b><small>다른 기기에서 작업 이어가기</small></span></button>
            </div>
            <p className="style-profile-note"><Sparkles size={14} /> {styleGuidance(styleProfile)}</p>
            {castParseReport?.relationships.length ? <section className="relationship-preview" aria-label="기획본 관계 근거 미리보기"><div className="relationship-preview-head"><div><p className="ledger-overline">관계 근거 미리보기</p><h3>장부에 반영되기 전후를 확인합니다.</h3></div><button className="text-action" onClick={() => setRelationshipPreviewOpen((open) => !open)}>{isRelationshipPreviewOpen ? "닫기" : `관계 ${castParseReport.relationships.length}건 보기`}</button></div>{isRelationshipPreviewOpen && (activeLedger ? <div className="relationship-preview-list">{relationshipPreview.map((item) => <article className={`relationship-proof is-${item.status}`} key={item.pair}><div className="relationship-proof-head"><b>{item.pair.replace("|", " · ")}</b><span>{item.status === "apply" ? "반영 가능" : item.status === "same" ? "현재 유지" : "반영 보류"}</span></div><div className="relationship-stage-flow"><small>현재 {item.currentStage ?? "미기록"}단계</small><i>→</i><strong>{item.nextStage ?? item.proposedStage}단계</strong>{item.cap !== undefined && <em>상한 {item.cap}</em>}</div>{item.label && <p className="relationship-label">{item.label}</p>}<p className="relationship-message">{item.message}</p><blockquote>{item.evidence.map((evidence) => <button type="button" className="relationship-evidence-link" onClick={() => revealRelationshipEvidence(evidence)} key={evidence}>{evidence}<ArrowUpRight size={12} /></button>)}</blockquote></article>)}</div> : <p className="relationship-preview-empty">현재 청크의 상태 장부를 가져오면 관계 단계와 근거를 반영 전후로 대조할 수 있습니다.</p>)}</section> : null}
            {focusedBriefSource && <section ref={briefSourceRef} className="brief-source-focus" aria-live="polite"><div><p className="ledger-overline">기획본 원문 위치</p><h3>{projectBrief?.sourceName} · {focusedBriefSource.line ? `${focusedBriefSource.line}행 부근` : "근거 문장"}</h3></div><button className="text-action" onClick={() => setBriefEvidenceFocus(null)}><X size={14} /> 닫기</button><pre>{focusedBriefSource.excerpt}</pre></section>}
            {stateLedgerCount > 0 && <button className="workspace-clear" onClick={clearStateLedgers}><Trash2 size={14} /> 장부 비우기</button>}
          </section>

          <section className="project-identity" aria-label="현재 제작 작품">
            <div><p className="section-eyebrow ink-eyebrow">현재 제작 작품</p><h2>{activeWorkTitle}</h2></div>
            <p>{projectBrief ? `기획본 ${projectBrief.sourceName}에서 제목을 연결했습니다.` : "기획본을 가져오면 이 영역이 새 작품 제목으로 자동 전환됩니다."}</p>
          </section>

          <ProductionPipeline
            title={activeWorkTitle}
            importedChunks={importedChunks}
            editedChunks={editedChunks}
            scriptFingerprint={sentenceFingerprint(importedChunks, editedChunks)}
            scriptReady={mergeReady && validateWorkspace().passed}
          />

          <section className={`merge-dock ${mergeReady ? "is-ready" : ""}`} aria-label="장편 통합본 내보내기">
            <div className="merge-seal"><BookDown size={21} /></div>
            <div className="merge-copy"><span>장편 통합본</span><b>21개 청크를 하나의 마크다운으로 묶습니다.</b><small>{!mergeReady ? `현재 ${loadedChunks.length}/21 연결됨 · 청크 ${missingChunks.map((chunk) => String(chunk).padStart(2, "0")).join(", ")} 대기` : validationPassed ? `대본·상태 장부 정밀 검수 통과 · 수정본 ${revisedChunks.length}개를 포함합니다.` : stateLedgerCount < 21 ? `상태 장부 ${stateLedgerCount}/21 연결됨 · JSON 장부를 모두 가져온 뒤 검수하세요.` : "통합본 내보내기 전 정밀 연속성 검수를 실행해 주세요."}</small></div>
            <div className="merge-progress"><strong>{loadedChunks.length}</strong><span>/ 21</span><i><em style={{ width: `${(loadedChunks.length / 21) * 100}%` }} /></i></div>
            <div className="merge-actions"><button className="merge-export" onClick={exportFeatureFilm} disabled={!mergeReady}><Download size={16} /> {mergeReady ? "통합본 즉시 내려받기" : "원고 연결 중"}</button><button className="merge-canonical" onClick={exportCanonicalFeatureFilm}><BookDown size={14} /> 최신 정본 직접 받기</button></div>
          </section>

          <section className={`merge-dock ${batchRewriteState.completed.length === 21 ? "is-ready" : ""}`} aria-label="21청크 AI 전면 재작성">
            <div className="merge-seal"><Sparkles size={21} /></div>
            <div className="merge-copy"><span>21청크 AI 전면 재작성</span><b>각 청크를 순서대로 새 문체 후보로 만들고 버전 장부에 보관합니다.</b><small>{batchRewriteState.running ? `청크 ${String(batchRewriteState.currentChunk ?? 1).padStart(2, "0")} 재작성 중 · 중단을 누르면 현재 청크 뒤에 멈춥니다.` : batchRewriteState.error ? `중단 사유 · ${batchRewriteState.error}` : batchRewriteState.completed.length === 21 ? "21청크 후보 생성 완료 · 각 청크의 수정 비교와 복원이 가능합니다." : "원문은 덮어쓰지 않습니다. 생성된 후보는 수정본으로 보관되며, 실행 시 언어 모델 사용량이 발생합니다."}</small></div>
            <div className="merge-progress"><strong>{batchRewriteState.completed.length}</strong><span>/ 21</span><i><em style={{ width: `${(batchRewriteState.completed.length / 21) * 100}%` }} /></i></div>
            {batchRewriteState.running ? <button className="merge-export" onClick={requestBatchStop} disabled={batchRewriteState.stopRequested}><X size={16} /> {batchRewriteState.stopRequested ? "중단 대기" : "현재 청크 뒤 중단"}</button> : <button className="merge-export" onClick={() => void startBatchRewrite()} disabled={!mergeReady || batchRewriteState.completed.length === 21}><Sparkles size={16} /> {batchRewriteState.completed.length ? "다음 청크부터 재개" : "21청크 재작성 시작"}</button>}
          </section>

          <section className={`validation-dock ${validationReport ? (validationPassed ? "is-passed" : "has-issues") : ""}`} aria-label="병합 전 연속성 검수">
            <span className="validation-seal">{validationPassed ? <ShieldCheck size={21} /> : <ScanSearch size={21} />}</span>
            <div className="validation-copy"><span>병합 전 연속성 검수</span><b>{validationReport ? (validationPassed ? "정본 계약과 충돌하는 자동 오류가 없습니다." : "설정 충돌과 형식 오류를 먼저 확인해야 합니다.") : "21개 청크의 설정·구조·대사·능력을 정본과 대조합니다."}</b><small>{validationReport ? `검수 완료 · 오류 ${validationReport.errors.length}개 · 경고 ${validationReport.warnings.length}개` : "청크 순서, 고정 대사, 연령 대가, 능력 창, 태그, 중복 구조, 어휘와 청크 경계를 검사합니다."}</small></div>
            <button className="validation-run" onClick={runContinuityCheck}><ScanSearch size={16} /> 전체 검수 실행</button>
          </section>

          {validationReport && (
            <section className="validation-report" aria-live="polite">
              <div className="validation-report-head"><div><p className="section-eyebrow ink-eyebrow">연속성 컴파일 결과</p><h3>{validationPassed ? "병합 가능" : "수정이 필요한 대목"}</h3></div><span className={validationPassed ? "report-status is-passed" : "report-status has-issues"}>{validationPassed ? <ShieldCheck size={14} /> : <AlertTriangle size={14} />}{validationPassed ? "통과" : "병합 잠김"}</span></div>
              <div className="report-metrics"><div><strong>{validationReport.checkedChunks}</strong><span>대본 청크</span></div><div><strong>{validationReport.stateCheckedChunks}</strong><span>상태 장부</span></div><div className="error-metric"><strong>{validationReport.errors.length}</strong><span>오류</span></div><div className="warning-metric"><strong>{validationReport.warnings.length}</strong><span>경고</span></div><div><strong>{validationReport.characterCount.toLocaleString()}</strong><span>본문 글자</span></div></div>
              {validationReport.missingChunks.length > 0 && <div className="missing-note"><AlertTriangle size={15} /> 청크 {validationReport.missingChunks.map((chunk) => String(chunk).padStart(2, "0")).join(", ")} 원고가 없어 검수가 완료되지 않았습니다.</div>}
              {validationReport.stateMissingChunks.length > 0 && <div className="missing-note"><FileJson size={15} /> 청크 {validationReport.stateMissingChunks.map((chunk) => String(chunk).padStart(2, "0")).join(", ")} 상태 장부 JSON이 없어 연령·관계·소지품 정밀 검수가 잠겨 있습니다.</div>}
              {(validationReport.errors.length > 0 || validationReport.warnings.length > 0) && <div className="issue-list">{[...validationReport.errors, ...validationReport.warnings].slice(0, 8).map((issue, index) => <button className={`issue-row ${issue.level}`} key={`${issue.code}-${issue.chunk ?? "all"}-${index}`} onClick={() => openIssueInEditor(issue)}><span>{issue.level === "error" ? "오류" : "경고"}</span><div><b>{issue.chunk ? `청크 ${String(issue.chunk).padStart(2, "0")} · ` : "전체 원고 · "}{issue.message}</b><small>{issue.level === "error" ? "클릭하면 편집창의 해당 위치로 이동합니다." : "클릭하면 관련 문장을 선택합니다."}</small></div><ArrowUpRight size={15} /></button>)}</div>}
              {(validationReport.errors.length + validationReport.warnings.length) > 8 && <p className="issue-more">처음 8개 항목을 표시합니다. 수정 후 다시 검수하면 최신 결과로 갱신됩니다.</p>}
              {selectedIssue && selectedIssueRange && <div className="issue-context-preview"><div><span>선택한 검수 문맥</span><b>{selectedIssue.chunk ? `청크 ${String(selectedIssue.chunk).padStart(2, "0")}` : "전체 원고"} · {selectedIssue.message}</b></div><button onClick={() => openIssueInEditor(selectedIssue)}><PencilLine size={14} /> 편집창에서 고치기</button><pre>{selectedIssueLines.map((line, index) => <code className={index + Math.max(0, selectedIssueStartLine - 2) === selectedIssueStartLine ? "is-target" : ""} key={`${line}-${index}`}><i>{String(index + Math.max(0, selectedIssueStartLine - 2) + 1).padStart(3, "0")}</i>{line || " "}</code>)}</pre></div>}
            </section>
          )}

          {validationReport && !validationPassed && (
            <section id="validation-recovery" className="validation-recovery" aria-label="통합본 다운로드 복구 안내">
              <div><p>다운로드가 잠긴 이유</p><b>이 브라우저에 남은 이전 원고·수정본 또는 장부가 정본 계약과 충돌했습니다.</b><small>현재 작업을 보존하려면 최신 정본 직접 받기를 누르세요. 이 작업실 자체를 최신 정본으로 되돌릴 때만 초기화를 선택하세요.</small></div>
              <div className="validation-recovery-actions"><button className="merge-canonical" onClick={exportCanonicalFeatureFilm}><BookDown size={14} /> 최신 정본 직접 받기</button><button className="recovery-reset" onClick={restoreCanonicalWorkspace}><RotateCcw size={14} /> 내 수정본·장부 초기화</button></div>
            </section>
          )}

          <section className="studio-grid" id="script">
            <article className="manuscript-panel">
              <div className="panel-heading">
                <div><p className="section-eyebrow ink-eyebrow">대본 롤</p><h2>{displayTitle}</h2></div>
                <div className="view-switcher" aria-label="대본 보기 선택">
                  <button className={activeView === "draft" ? "is-selected" : ""} onClick={() => setActiveView("draft")}><FileText size={15} /> 본문</button>
                  <button className={activeView === "ledger" ? "is-selected" : ""} onClick={() => setActiveView("ledger")}><ShieldCheck size={15} /> 장부</button>
                  <button className={activeView === "river" ? "is-selected" : ""} onClick={() => setActiveView("river")}><Route size={15} /> 물길</button>
                </div>
              </div>

              {activeView === "draft" && isEditing && activeContent && (
                <div className="editor-area">
                  <div className="editor-toolbar">
                    <div><span className="editor-status-dot" /><b>편집 모드</b><small>수정 내용은 저장 버튼을 누르면 이 브라우저에 보관됩니다.</small></div>
                    <div className="editor-toolbar-actions"><button className="editor-cancel" onClick={() => { setDraftText(activeContent); setIssueFocus(null); setEditing(false); }}>취소</button><button className="editor-save" onClick={() => { saveDraft(); setIssueFocus(null); }}><Save size={15} /> 수정본 저장</button></div>
                  </div>
                  {issueFocus && <div className="issue-focus-note"><AlertTriangle size={15} /><span><b>{issueFocus.issue.level === "error" ? "검수 오류 위치" : "검수 경고 위치"}</b><em>{issueFocus.issue.message}</em></span><button onClick={() => setIssueFocus(null)} aria-label="오류 강조 해제"><X size={15} /></button></div>}
                  <textarea ref={editorRef} className={`markdown-editor ${issueFocus ? "is-issue-focused" : ""}`} value={draftText} onChange={(event) => { setDraftText(event.target.value); setIssueFocus(null); }} aria-label="마크다운 대본 편집" spellCheck={false} />
                  <div className="editor-footer"><label className="version-memo-field"><span>이번 보관본 제목</span><input value={versionMemo} onChange={(event) => setVersionMemo(event.target.value)} placeholder="예: 수문 진입 전 리듬 보정" maxLength={48} /></label><div><span>Markdown · {draftText.length.toLocaleString()}자</span><button className="text-action" onClick={resetDraft} disabled={!hasLocalEdit}><RotateCcw size={14} /> 원본 복원</button><button className="text-action" onClick={exportMarkdown}><Download size={14} /> 지금 내려받기</button></div></div>
                </div>
              )}

              {activeView === "draft" && !isEditing && activeChunk === 1 && !activeImported && (
                <div className="script-reading-area">
                  <div className="passage-tabs" role="tablist" aria-label="청크 1 문단 선택">
                    {baseDraftPassages.map((passage, index) => <button key={passage.label} onClick={() => setActivePassage(index)} className={activePassage === index ? "is-active" : ""} role="tab" aria-selected={activePassage === index}><span>0{index + 1}</span>{passage.label}</button>)}
                  </div>
                  <div className="script-copy">{activeMeta.lines.map((line, index) => <p key={`${line}-${index}`} className={line.startsWith("[") ? "dialogue-line" : ""}>{line}</p>)}</div>
                  <div className="script-caption"><span>원문 발췌 · 청크 01 {hasLocalEdit && <em className="saved-copy">수정본 보관됨</em>}</span><div className="script-actions"><button onClick={startEditing}><PencilLine size={14} /> 수정</button><button onClick={createBriefDraft}>기획 초안</button><button onClick={requestFullRewrite} disabled={rewriteMutation.isPending}><Sparkles size={14} /> {rewriteMutation.isPending ? "재작성 중" : "AI 전면 재작성"}</button><button onClick={requestStyleScore} disabled={scoreMutation.isPending}><ScanSearch size={14} /> {scoreMutation.isPending ? "평가 중" : "문체 점수"}</button><button onClick={runRhythmCheck}>리듬 검수</button><button onClick={() => setVersionsOpen((open) => !open)}><ArchiveRestore size={14} /> 버전 {activeVersions.length}</button>{hasLocalEdit && <button onClick={() => setDiffOpen((open) => !open)}>{isDiffOpen ? "비교 닫기" : "수정 비교"}</button>}<button onClick={exportMarkdown}><Download size={14} /> md 내려받기</button></div></div>
                </div>
              )}

              {activeView === "draft" && !isEditing && activeImported && (
                <div className="script-reading-area imported-reading-area">
                  <div className="imported-file-meta"><span><FileText size={14} /> {activeImported.sourceName}</span><small>{hasLocalEdit ? "수정본 보관됨" : `가져온 원고 · ${new Date(activeImported.importedAt).toLocaleDateString("ko-KR")}`}</small></div>
                  <div className="script-copy imported-copy">{importedBlocks.map((block, index) => <p key={`${block.slice(0, 20)}-${index}`} className={block.startsWith("[") ? "dialogue-line" : ""}>{block}</p>)}</div>
                  <div className="script-caption"><span>청크 {String(activeChunk).padStart(2, "0")} · 브라우저 장부에 보관됨</span><div className="script-actions"><button onClick={startEditing}><PencilLine size={14} /> 수정</button><button onClick={createBriefDraft}>기획 초안</button><button onClick={requestFullRewrite} disabled={rewriteMutation.isPending}><Sparkles size={14} /> {rewriteMutation.isPending ? "재작성 중" : "AI 전면 재작성"}</button><button onClick={requestStyleScore} disabled={scoreMutation.isPending}><ScanSearch size={14} /> {scoreMutation.isPending ? "평가 중" : "문체 점수"}</button><button onClick={runRhythmCheck}>리듬 검수</button><button onClick={() => setVersionsOpen((open) => !open)}><ArchiveRestore size={14} /> 버전 {activeVersions.length}</button>{hasLocalEdit && <button onClick={() => setDiffOpen((open) => !open)}>{isDiffOpen ? "비교 닫기" : "수정 비교"}</button>}<button onClick={exportMarkdown}><Download size={14} /> md 내려받기</button></div></div>
                </div>
              )}

              {activeView === "draft" && !isEditing && activeChunk > 1 && !activeImported && (
                <div className="empty-script-state">
                  <span className="empty-script-icon"><FileUp size={24} /></span>
                  <p className="section-eyebrow ink-eyebrow">CHUNK {String(activeChunk).padStart(2, "0")}</p>
                  <h3>아직 이 물길에는 원고가 없습니다.</h3>
                  <p>파일명에 <b>chunk_{String(activeChunk).padStart(2, "0")}.md</b>를 넣거나 첫 줄에 <b>[청크 {String(activeChunk).padStart(2, "0")}/21]</b>을 적은 마크다운을 가져오세요.</p>
                  <button className="vermilion-action" onClick={openFilePicker}><UploadCloud size={16} /> 청크 원고 가져오기</button>
                </div>
              )}

              {activeView === "draft" && !isEditing && isDiffOpen && hasLocalEdit && <div className="diff-panel"><div className="diff-head"><div><p className="ledger-overline">수정 비교</p><h3>원본과 수정본의 바뀐 줄</h3></div><button onClick={() => setDiffOpen(false)}><X size={15} /> 닫기</button></div>{diffRows.length ? <div className="diff-list">{diffRows.map((row) => <div className="diff-row" key={row.line}><i>{row.line}</i><del>{row.before || "삭제된 빈 줄"}</del><ins>{row.after || "삭제됨"}</ins></div>)}</div> : <p className="diff-empty">줄 단위 변경이 없습니다.</p>}</div>}
              {activeView === "draft" && !isEditing && isVersionsOpen && <div className="version-panel"><div className="diff-head"><div><p className="ledger-overline">청크 버전 장부</p><h3>수정 저장 때마다 자동 보관합니다.</h3></div><button onClick={() => setVersionsOpen(false)}><X size={15} /> 닫기</button></div>{activeVersions.length ? <><label className="version-search"><span>메모 검색</span><input value={versionQuery} onChange={(event) => setVersionQuery(event.target.value)} placeholder="예: 수문, 대사, 리듬" maxLength={48} />{versionQuery && <button type="button" onClick={() => setVersionQuery("")}><X size={13} /></button>}</label><div className="version-list">{filteredVersions.map((version) => <article className={`version-row ${selectedVersion?.id === version.id ? "is-selected" : ""}`} key={version.id}><button className="version-select" onClick={() => setSelectedVersionId(version.id)}><span>{new Date(version.savedAt).toLocaleString("ko-KR", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" })}</span><b>{version.note || version.reason}</b><small>{version.note ? `${version.reason} · ${version.characterCount.toLocaleString()}자` : `${version.characterCount.toLocaleString()}자`}</small></button><button className={`version-pin ${version.pinned ? "is-pinned" : ""}`} onClick={() => setDraftVersions((previous) => toggleDraftVersionPin(previous, activeChunk, version.id))} aria-label={version.pinned ? "이 버전 고정 해제" : "이 버전 고정"} title={version.pinned ? "고정 해제" : "핀 고정"}><Flag size={14} fill={version.pinned ? "currentColor" : "none"} /></button></article>)}</div>{!filteredVersions.length && <p className="diff-empty">해당 메모 또는 저장 사유와 일치하는 버전이 없습니다.</p>}{selectedVersion && <div className="version-detail"><div><b>선택 버전과 현재 원고</b><span>바뀐 줄 {selectedVersionDiff.length}개</span></div>{selectedVersion.note && <p className="version-note">{selectedVersion.note}</p>}<small className="version-reason">{selectedVersion.reason} · {selectedVersion.characterCount.toLocaleString()}자</small><div className="version-actions"><button className="text-action" onClick={() => { setDraftText(selectedVersion.content); setVersionMemo(selectedVersion.note ?? ""); setEditing(true); setVersionsOpen(false); }}>편집창에서 열기</button><button className="editor-save" onClick={() => restoreDraftVersion(selectedVersion)}><ArchiveRestore size={14} /> 이 버전 복원</button></div>{selectedVersionDiff.length ? <div className="diff-list">{selectedVersionDiff.slice(0, 16).map((row) => <div className="diff-row" key={row.line}><i>{row.line}</i><del>{row.before || "삭제된 빈 줄"}</del><ins>{row.after || "삭제됨"}</ins></div>)}</div> : <p className="diff-empty">현재 원고와 같은 내용입니다.</p>}</div>}</> : <p className="diff-empty">아직 저장된 버전이 없습니다. 수정본을 저장하면 이곳에 자동 스냅샷이 남습니다.</p>}</div>}
              {activeView === "draft" && !isEditing && rhythmNotices.length > 0 && <div className="rhythm-panel"><div className="rhythm-panel-head"><div><p className="ledger-overline">문장 리듬</p><h3>경고를 누르면 실제 문장을 강조합니다.</h3></div><button className="text-action" onClick={() => setRhythmNotices([])}><X size={14} /> 닫기</button></div><div className="rhythm-list">{rhythmNotices.map((notice) => <button className="rhythm-row" key={notice.id} onClick={() => openRhythmInEditor(notice)}><b>{notice.label}</b><span>{notice.summary}</span><small>문장 열기</small></button>)}</div></div>}
              {activeView === "draft" && !isEditing && publishedStyleScore && <div className="rhythm-panel ai-style-panel"><div className="rhythm-panel-head"><div><p className="ledger-overline">서버 전수 문체 재평가</p><h3>청크 {String(activeChunk).padStart(2, "0")} · 종합 {publishedStyleScore.overall}점</h3></div><span className="verified-mark"><Check size={14} /> 21청크 완료</span></div><p className="ai-style-summary">{publishedStyleScore.summary}</p><div className="ai-score-grid">{[["진입 긴장", publishedStyleScore.hook], ["동행자", publishedStyleScore.companionVoice], ["대사", publishedStyleScore.dialogue], ["리듬", publishedStyleScore.rhythm], ["무협 쾌감", publishedStyleScore.martialAppeal], ["TTS", publishedStyleScore.tts]].map(([label, score]) => <div key={String(label)}><b>{score}</b><span>{label}</span></div>)}</div><div className="ai-style-notes"><p><strong>강점</strong>{publishedStyleScore.strengths.join(" · ")}</p><p><strong>보강</strong>{publishedStyleScore.issues.join(" · ")}</p></div><small>모델 {defaultStyleScoreReport.model} · 21청크 종합 평균 {publishedOverallAverage}점 · 브라우저 로그인 없이 확인 가능한 읽기 전용 결과입니다.</small></div>}
              {activeView === "draft" && !isEditing && aiStyleScore?.chunk === activeChunk && <div className="rhythm-panel ai-style-panel"><div className="rhythm-panel-head"><div><p className="ledger-overline">AI 문체 재평가</p><h3>종합 {aiStyleScore.overall}점 · {aiStyleScore.model}</h3></div><button className="text-action" onClick={() => setAiStyleScore(null)}><X size={14} /> 닫기</button></div><p className="ai-style-summary">{aiStyleScore.summary}</p><div className="ai-score-grid">{[["Hook", aiStyleScore.hook], ["동행자", aiStyleScore.companionVoice], ["대사", aiStyleScore.dialogue], ["리듬", aiStyleScore.rhythm], ["무협 쾌감", aiStyleScore.martialAppeal], ["TTS", aiStyleScore.tts]].map(([label, score]) => <div key={String(label)}><b>{score}</b><span>{label}</span></div>)}</div><div className="ai-style-notes"><p><strong>강점</strong>{aiStyleScore.strengths.join(" · ")}</p><p><strong>보강</strong>{aiStyleScore.issues.join(" · ")}</p></div></div>}
              {activeView === "ledger" && !isLedgerEditing && !isLedgerFormOpen && <div className="inline-ledger"><div className="ledger-image-wrap"><img src={assets.ledger} alt="한지 장부와 인주를 담은 정물" /></div><div><p className="ledger-overline">CHUNK {String(activeChunk).padStart(2, "0")} 종료 상태</p><h3>{activeLedger ? `${activeLedger.location ?? "위치 미기록"} · 상태 장부 연결됨` : activeChunk === 1 ? "아직은 배 위의 약속뿐이다." : "대본이 들어오면, 장부도 이어집니다."}</h3><p>{activeLedger ? `마지막 위치는 ${activeLedger.chunk_boundary?.last_location ?? activeLedger.location ?? "미기록"}입니다. ${activeLedger.chunk_boundary?.next_required_end_state ?? "다음 도달 상태를 장부에 기록하세요."}` : "상태 장부 JSON을 함께 가져오면 인물·관계·대가 검수까지 표시합니다."}</p><div className="ledger-actions"><button className="text-action" onClick={activeLedger ? openLedgerForm : openStateFilePicker}>{activeLedger ? "핵심 항목 폼 수정" : "장부 가져오기"} <PencilLine size={15} /></button>{activeLedger && <button className="text-action" onClick={startLedgerEditing}>JSON 직접 수정</button>}{activeLedger && <button className="text-action" onClick={exportLedger}>JSON 내려받기 <Download size={15} /></button>}</div></div></div>}
              {activeView === "ledger" && isLedgerFormOpen && <div className="ledger-form"><div className="editor-toolbar"><div><span className="editor-status-dot" /><b>핵심 상태 장부 폼</b><small>복아는 실제·정신·목소리 스무 살이며, 청크 1부터 20까지 육체 일흔 살을 유지합니다.</small></div><div className="editor-toolbar-actions"><button className="editor-cancel" onClick={() => setLedgerFormOpen(false)}>취소</button><button className="editor-save" onClick={saveLedgerForm}><Save size={15} /> 저장</button></div></div><label>위치<input value={ledgerForm.location} onChange={(event) => setLedgerForm({ ...ledgerForm, location: event.target.value })} /></label><label>강무진 육체 나이<input type="number" value={ledgerForm.heroAge} onChange={(event) => setLedgerForm({ ...ledgerForm, heroAge: event.target.value })} /></label><label>복아 정신 나이<input type="number" value={ledgerForm.bokAhMind} onChange={(event) => setLedgerForm({ ...ledgerForm, bokAhMind: event.target.value })} /></label><label>복아 육체 나이<input type="number" value={ledgerForm.bokAhBody} onChange={(event) => setLedgerForm({ ...ledgerForm, bokAhBody: event.target.value })} /></label><label>강무진 소지품<input value={ledgerForm.possessions} onChange={(event) => setLedgerForm({ ...ledgerForm, possessions: event.target.value })} /></label><label>강무진 복아 관계 단계<input type="number" value={ledgerForm.relationshipStage} onChange={(event) => setLedgerForm({ ...ledgerForm, relationshipStage: event.target.value })} /></label></div>}
              {activeView === "ledger" && isLedgerEditing && <div className="ledger-editor"><div className="editor-toolbar"><div><span className="editor-status-dot" /><b>상태 장부 편집</b><small>characters, relationships 구조와 복아의 실제·정신 스무 살, 청크 1부터 20 육체 일흔 살, 청크 21 육체 스무 살 복귀 잠금을 유지하세요.</small></div><div className="editor-toolbar-actions"><button className="editor-cancel" onClick={() => setLedgerEditing(false)}>취소</button><button className="editor-save" onClick={saveLedger}><Save size={15} /> 장부 저장</button></div></div><textarea className="ledger-json-editor" value={ledgerText} onChange={(event) => setLedgerText(event.target.value)} aria-label="상태 장부 JSON 편집" spellCheck={false} /><div className="editor-footer"><span>JSON · {ledgerText.length.toLocaleString()}자</span><button className="text-action" onClick={exportLedger}><Download size={14} /> 현재 장부 내보내기</button></div></div>}
              {activeView === "river" && <div className="river-map-card"><img src={assets.river} alt="별빛이 닿은 밤 강물과 배의 밧줄" /><div><p className="ledger-overline">SCENE FLOW</p><h3>{activeChunk === 1 ? "별 추락 → 구조 → 징수 명령 → 배의 원칙" : `청크 ${String(activeChunk).padStart(2, "0")}의 물길이 연결되었습니다.`}</h3><p>매 청크는 독립된 회차가 아니라, 한 편의 영화 안에서 인과로 이어지는 강의 굽이다.</p></div></div>}
            </article>

            <aside className="continuity-panel" aria-label="연속성 장부">
              <div className="panel-heading compact"><div><p className="section-eyebrow ink-eyebrow">연속성 장부</p><h2>현재 상태</h2></div><span className="verified-mark"><Check size={14} /> 통과</span></div>
              <div className="check-banner"><span className="check-icon">{validationReport?.errors.length ? <AlertTriangle size={18} /> : <ShieldCheck size={18} />}</span><div><b>{validationReport ? `오류 ${validationReport.errors.length}개 · 경고 ${validationReport.warnings.length}개` : "대본별 장부 대기"}</b><small>{validationReport ? (validationPassed ? "21청크 병합 전 자동 검수 통과" : "통합본 다운로드 전 오류를 수정해야 합니다.") : activeChunk === 1 ? "청크 1 종료 상태 검수 완료" : "가져온 원고 연결 완료"}</small></div></div>
              <div className="ledger-list">{activeLedgerRows.map((row) => <div className="ledger-row" key={row.name}><span className={`ledger-dot ${row.tone}`} /><div><b>{row.name}</b><small>{row.detail}</small></div></div>)}</div>
              <div className="open-thread"><div className="thread-heading"><Flag size={16} /> 열려 있는 실</div><p>복아가 빼앗긴 쉰 해 · 허담의 수명세 · 강무진 몸속 요광</p></div>
              <div className="next-state"><span>다음 도달 상태</span><p>{activeLedger?.chunk_boundary?.next_required_end_state ?? (activeChunk === 1 ? "집행대와 첫 충돌. 단여령이 요광을 확인한다." : "청크 상태 장부를 가져오면 이 칸에 다음 종료 조건을 연결합니다.")}</p></div>
            </aside>
          </section>

          <section className="below-grid">
            <article className="principle-card"><div className="principle-icon"><Waves size={23} /></div><div><p className="section-eyebrow ink-eyebrow">사공의 약속</p><blockquote>“내 배에 오른 사람은, 무슨 일이 있어도 건너편에 내려준다.”</blockquote></div></article>
            <article className="rule-card"><CircleDotDashed size={21} /><div><b>한 편의 영화</b><span>21개 청크는 출력 경계일 뿐, 새로운 시작이 아닙니다.</span></div></article>
            <article className="rule-card"><HeartPulse size={21} /><div><b>대가는 남는다</b><span>나이, 부상, 관계, 소지품은 다음 장면까지 기록됩니다.</span></div></article>
            <article className="rule-card accent-rule"><Sparkles size={21} /><div><b>요광은 아직 잠들어 있다</b><span>개로 사용 0회 · 별길은 강무진의 몸에만 남았습니다.</span></div></article>
          </section>
        </main>
      </div>
    </div>
  );
}
