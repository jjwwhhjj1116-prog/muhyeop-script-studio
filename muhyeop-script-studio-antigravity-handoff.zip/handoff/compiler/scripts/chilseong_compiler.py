#!/usr/bin/env python3
"""칠성탈명록 전용 연속성 컴파일러.

창작을 생성하지 않는다. 정본 계약, 청크 상태 장부, 대본 파일을 대조하여
재현 가능한 오류·경고 보고서를 만든다.
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CANON = ROOT / "references" / "chilseong_canon.json"
DEFAULT_TEMPLATE = ROOT / "templates" / "chunk_state_template.json"


@dataclass(frozen=True)
class Issue:
    level: str
    code: str
    message: str
    path: str = ""

    def render(self) -> str:
        prefix = f"[{self.level}] {self.code}: {self.message}"
        return f"{prefix} ({self.path})" if self.path else prefix


def load_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ValueError(f"필수 파일이 없습니다: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"JSON 문법 오류: {path} {exc}") from exc


def write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8").replace("\r\n", "\n").lstrip("\ufeff")
    except FileNotFoundError as exc:
        raise ValueError(f"대본 파일이 없습니다: {path}") from exc


def nonempty_lines(text: str) -> list[str]:
    return [line.strip() for line in text.splitlines() if line.strip()]


def prose_text(text: str) -> str:
    return "\n".join(line for line in text.splitlines() if not re.fullmatch(r"\[청크\s*\d{1,2}/21\]", line.strip()))


def count_chars(text: str) -> int:
    return len(re.sub(r"\s+", "", prose_text(text)))


def checkpoint_for(mapping: dict[str, Any], chunk: int) -> Any:
    eligible = [int(key) for key in mapping if int(key) <= chunk]
    if not eligible:
        return None
    return mapping[str(max(eligible))]


def find_state(state_dir: Path, chunk: int) -> Path:
    return state_dir / f"chunk_{chunk:02d}.json"


def state_character(state: dict[str, Any], name: str) -> dict[str, Any] | None:
    value = state.get("characters", {}).get(name)
    return value if isinstance(value, dict) else None


def check_chunk_header(text: str, chunk: int, path: Path) -> list[Issue]:
    issues: list[Issue] = []
    expected = f"[청크 {chunk:02d}/21]"
    lines = nonempty_lines(text)
    if not lines or lines[0] != expected:
        issues.append(Issue("ERROR", "header", f"첫 내용 줄은 정확히 {expected}여야 합니다.", str(path)))
    return issues


def check_structure(text: str, chunk: int, canon: dict[str, Any], path: Path) -> list[Issue]:
    issues: list[Issue] = []
    structure = canon["structure"]
    expected_headings = structure["heading_by_chunk"].get(str(chunk), [])
    expected_markers = structure["marker_by_chunk"].get(str(chunk), [])
    all_headings = ["## Hook", "## Intro", "## Body", "## Climax", "## End"]
    all_markers = ["[CTA]", "[END]"]

    for token in all_headings:
        actual = text.count(token)
        expected = 1 if token in expected_headings else 0
        if actual != expected:
            issues.append(Issue("ERROR", "structure_heading", f"{token} 개수 {actual}개. 이 청크의 허용 개수는 {expected}개입니다.", str(path)))
    for token in all_markers:
        actual = text.count(token)
        expected = 1 if token in expected_markers else 0
        if actual != expected:
            issues.append(Issue("ERROR", "structure_marker", f"{token} 개수 {actual}개. 이 청크의 허용 개수는 {expected}개입니다.", str(path)))

    lines = nonempty_lines(text)
    if "[CTA]" in expected_markers:
        cta_index = lines.index("[CTA]") if "[CTA]" in lines else -1
        hook_last = next(item["text"] for item in canon["fixed_dialogues"] if item["id"] == "hook_last")
        if cta_index <= 0 or lines[cta_index - 1] != hook_last:
            issues.append(Issue("ERROR", "cta_position", "[CTA] 바로 앞줄은 Hook 마지막 고정 대사여야 합니다.", str(path)))
    if "[END]" in expected_markers:
        end_index = lines.index("[END]") if "[END]" in lines else -1
        if end_index < 0 or end_index + 1 >= len(lines) or lines[end_index + 1] != "## End":
            issues.append(Issue("ERROR", "end_position", "[END] 다음 줄은 정확히 ## End여야 합니다.", str(path)))
    return issues


def check_fixed_dialogues(text: str, chunk: int, canon: dict[str, Any], path: Path) -> list[Issue]:
    issues: list[Issue] = []
    for item in canon["fixed_dialogues"]:
        if item["chunk"] != chunk:
            continue
        if item["text"] not in text:
            issues.append(Issue("ERROR", "fixed_dialogue", f"고정 대사가 없거나 원문과 다릅니다: {item['id']}", str(path)))
    if chunk == 21:
        end_last = next(item["text"] for item in canon["fixed_dialogues"] if item["id"] == "end_last")
        lines = nonempty_lines(text)
        if not lines or lines[-1] != end_last:
            issues.append(Issue("ERROR", "end_last_line", "청크 21의 마지막 내용 줄은 강무진의 최종 고정 대사여야 합니다.", str(path)))
    return issues


def check_dialogue_tags(text: str, canon: dict[str, Any], path: Path) -> list[Issue]:
    issues: list[Issue] = []
    allowed_speakers = set(canon["allowed_speakers"])
    allowed_emotions = set(canon["allowed_emotions"])
    full_tag = re.compile(r'^\s*\[([^|\]\n]+)\|([^\]\n]+)\]"([^"\n]*)"\s*$')
    candidate = re.compile(r"^\s*\[[^\]\n]*\|[^\]\n]*\].*$")
    for line_number, line in enumerate(text.splitlines(), 1):
        if not candidate.match(line):
            continue
        match = full_tag.match(line)
        if not match:
            issues.append(Issue("ERROR", "dialogue_format", f"{line_number}행의 대사 태그 형식이 틀렸습니다.", str(path)))
            continue
        speaker, emotion, spoken = match.groups()
        if speaker not in allowed_speakers:
            issues.append(Issue("ERROR", "unknown_speaker", f"{line_number}행의 화자 {speaker}은 정본 고정명이 아닙니다.", str(path)))
        if emotion not in allowed_emotions:
            issues.append(Issue("ERROR", "unknown_emotion", f"{line_number}행의 감정 {emotion}은 허용값이 아닙니다.", str(path)))
        if emotion == "FIRM" and speaker != canon["firm_only_speaker"]:
            issues.append(Issue("ERROR", "firm_misuse", f"{line_number}행의 FIRM은 강무진만 사용할 수 있습니다.", str(path)))
        if not spoken.strip():
            issues.append(Issue("ERROR", "empty_dialogue", f"{line_number}행의 직접 대사가 비어 있습니다.", str(path)))
    return issues


def check_chunk_targets(text: str, chunk: int, canon: dict[str, Any], path: Path, no_length: bool) -> list[Issue]:
    issues: list[Issue] = []
    config = canon["chunks"][str(chunk)]
    if not no_length:
        actual = count_chars(text)
        target = config["target_chars"]
        if not target - 200 <= actual <= target + 200:
            issues.append(Issue("WARNING", "chunk_length", f"공백 제외 {actual}자. 목표 {target}자 대비 허용 범위는 {target - 200}~{target + 200}자입니다.", str(path)))
    for term in config.get("required_terms", []):
        if term not in text:
            issues.append(Issue("WARNING", "target_state_evidence", f"청크 종료 상태 증거어가 없습니다: {term}", str(path)))
    return issues


def check_ability_mentions(text: str, chunk: int, canon: dict[str, Any], path: Path) -> list[Issue]:
    issues: list[Issue] = []
    for ability, rule in canon["ability_rules"].items():
        occurrences = text.count(ability)
        if occurrences and chunk not in rule["allowed_chunks"]:
            issues.append(Issue("ERROR", "ability_out_of_window", f"{ability}은 청크 {rule['allowed_chunks']}에서만 쓸 수 있습니다.", str(path)))
        if occurrences > 2:
            issues.append(Issue("WARNING", "ability_repeat", f"{ability}이 {occurrences}회 언급되었습니다. 결정적 사용 여부를 수동 확인하세요.", str(path)))
    return issues


def check_state(state: dict[str, Any], previous: dict[str, Any] | None, chunk: int, canon: dict[str, Any], path: Path) -> list[Issue]:
    issues: list[Issue] = []
    if state.get("chunk") != chunk:
        issues.append(Issue("ERROR", "state_chunk", f"상태 장부의 chunk 값은 {chunk}이어야 합니다.", str(path)))
    if not isinstance(state.get("characters"), dict):
        return issues + [Issue("ERROR", "state_schema", "characters 객체가 필요합니다.", str(path))]

    age_checkpoint = canon["age_checkpoints"].get(str(chunk), {})
    for name, expected in age_checkpoint.items():
        character = state_character(state, name)
        if character is None:
            issues.append(Issue("ERROR", "state_character_missing", f"검수 대상 인물 {name}이 상태 장부에 없습니다.", str(path)))
            continue
        for field, expected_value in expected.items():
            if character.get(field) != expected_value:
                issues.append(Issue("ERROR", "age_checkpoint", f"{name}.{field}={character.get(field)!r}. 청크 {chunk} 정본값은 {expected_value!r}입니다.", str(path)))

    if previous:
        for name, now in state.get("characters", {}).items():
            before = state_character(previous, name)
            if not isinstance(before, dict) or not isinstance(now, dict):
                continue
            for field in ("body_age", "actual_age", "mind_age"):
                old_value, new_value = before.get(field), now.get(field)
                if not isinstance(old_value, int) or not isinstance(new_value, int):
                    continue
                exception = name == "복아" and field == "body_age" and chunk == 21 and old_value == 58 and new_value == 8
                if new_value < old_value and not exception:
                    issues.append(Issue("ERROR", "age_reversal", f"{name}.{field}가 {old_value}에서 {new_value}로 감소했습니다.", str(path)))
            if before.get("alive") is False and now.get("alive") is not False:
                issues.append(Issue("ERROR", "resurrection", f"{name}은 이전 청크에서 사망했는데 다시 생존 상태입니다.", str(path)))

    hero = state_character(state, "강무진")
    if hero:
        used = hero.get("abilities_used", {})
        if not isinstance(used, dict):
            issues.append(Issue("ERROR", "ability_ledger", "강무진.abilities_used 객체가 필요합니다.", str(path)))
        else:
            for ability, rule in canon["ability_rules"].items():
                expected_total = rule.get("expected_total_after", {}).get(str(chunk))
                if expected_total is not None and used.get(ability) != expected_total:
                    issues.append(Issue("ERROR", "ability_count", f"{ability} 누적 사용 횟수는 {expected_total}회여야 하나 {used.get(ability)!r}회입니다.", str(path)))
            if previous:
                old_used = state_character(previous, "강무진").get("abilities_used", {}) if state_character(previous, "강무진") else {}
                for ability, number in used.items():
                    if isinstance(number, int) and isinstance(old_used.get(ability), int) and number < old_used[ability]:
                        issues.append(Issue("ERROR", "ability_count_reversal", f"{ability} 누적 횟수가 감소했습니다.", str(path)))

    for name, death_chunk in canon["death_rules"].items():
        character = state_character(state, name)
        if character is None:
            continue
        if chunk >= death_chunk and character.get("alive") is not False:
            issues.append(Issue("ERROR", "death_lock", f"{name}은 청크 {death_chunk} 이후 사망 상태여야 합니다.", str(path)))
        if chunk < death_chunk and character.get("alive") is False:
            issues.append(Issue("WARNING", "early_death", f"{name}의 사망 시점이 정본 청크 {death_chunk}보다 빠릅니다.", str(path)))

    relationships = state.get("relationships", {})
    if isinstance(relationships, dict):
        for pair, limits in canon["relationship_max_stage"].items():
            relation = relationships.get(pair)
            if not isinstance(relation, dict):
                continue
            allowed = checkpoint_for(limits, chunk)
            stage = relation.get("stage")
            if isinstance(allowed, int) and isinstance(stage, int) and stage > allowed:
                issues.append(Issue("ERROR", "relationship_jump", f"{pair} 관계 단계 {stage}는 청크 {chunk}의 최대 허용 단계 {allowed}를 넘습니다.", str(path)))
            if previous and isinstance(stage, int):
                prior_relation = previous.get("relationships", {}).get(pair, {})
                prior_stage = prior_relation.get("stage") if isinstance(prior_relation, dict) else None
                if isinstance(prior_stage, int) and stage > prior_stage and not relation.get("evidence"):
                    issues.append(Issue("WARNING", "relationship_evidence", f"{pair} 관계 단계가 {prior_stage}에서 {stage}로 변했으나 evidence가 비어 있습니다.", str(path)))
    return issues


def check_lexical(text: str, canon: dict[str, Any], path: Path) -> list[Issue]:
    issues: list[Issue] = []
    rules = canon["lexical_rules"]
    for phrase in rules["banned"]:
        hits = text.count(phrase)
        if hits:
            issues.append(Issue("WARNING", "banned_lexicon", f"금지 후보 {phrase!r}이 {hits}회 발견되었습니다. 물리적 의미·대사 예외인지 수동 확인하세요.", str(path)))
    for phrase, limit in rules["limited"].items():
        hits = text.count(phrase)
        if hits > limit:
            issues.append(Issue("WARNING", "lexical_limit", f"{phrase!r}이 {hits}회입니다. 구간 상한 {limit}회를 넘었습니다.", str(path)))
    for phrase in rules["no_recap_phrases"]:
        if phrase in text:
            issues.append(Issue("WARNING", "recap_phrase", f"재요약 후보 표현 {phrase!r}이 발견되었습니다.", str(path)))
    return issues


def check_boundary(text: str, chunk: int, canon: dict[str, Any], path: Path) -> list[Issue]:
    if chunk == 21:
        return []
    issues: list[Issue] = []
    tail = "\n".join(nonempty_lines(text)[-5:])
    for phrase in canon["lexical_rules"]["false_cliff_phrases"]:
        if phrase in tail:
            issues.append(Issue("WARNING", "false_cliff", f"청크 말미에 가짜 클리프행어 후보 {phrase!r}이 있습니다.", str(path)))
    return issues


def check_one(canon: dict[str, Any], draft_path: Path, state_path: Path, previous_state_path: Path | None, no_length: bool) -> list[Issue]:
    state = load_json(state_path)
    chunk = state.get("chunk")
    if not isinstance(chunk, int) or not 1 <= chunk <= 21:
        return [Issue("ERROR", "state_chunk", "상태 장부의 chunk는 1~21 정수여야 합니다.", str(state_path))]
    text = read_text(draft_path)
    previous = load_json(previous_state_path) if previous_state_path and previous_state_path.exists() else None
    issues: list[Issue] = []
    issues += check_chunk_header(text, chunk, draft_path)
    issues += check_structure(text, chunk, canon, draft_path)
    issues += check_fixed_dialogues(text, chunk, canon, draft_path)
    issues += check_dialogue_tags(text, canon, draft_path)
    issues += check_chunk_targets(text, chunk, canon, draft_path, no_length)
    issues += check_ability_mentions(text, chunk, canon, draft_path)
    issues += check_state(state, previous, chunk, canon, state_path)
    issues += check_lexical(text, canon, draft_path)
    issues += check_boundary(text, chunk, canon, draft_path)
    return issues


def all_draft_paths(drafts_dir: Path) -> list[Path]:
    return [drafts_dir / f"chunk_{number:02d}.md" for number in range(1, 22)]


def check_project(canon: dict[str, Any], drafts_dir: Path, state_dir: Path, no_length: bool) -> list[Issue]:
    issues: list[Issue] = []
    combined: list[str] = []
    for chunk, draft_path in enumerate(all_draft_paths(drafts_dir), 1):
        state_path = find_state(state_dir, chunk)
        if not draft_path.exists():
            issues.append(Issue("ERROR", "draft_missing", f"청크 {chunk} 대본이 없습니다.", str(draft_path)))
            continue
        if not state_path.exists():
            issues.append(Issue("ERROR", "state_missing", f"청크 {chunk} 상태 장부가 없습니다.", str(state_path)))
            continue
        previous = find_state(state_dir, chunk - 1) if chunk > 1 else None
        issues += check_one(canon, draft_path, state_path, previous, no_length)
        combined.append(read_text(draft_path))
    manuscript = "\n".join(combined)
    if combined:
        for marker in ("[CTA]", "[END]"):
            actual = manuscript.count(marker)
            if actual != 1:
                issues.append(Issue("ERROR", "global_marker", f"전체 원고의 {marker} 개수는 1개여야 하나 {actual}개입니다.", str(drafts_dir)))
        for heading in ("## Hook", "## Intro", "## Body", "## Climax", "## End"):
            actual = manuscript.count(heading)
            if actual != 1:
                issues.append(Issue("ERROR", "global_heading", f"전체 원고의 {heading} 개수는 1개여야 하나 {actual}개입니다.", str(drafts_dir)))
        actual_total = count_chars(manuscript)
        target = canon["total_character_target"]
        if not target["min"] <= actual_total <= target["max"]:
            issues.append(Issue("WARNING", "total_length", f"전체 공백 제외 {actual_total}자. 목표 범위는 {target['min']}~{target['max']}자입니다.", str(drafts_dir)))
        for start in range(1, 22, 3):
            group = "\n".join(read_text(path) for path in all_draft_paths(drafts_dir)[start - 1:start + 2] if path.exists())
            if group:
                issues += [Issue(issue.level, issue.code, f"청크 {start}~{min(start + 2, 21)}: {issue.message}", issue.path) for issue in check_lexical(group, canon, drafts_dir)]
    return issues


def print_report(issues: Iterable[Issue], json_output: bool) -> int:
    result = list(issues)
    errors = [item for item in result if item.level == "ERROR"]
    warnings = [item for item in result if item.level == "WARNING"]
    if json_output:
        payload = {"errors": [item.__dict__ for item in errors], "warnings": [item.__dict__ for item in warnings], "ok": not errors}
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        if not result:
            print("[PASS] 오류와 경고가 없습니다.")
        else:
            for item in result:
                print(item.render())
            print(f"\n요약: 오류 {len(errors)}개, 경고 {len(warnings)}개")
    return 2 if errors else 0


def command_init(args: argparse.Namespace) -> int:
    root = Path(args.project).resolve()
    if root.exists() and any(root.iterdir()) and not args.force:
        print(f"오류: 비어 있지 않은 경로입니다. 덮어쓰려면 --force를 사용하세요: {root}", file=sys.stderr)
        return 2
    root.mkdir(parents=True, exist_ok=True)
    for dirname in ("drafts", "state", "reports"):
        (root / dirname).mkdir(exist_ok=True)
    shutil.copy2(DEFAULT_CANON, root / "canon.json")
    shutil.copy2(DEFAULT_TEMPLATE, root / "state" / "chunk_01.json")
    readme = """# 칠성탈명록 연속성 컴파일러 프로젝트\n\n- `canon.json`은 읽기 전용 정본 계약이다. 정본 변경이 확정되기 전에는 수정하지 않는다.\n- `drafts/chunk_NN.md`에는 관리 표식과 대본만 둔다.\n- `state/chunk_NN.json`은 청크 종료 직후의 사실 상태다. 다음 청크를 쓰기 전 갱신한다.\n- 검수: `python chilseong_compiler.py check --draft drafts/chunk_05.md --state state/chunk_05.json`\n- 전체 검수: `python chilseong_compiler.py check-all --drafts-dir drafts --state-dir state`\n"""
    (root / "README.md").write_text(readme, encoding="utf-8")
    print(f"초기화 완료: {root}")
    return 0


def command_context(args: argparse.Namespace) -> int:
    canon = load_json(Path(args.canon))
    chunk = args.chunk
    state_dir = Path(args.state_dir)
    previous_path = find_state(state_dir, chunk - 1) if chunk > 1 else None
    print(f"# 청크 {chunk:02d} 집필 전 내부 장부. 출력 금지")
    print(f"목표 분량: {canon['chunks'][str(chunk)]['target_chars']}자")
    print("종료 상태 증거어: " + ", ".join(canon['chunks'][str(chunk)].get('required_terms', [])))
    locked = [item['text'] for item in canon['fixed_dialogues'] if item['chunk'] == chunk]
    if locked:
        print("고정 대사:")
        for line in locked:
            print(f"- {line}")
    if previous_path and previous_path.exists():
        previous = load_json(previous_path)
        boundary = previous.get("chunk_boundary", {})
        print("직전 종료 상태:")
        print(f"- 위치: {boundary.get('last_location', previous.get('location', '미기록'))}")
        print(f"- 마지막 행동: {' / '.join(boundary.get('last_actions', [])) or '미기록'}")
        print(f"- 다음 종료 요구: {boundary.get('next_required_end_state', '정본 지도 확인')}")
    else:
        print("직전 상태: 청크 1 시작 정본을 사용합니다.")
    return 0


def add_common_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--canon", default=str(DEFAULT_CANON), help="정본 계약 JSON 경로")
    parser.add_argument("--no-length", action="store_true", help="분량 경고를 생략")
    parser.add_argument("--json", action="store_true", help="보고서를 JSON으로 출력")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="칠성탈명록 전용 연속성 컴파일러")
    sub = parser.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init", help="대본 프로젝트의 장부 구조를 초기화")
    init.add_argument("project", help="새 프로젝트 루트 경로")
    init.add_argument("--force", action="store_true", help="비어 있지 않은 경로도 허용")
    init.set_defaults(func=command_init)

    context = sub.add_parser("context", help="청크 작성 전에 필요한 상태만 출력")
    context.add_argument("--chunk", type=int, required=True, choices=range(1, 22))
    context.add_argument("--state-dir", required=True)
    context.add_argument("--canon", default=str(DEFAULT_CANON))
    context.set_defaults(func=command_context)

    check = sub.add_parser("check", help="한 청크 대본과 상태 장부를 검수")
    check.add_argument("--draft", required=True)
    check.add_argument("--state", required=True)
    check.add_argument("--previous-state")
    add_common_arguments(check)
    check.set_defaults(func="check")

    check_all = sub.add_parser("check-all", help="21청크 전체를 연결하여 검수")
    check_all.add_argument("--drafts-dir", required=True)
    check_all.add_argument("--state-dir", required=True)
    add_common_arguments(check_all)
    check_all.set_defaults(func="check-all")
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    try:
        if callable(args.func):
            return args.func(args)
        canon = load_json(Path(args.canon))
        if args.func == "check":
            previous = Path(args.previous_state) if args.previous_state else None
            issues = check_one(canon, Path(args.draft), Path(args.state), previous, args.no_length)
        else:
            issues = check_project(canon, Path(args.drafts_dir), Path(args.state_dir), args.no_length)
        return print_report(issues, args.json)
    except ValueError as exc:
        print(f"오류: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
