---
name: chilseong-continuity-compiler
description: "《칠성탈명록》의 21개 출력 청크 대본을 작성·수정·인수·검수할 때 정본, 청크 상태 장부, Python 연속성 컴파일러를 사용해 연령·대가·능력·인지·관계·구조·고정 대사·TTS·어휘 오류를 차단한다. Use for: 칠성탈명록 청크 작성, 다음 청크 이어쓰기, 대본 수정, 21청크 전체 검수, 연속성 오류 점검, 상태 장부 갱신."
---

# 칠성탈명록 연속성 컴파일러

## 목적

정본은 읽기 전용 계약이다. 대본은 창작물이고 상태 장부는 현재 사실이다. 이 스킬은 모델의 대화 기억이 아니라 **정본 + 청크 종료 상태 + 결정적 검사**로 연속성 오류를 차단한다.

`references/chilseong_canon.json`은 V12 FULL과 작품 컨텍스트에서 기계적으로 확인할 수 있는 잠금만 옮긴 파일이다. 이 파일은 정본을 대체하지 않는다.

## 반드시 읽을 정본

청크 작성, 수정, 검수 작업을 시작할 때마다 다음 두 파일을 전부 다시 읽는다.

1. 프로젝트 공유 파일의 `01_Claude_프로젝트_지침_장편무협영화_V12_FULL.md`
2. 프로젝트 공유 파일의 `02_칠성탈명록_프로젝트_컨텍스트_V2.md`

현재 사용자의 지시가 두 정본과 충돌하면 추측하지 말고 충돌 항목을 먼저 보고한다. 정본과 `canon.json`이 다르면 정본을 우선하고, `canon.json`은 사용자의 명시적 승인 뒤에만 갱신한다.

## 파일 역할

| 파일 또는 폴더 | 역할 | 편집 원칙 |
|---|---|---|
| `canon.json` | 기계 검수용 잠금 계약 | 정본이 확정 변경될 때만 수정한다. |
| `drafts/chunk_NN.md` | 청크 대본 | 관리 표식과 대본만 둔다. |
| `state/chunk_NN.json` | 청크 종료 직후 사실 상태 | 청크를 확정한 뒤 생성·갱신한다. |
| `reports/` | 검수 보고서 | TTS 입력에서 제외한다. |
| `scripts/chilseong_compiler.py` | 결정적 검사 도구 | 창작하지 않고 오류 위치만 보고한다. |

## 새 프로젝트 초기화

다음 명령으로 정본 계약과 상태 장부 구조를 만든다.

```bash
python /home/ubuntu/skills/chilseong-continuity-compiler/scripts/chilseong_compiler.py init /경로/칠성탈명록-대본
```

초기화 뒤 `canon.json`을 해당 프로젝트의 읽기 전용 정본 계약으로 사용한다. `state/chunk_01.json`에는 청크 1 종료 상태를 기록한다. 후속 청크 상태 파일은 `templates/chunk_state_template.json`을 복사해 만든다.

## 청크 작성 절차

다음 순서를 생략하지 않는다.

1. 두 정본을 전부 읽는다.
2. `context` 명령으로 이번 청크의 목표 분량, 고정 대사, 직전 행동, 목표 종료 상태를 확인한다.
3. 직전 상태 장부의 위치, 등장인물, 연령, 외형, 부상, 소지품, 인지 범위, 관계 단계, 열린 복선을 내부 장부로 사용한다.
4. 이번 청크를 작성한다. 청크는 독립 회차가 아니다. 재요약, 재소개, 새 Hook, 새 Intro, CTA, 중간 End, 가짜 클리프행어를 만들지 않는다.
5. 종료 상태를 `state/chunk_NN.json`에 기록한다. 새로 생긴 사실은 `last_actions`, `knowledge`, `injuries`, `possessions`, `abilities_used`, `relationships`, `world`, `open_threads`에 남긴다.
6. `check` 명령을 실행한다. 오류는 먼저 고친다. 경고는 문맥 예외인지 수동 판단한다.
7. 사용자 요청이 `청크 N 작성`이면 **관리용 청크 표식과 대본만 출력**한다. 상태 장부와 검수 보고서는 출력하지 않는다.

```bash
python /home/ubuntu/skills/chilseong-continuity-compiler/scripts/chilseong_compiler.py context \
  --chunk 6 \
  --state-dir /경로/칠성탈명록-대본/state \
  --canon /경로/칠성탈명록-대본/canon.json

python /home/ubuntu/skills/chilseong-continuity-compiler/scripts/chilseong_compiler.py check \
  --draft /경로/칠성탈명록-대본/drafts/chunk_06.md \
  --state /경로/칠성탈명록-대본/state/chunk_06.json \
  --previous-state /경로/칠성탈명록-대본/state/chunk_05.json \
  --canon /경로/칠성탈명록-대본/canon.json
```

## 상태 장부 규칙

`state/chunk_NN.json`은 **청크 종료 직후의 사실**만 쓴다. 다음 청크의 추측, 장면 연출, 긴 줄거리 요약을 적지 않는다.

반드시 기록한다.

- `characters`: 생존, 육체·실제·정신 연령, 외형, 부상, 체력, 소지품, 아는 사실과 모르는 사실, 누적 능력 사용 횟수.
- `relationships`: 관계 단계, 라벨, 단계 변화를 낳은 행동 근거.
- `world`: 귀환한 별, 남은 잠금, 하늘 균열, 기한, 강제 징수 수명 상태.
- `plot`: 완료 사건, 열린 복선, 심은 복선, 회수 복선.
- `chunk_boundary`: 마지막 두 행동, 마지막 위치, 다음 청크가 반드시 도달할 종료 상태.

관계 단계가 올라가면 `evidence`에 비용을 낸 실제 행동을 적는다. 사과 한 줄이나 선언만으로 단계를 올리지 않는다.

## 컴파일러 검사 범위

### 오류로 차단

- 청크 관리 표식, Hook·Intro·Body·Climax·End, CTA·END의 개수와 위치 오류.
- 고정 대사 누락 또는 화자·감정 태그 형식 오류.
- 강무진 외 FIRM 사용.
- 정본 청크 외 요광개로·칠성도강 사용.
- 연령 체크포인트 불일치, 역노화, 능력 누적 횟수 감소.
- 허담, 노철산, 위천록의 사망 시점 위반과 부활.
- 관계 단계의 조기 도약.
- 최종 청크 마지막 직접 대사 위치 오류.

### 경고로 수동 검토

- 목표 분량에서 ±200자 이탈.
- 청크 종료 상태의 증거어 누락.
- 금지·제한 어휘, 재요약 후보, 가짜 클리프행어 후보.
- 관계 변화 근거 누락.
- 인물명·무공명·정식 용어의 문맥상 허용 가능한 반복.

어휘 검사는 기계적 후보 탐지다. 대사 자연 발화, 물리적 동작의 `짚다`, 인물명·고유명사 예외는 사람이 문맥을 보고 결정한다.

## 전체 인수 검수

21청크가 모두 있을 때 실행한다.

```bash
python /home/ubuntu/skills/chilseong-continuity-compiler/scripts/chilseong_compiler.py check-all \
  --drafts-dir /경로/칠성탈명록-대본/drafts \
  --state-dir /경로/칠성탈명록-대본/state \
  --canon /경로/칠성탈명록-대본/canon.json \
  --json > /경로/칠성탈명록-대본/reports/final_report.json
```

전체 검수는 구조 표식의 전역 개수, 21개 대본·상태 장부의 존재, 누적 상태, 연속 3청크 어휘 구간, 전체 목표 분량을 검사한다. 오류를 발견해도 새 설정으로 덮지 않는다. 오류가 시작된 **가장 최근 청크의 최소 범위**만 수정한다.

## 비낭독 출력 원칙

청크 대본, 상태 장부, 컴파일러 보고서를 섞지 않는다. TTS에 넣는 것은 `drafts/chunk_NN.md`의 대본 본문뿐이다. 전체 대본 확정 뒤에만 대사 위치 점검표와 최종 컴파일 보고서를 별도 산출물로 제공한다.
