import { describe, expect, it } from "vitest";
import { buildRewriteSystemPrompt, studioModelCandidates, validateRewriteCandidate, validateRewriteInput } from "./scriptStudio";

describe("script studio rewrite guards", () => {
  it("rejects an invalid chunk or empty manuscript", () => {
    expect(() => validateRewriteInput({ chunk: 0, content: "원고" })).toThrow();
    expect(() => validateRewriteInput({ chunk: 1, content: "  " })).toThrow();
  });

  it("requires Hook locks for the first chunk", () => {
    const valid = `[청크 01/21]\n## Hook\n[복아|놀람]"아저씨, 나 아직 스무 살이야."\n본문\n[허담|내추럴]"별이 내린 땅의 세월은 관천원의 것이다. 남은 것까지 거두어라."\n[CTA]\n## Intro\n[강무진|FIRM]"내 배에 오른 사람은, 무슨 일이 있어도 건너편에 내려준다."\n## Body`;
    expect(() => validateRewriteCandidate(1, valid)).not.toThrow();
    expect(() => validateRewriteCandidate(1, "[청크 01/21]\n## Hook\n본문")).toThrow();
  });

  it("builds a prompt that preserves adult Bokah canon", () => {
    expect(buildRewriteSystemPrompt(1)).toContain("스무 살");
    expect(buildRewriteSystemPrompt(1)).toContain("[CTA]");
  });

  it("prioritizes a cost-efficient model for style scoring without weakening rewrite selection", () => {
    expect(studioModelCandidates("score")[0]).toBe("gpt-5-mini");
    expect(studioModelCandidates("rewrite")[0]).toBe("claude-sonnet-4-6");
  });
});
