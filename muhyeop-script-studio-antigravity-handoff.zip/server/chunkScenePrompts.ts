import { invokeLLM, listLLMModels } from "./_core/llm";

export type DenseSceneInput = {
  number: number;
  sentenceIds: string[];
  koreanEvidence: string;
  dialogueEvidence?: string;
};

export type PromptCharacterAnchor = {
  name: string;
  characterSheet?: string;
  appearanceAnchor?: string;
};

export type GenerateChunkScenePromptsInput = {
  title: string;
  chunk: number;
  chunkScript: string;
  scenes: DenseSceneInput[];
  characters?: PromptCharacterAnchor[];
};

export type DenseScenePrompt = {
  sceneNumber: number;
  prompt: string;
};

export type GenerateChunkScenePromptsResult = {
  chunk: number;
  prompts: DenseScenePrompt[];
  model: string;
};

const MAX_CHUNK_SCRIPT_CHARS = 14_000;
const MAX_SCENE_COUNT = 120;
const MIN_DENSE_PROMPT_CHARS = 240;
const MAX_DENSE_PROMPT_CHARS = 3_200;

function compact(value: string, limit: number) {
  return value.replace(/\s+/g, " ").trim().slice(0, limit);
}

export function densePromptModelCandidates() {
  return ["claude-sonnet-4-6", "gpt-5", "gemini-3.1-pro-preview", "gpt-5-mini"];
}

async function pickDensePromptModel() {
  const { data } = await listLLMModels();
  const model = densePromptModelCandidates().find((candidate) => data.some((item) => item.id === candidate)) ?? data[0]?.id;
  if (!model) throw new Error("사용 가능한 장면 프롬프트 생성 모델을 찾지 못했습니다.");
  return model;
}

export function validateChunkScenePromptInput(input: GenerateChunkScenePromptsInput) {
  if (!Number.isInteger(input.chunk) || input.chunk < 1 || input.chunk > 21) throw new Error("청크 번호는 1부터 21 사이여야 합니다.");
  if (!input.title.trim()) throw new Error("작품 제목이 필요합니다.");
  if (!input.chunkScript.trim()) throw new Error("청크 원고가 비어 있습니다.");
  if (input.chunkScript.length > MAX_CHUNK_SCRIPT_CHARS) throw new Error("청크 원고가 생성 한도를 넘었습니다.");
  if (!input.scenes.length) throw new Error("생성할 장면이 없습니다.");
  if (input.scenes.length > MAX_SCENE_COUNT) throw new Error("한 번에 생성할 장면 수가 너무 많습니다. 청크 단위로 다시 나누어 주세요.");
  const seen = new Set<number>();
  input.scenes.forEach((scene) => {
    if (!Number.isInteger(scene.number) || scene.number < 1) throw new Error("장면 번호가 올바르지 않습니다.");
    if (seen.has(scene.number)) throw new Error("같은 장면 번호가 중복되었습니다.");
    seen.add(scene.number);
    if (!scene.sentenceIds.length || scene.sentenceIds.length > 3) throw new Error(`장면 ${scene.number}의 문장 연결 수가 올바르지 않습니다.`);
    if (!scene.koreanEvidence.trim()) throw new Error(`장면 ${scene.number}의 원고 근거가 비어 있습니다.`);
  });
}

export function buildDenseScenePromptSystemPrompt(input: GenerateChunkScenePromptsInput) {
  const anchors = (input.characters ?? [])
    .map((character) => {
      const sheet = compact(character.characterSheet ?? "", 700);
      const appearance = compact(character.appearanceAnchor ?? "", 500);
      return `${compact(character.name, 80)}: ${sheet || "No character sheet."}${appearance ? ` Appearance anchor: ${appearance}` : ""}`;
    })
    .join("\n");

  return `You are the visual prompt director for a Korean dark-fantasy wuxia audiobook film. Create image-generation-ready, high-density English prompts for screenplay chunk ${input.chunk} of 21 only.

Continuity contract: Use only the supplied screenplay evidence, character anchors, active objects, places, injuries, ages, and actions. Never import an event from another chunk, invent a character, add an unearned ability, change who holds an object, or reveal knowledge unavailable in this chunk. Bok-ah is an adult with an adult appearance even when the story describes an aged body. Do not depict children.

Each prompt must be a single English cinematic direction paragraph of ${MIN_DENSE_PROMPT_CHARS}-${MAX_DENSE_PROMPT_CHARS} characters. It must densely specify: the decisive action; character blocking, facial intent shown through action, costume, age condition and props when evidenced; exact location, time and atmosphere; foreground/midground/background layout; camera framing, angle, lens feeling and depth; lighting, palette and material texture; Korean wuxia dark-fantasy visual language; and a clear negative guard that includes no text, no watermark, no logo, no subtitles, no modern objects, no collage, no duplicate people, no extra limbs.

Do not write a plot summary, dialogue quotation, scene number, Markdown, Korean text, headings, alternatives, or explanations. Keep one decisive visual beat per prompt. Preserve geographic orientation and the immediate result of each action.

Project title: ${compact(input.title, 160)}
Character anchors:
${anchors || "No supplied character anchors. Describe only people identified by the screenplay evidence."}`;
}

export function validateDenseScenePromptResult(input: GenerateChunkScenePromptsInput, prompts: DenseScenePrompt[]) {
  const expected = new Set(input.scenes.map((scene) => scene.number));
  if (prompts.length !== expected.size) throw new Error(`청크 ${input.chunk}의 장면 프롬프트 수가 원고 장면 수와 다릅니다.`);
  const received = new Set<number>();
  prompts.forEach((entry) => {
    if (!expected.has(entry.sceneNumber) || received.has(entry.sceneNumber)) throw new Error(`청크 ${input.chunk}에 잘못되었거나 중복된 장면 번호가 있습니다.`);
    received.add(entry.sceneNumber);
    const prompt = entry.prompt.trim();
    if (prompt.length < MIN_DENSE_PROMPT_CHARS || prompt.length > MAX_DENSE_PROMPT_CHARS) throw new Error(`장면 ${entry.sceneNumber} 프롬프트 길이가 고밀도 범위를 벗어났습니다.`);
    if (prompt.replace(/[^a-z]/gi, "").length < 20) throw new Error(`장면 ${entry.sceneNumber} 프롬프트가 영문 시각화 지시로 보이지 않습니다.`);
    if (!/no text/i.test(prompt)) throw new Error(`장면 ${entry.sceneNumber} 프롬프트에 텍스트 제거 지시가 없습니다.`);
  });
  return prompts.map((entry) => ({ sceneNumber: entry.sceneNumber, prompt: entry.prompt.trim() })).sort((a, b) => a.sceneNumber - b.sceneNumber);
}

function parsePayload(raw: unknown) {
  if (typeof raw !== "string") throw new Error("언어 모델이 빈 장면 프롬프트 응답을 반환했습니다.");
  try {
    return JSON.parse(raw) as { prompts?: Array<{ sceneNumber?: unknown; prompt?: unknown }> };
  } catch {
    throw new Error("언어 모델이 장면 프롬프트 JSON 형식을 지키지 않았습니다.");
  }
}

export async function generateDenseChunkScenePrompts(input: GenerateChunkScenePromptsInput): Promise<GenerateChunkScenePromptsResult> {
  validateChunkScenePromptInput(input);
  const model = await pickDensePromptModel();
  const response = await invokeLLM({
    model,
    messages: [
      { role: "system", content: buildDenseScenePromptSystemPrompt(input) },
      {
        role: "user",
        content: `Chunk ${input.chunk} screenplay source:\n${compact(input.chunkScript, MAX_CHUNK_SCRIPT_CHARS)}\n\nScene evidence to convert one-for-one:\n${JSON.stringify(input.scenes.map((scene) => ({ sceneNumber: scene.number, sentenceIds: scene.sentenceIds, koreanEvidence: compact(scene.koreanEvidence, 1_200), dialogueEvidence: compact(scene.dialogueEvidence ?? "", 800) })))}`,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "dense_chunk_scene_prompts",
        strict: true,
        schema: {
          type: "object",
          properties: {
            prompts: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  sceneNumber: { type: "integer" },
                  prompt: { type: "string" },
                },
                required: ["sceneNumber", "prompt"],
                additionalProperties: false,
              },
            },
          },
          required: ["prompts"],
          additionalProperties: false,
        },
      },
    },
    maxTokens: 8_000,
  });
  const payload = parsePayload(response.choices[0]?.message.content);
  const prompts = (payload.prompts ?? []).map((entry) => ({ sceneNumber: Number(entry.sceneNumber), prompt: String(entry.prompt ?? "") }));
  return { chunk: input.chunk, prompts: validateDenseScenePromptResult(input, prompts), model };
}
