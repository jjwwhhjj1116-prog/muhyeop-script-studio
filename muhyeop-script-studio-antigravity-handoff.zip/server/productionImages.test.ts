import { describe, expect, it } from "vitest";
import { buildCharacterImagePrompt, buildSceneImagePrompt } from "./productionImages";

describe("production image prompts", () => {
  it("anchors a main character with the exact Korean name label", () => {
    const prompt = buildCharacterImagePrompt({ title: "칠성탈명록", name: "강무진", characterSheet: "은사촌의 사공. 낡은 삿대를 든다." });
    expect(prompt).toContain('exact Korean name "강무진"');
    expect(prompt).toContain("childlike appearance");
  });

  it("builds a silent text-free scene image brief", () => {
    const prompt = buildSceneImagePrompt({ title: "칠성탈명록", sceneNumber: 1, scenePrompt: "Moonlit river ferry, falling star", sceneSummary: "별이 강으로 떨어진다." });
    expect(prompt).toContain("scene 1");
    expect(prompt).toContain("no written text");
  });
});
