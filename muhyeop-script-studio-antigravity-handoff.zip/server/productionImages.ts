import { generateImage } from "./_core/imageGeneration";

export type CharacterImageRequest = {
  title: string;
  name: string;
  characterSheet: string;
  supportAnchor?: string;
};

export type SceneImageRequest = {
  title: string;
  sceneNumber: number;
  scenePrompt: string;
  sceneSummary?: string;
};

function compact(value: string, limit: number) {
  return value.replace(/\s+/g, " ").trim().slice(0, limit);
}

export function buildCharacterImagePrompt(input: CharacterImageRequest) {
  const sheet = compact(input.characterSheet, 2_400);
  const anchor = compact(input.supportAnchor ?? "", 600);
  return `Create a cinematic character reference portrait for the Korean wuxia audiobook project "${compact(input.title, 120)}".

Character: ${compact(input.name, 80)}.
Character sheet: ${sheet || "A principal character in an original Korean wuxia drama."}
${anchor ? `Continuity anchor: ${anchor}` : ""}

Composition: medium-quality polished character key art, three-quarter full-body portrait, face and costume clearly visible, dramatic but readable silhouette, restrained ink-wash inspired dark fantasy wuxia mood, aged paper and moonlit river palette, no other people.
Text to render: the exact Korean name "${compact(input.name, 80)}" as one small clean title centered at the top. No other text.
Avoid: childlike appearance, modern clothing, weapons held toward camera, extra limbs, duplicate faces, watermark, logo, collage, speech bubbles.`;
}

export function buildSceneImagePrompt(input: SceneImageRequest) {
  return `Create a cinematic 16:9 visualization still for scene ${input.sceneNumber} of the Korean wuxia audiobook project "${compact(input.title, 120)}".

Scene direction: ${compact(input.scenePrompt, 3_000)}
${input.sceneSummary ? `Narrative evidence: ${compact(input.sceneSummary, 900)}` : ""}

Composition: one decisive moment, readable character blocking, cinematic depth, Korean wuxia dark fantasy, moonlit river and ink-wash color language where appropriate, high visual continuity, no written text.
Avoid: captions, subtitles, logos, watermark, split screens, collage, modern objects, audible-action symbols, duplicated people, distorted hands.`;
}

export async function generateCharacterProductionImage(input: CharacterImageRequest) {
  const { url } = await generateImage({ prompt: buildCharacterImagePrompt(input), quality: "medium" });
  if (!url) throw new Error("인물 이미지 URL을 받지 못했습니다.");
  return { url, prompt: buildCharacterImagePrompt(input), modelQuality: "medium" as const };
}

export async function generateSceneProductionImage(input: SceneImageRequest) {
  const { url } = await generateImage({ prompt: buildSceneImagePrompt(input), quality: "medium" });
  if (!url) throw new Error("장면 이미지 URL을 받지 못했습니다.");
  return { url, prompt: buildSceneImagePrompt(input), modelQuality: "medium" as const };
}
