import { invokeLLM, listLLMModels } from "./_core/llm";

export type RewriteInput = {
  chunk: number;
  content: string;
  projectBrief?: string;
};

export type RewriteResult = {
  rewrittenMarkdown: string;
  revisionNote: string;
  preservedLocks: string[];
  model: string;
};

export type StyleScore = {
  overall: number;
  hook: number;
  companionVoice: number;
  dialogue: number;
  rhythm: number;
  martialAppeal: number;
  tts: number;
  summary: string;
  strengths: string[];
  issues: string[];
  model: string;
};

const MAX_MANUSCRIPT_CHARS = 14_000;
const MAX_BRIEF_CHARS = 5_000;
const BOKAH_HOOK = '[복아|놀람]"아저씨, 나 아직 스무 살이야."';
const HEO_DAM_HOOK = '[허담|내추럴]"별이 내린 땅의 세월은 관천원의 것이다. 남은 것까지 거두어라."';

export function buildRewriteSystemPrompt(chunk: number) {
  return `당신은 한국어 무협 오디오북 영화의 수석 편집자다. 청크 ${chunk}의 원고만 전면 문체 재작성한다.

절대 잠금: 등장인물 이름·나이·생존·부상·소지품·능력 사용 횟수·관계 단계·사건 순서·대가를 바꾸지 않는다. 새 혈통, 새 스승, 새 비급, 새 유물, 새 흑막, 새 부활 규칙을 만들지 않는다. 복아는 실제·정신 스무 살이며, 별 추락 뒤 육체만 일흔 살이다. 미성년처럼 보이게 쓰지 않는다.

문체: 화자는 강무진 곁에서 사건 뒤 짧게 반응하는 동행자다. CCTV식 관찰이나 1인칭 나레이션을 쓰지 않는다. 사람이 주어가 되어 실제 행동과 결과를 이어 쓴다. 짧은·중간·긴 문장을 섞고, 인물 속마음을 먼저 해설하지 않는다. 무협은 현대 한국어 위에 절제해 얹는다. 대사는 실제로 말할 수 있게 고친다. 모든 직접 대사는 [화자명|감정]"대사" 형식을 지킨다. FIRM은 강무진에게만 허용된다.

구조: 이 작품은 21편이 아니라 한 편의 영화다. 이 청크 밖의 Hook·Intro·CTA·END를 새로 만들거나 반복하지 않는다. 원고의 관리 표식과 기존 구조 표식은 보존한다. 결과는 마크다운 대본만이며, 설명·검수표·영어·카메라 지시·괄호 지시를 넣지 않는다.

${chunk === 1 ? `청크 1 잠금: ${BOKAH_HOOK}은 Hook 첫 직접 대사로, ${HEO_DAM_HOOK}은 Hook 마지막 직접 대사로 정확히 유지한다. 두 번째 대사 뒤에는 [CTA]가 바로 와야 한다. ## Intro와 그 안의 고정 대사·## Body는 삭제하거나 옮기지 않는다.` : ""}`;
}

export function buildScoreSystemPrompt(chunk: number) {
  return `당신은 한국어 무협 오디오북 영화의 냉정한 편집 심사자다. 청크 ${chunk} 원고를 다음 축으로 0~100점 평가한다: Hook, 동행자 화자, 대사 자연발화, 문장 리듬, 무협 쾌감, TTS. 청크 1이 아니면 Hook은 장면 진입의 긴장도로 평가한다. 점수는 관대하게 주지 말고, 개선 가능한 실제 문장 특징을 근거로 든다. 설정을 바꾸거나 새 사건을 제안하지 않는다. 복아는 스무 살 성인이고 육체만 일흔 살이라는 설정을 지킨다.`;
}

export function studioModelCandidates(task: "rewrite" | "score") {
  return task === "score"
    ? ["gpt-5-mini", "claude-haiku-4-5", "claude-sonnet-4-6", "gpt-5"]
    : ["claude-sonnet-4-6", "gpt-5", "gemini-3.1-pro-preview", "gpt-5-mini"];
}

export function validateRewriteInput(input: RewriteInput) {
  if (!Number.isInteger(input.chunk) || input.chunk < 1 || input.chunk > 21) throw new Error("청크 번호는 1부터 21 사이여야 합니다.");
  if (!input.content.trim()) throw new Error("재작성할 원고가 비어 있습니다.");
  if (input.content.length > MAX_MANUSCRIPT_CHARS) throw new Error("한 번에 재작성할 원고가 너무 깁니다.");
}

export function validateRewriteCandidate(chunk: number, markdown: string) {
  if (!markdown.includes(`[청크 ${String(chunk).padStart(2, "0")}/21]`)) throw new Error("재작성본의 청크 관리 표식이 사라졌습니다.");
  if (chunk === 1) {
    if (!markdown.includes(BOKAH_HOOK) || !markdown.includes(HEO_DAM_HOOK)) throw new Error("Hook 고정 대사가 보존되지 않았습니다.");
    if (!markdown.includes(`${HEO_DAM_HOOK}\n[CTA]`)) throw new Error("Hook 마지막 대사 뒤 CTA 위치가 바뀌었습니다.");
    if (!markdown.includes("## Intro") || !markdown.includes("## Body")) throw new Error("청크 1의 영화 구조 표식이 사라졌습니다.");
  }
}

async function pickStudioModel(task: "rewrite" | "score") {
  const { data } = await listLLMModels();
  const model = studioModelCandidates(task).find((candidate) => data.some((item) => item.id === candidate)) ?? data[0]?.id;
  if (!model) throw new Error("사용 가능한 문체 편집 모델을 찾지 못했습니다.");
  return model;
}

function parseObject(raw: unknown) {
  if (typeof raw !== "string") throw new Error("언어 모델이 비어 있는 응답을 반환했습니다.");
  try {
    return JSON.parse(raw) as Record<string, unknown>;
  } catch {
    throw new Error("언어 모델 응답 형식이 올바르지 않습니다.");
  }
}

export async function rewriteManuscriptChunk(input: RewriteInput): Promise<RewriteResult> {
  validateRewriteInput(input);
  const model = await pickStudioModel("rewrite");
  const response = await invokeLLM({
    model,
    messages: [
      { role: "system", content: buildRewriteSystemPrompt(input.chunk) },
      { role: "user", content: `현재 원고:\n\n${input.content}\n\n기획 참고:\n${(input.projectBrief ?? "연결된 기획본 없음").slice(0, MAX_BRIEF_CHARS)}` },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "manuscript_rewrite",
        strict: true,
        schema: {
          type: "object",
          properties: {
            rewrittenMarkdown: { type: "string" },
            revisionNote: { type: "string" },
            preservedLocks: { type: "array", items: { type: "string" } },
          },
          required: ["rewrittenMarkdown", "revisionNote", "preservedLocks"],
          additionalProperties: false,
        },
      },
    },
    maxTokens: 8_000,
  });
  const payload = parseObject(response.choices[0]?.message.content);
  const rewrittenMarkdown = String(payload.rewrittenMarkdown ?? "").trim();
  validateRewriteCandidate(input.chunk, rewrittenMarkdown);
  return {
    rewrittenMarkdown,
    revisionNote: String(payload.revisionNote ?? "문체 재작성 완료"),
    preservedLocks: Array.isArray(payload.preservedLocks) ? payload.preservedLocks.map(String).slice(0, 6) : [],
    model,
  };
}

export async function scoreManuscriptChunk(input: RewriteInput): Promise<StyleScore> {
  validateRewriteInput(input);
  const model = await pickStudioModel("score");
  const response = await invokeLLM({
    model,
    messages: [
      { role: "system", content: buildScoreSystemPrompt(input.chunk) },
      { role: "user", content: `평가할 원고:\n\n${input.content}` },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "manuscript_style_score",
        strict: true,
        schema: {
          type: "object",
          properties: {
            overall: { type: "integer", minimum: 0, maximum: 100 },
            hook: { type: "integer", minimum: 0, maximum: 100 },
            companionVoice: { type: "integer", minimum: 0, maximum: 100 },
            dialogue: { type: "integer", minimum: 0, maximum: 100 },
            rhythm: { type: "integer", minimum: 0, maximum: 100 },
            martialAppeal: { type: "integer", minimum: 0, maximum: 100 },
            tts: { type: "integer", minimum: 0, maximum: 100 },
            summary: { type: "string" },
            strengths: { type: "array", items: { type: "string" } },
            issues: { type: "array", items: { type: "string" } },
          },
          required: ["overall", "hook", "companionVoice", "dialogue", "rhythm", "martialAppeal", "tts", "summary", "strengths", "issues"],
          additionalProperties: false,
        },
      },
    },
    maxTokens: 3_000,
  });
  const payload = parseObject(response.choices[0]?.message.content);
  const score = (key: string) => Math.max(0, Math.min(100, Number(payload[key]) || 0));
  return {
    overall: score("overall"),
    hook: score("hook"),
    companionVoice: score("companionVoice"),
    dialogue: score("dialogue"),
    rhythm: score("rhythm"),
    martialAppeal: score("martialAppeal"),
    tts: score("tts"),
    summary: String(payload.summary ?? ""),
    strengths: Array.isArray(payload.strengths) ? payload.strengths.map(String).slice(0, 4) : [],
    issues: Array.isArray(payload.issues) ? payload.issues.map(String).slice(0, 4) : [],
    model,
  };
}
