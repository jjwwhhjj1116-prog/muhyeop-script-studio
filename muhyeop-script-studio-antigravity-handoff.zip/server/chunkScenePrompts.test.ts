import { describe, expect, it } from "vitest";
import { buildDenseScenePromptSystemPrompt, validateChunkScenePromptInput, validateDenseScenePromptResult } from "./chunkScenePrompts";

const input = {
  title: "칠성탈명록",
  chunk: 3,
  chunkScript: "강무진은 수면의 파문을 보았다. 백야의 검이 배 난간을 스쳤다.",
  scenes: [{ number: 8, sentenceIds: ["c03-l001-s1", "c03-l002-s1"], koreanEvidence: "강무진은 수면의 파문을 보았다. 백야의 검이 배 난간을 스쳤다." }],
  characters: [{ name: "강무진", appearanceAnchor: "adult Korean ferryman, weathered dark robe, old wooden pole, alert eyes" }],
};

describe("chunk dense scene prompts", () => {
  it("builds a chunk-scoped system prompt with adult-appearance and negative guards", () => {
    const prompt = buildDenseScenePromptSystemPrompt(input);
    expect(prompt).toContain("chunk 3 of 21 only");
    expect(prompt).toContain("Do not depict children");
    expect(prompt).toContain("no watermark");
  });

  it("rejects cross-chunk generation input and accepts a complete dense result", () => {
    expect(() => validateChunkScenePromptInput({ ...input, chunk: 22 })).toThrow("청크 번호");
    const dense = "A moonlit river ferry at night, adult Korean ferryman Kang Mujin braces beside the wet wooden rail as a black-clad swordsman cuts through the mist, the pole hooks the rail and water ripples reveal the attack line, three-quarter low angle medium-wide framing, tense foreground splashes, lantern glow against ink-blue shadows, weathered wood texture, cinematic Korean wuxia dark fantasy, shallow depth of field, no text, no watermark, no logo, no subtitles, no modern objects, no collage, no duplicate people, no extra limbs.";
    expect(validateDenseScenePromptResult(input, [{ sceneNumber: 8, prompt: dense }])).toEqual([{ sceneNumber: 8, prompt: dense }]);
  });

  it("rejects short or oversized prompts, missing scene numbers, and missing text-removal guards", () => {
    const valid = "A moonlit river ferry at night, adult Korean ferryman Kang Mujin braces beside the wet wooden rail as a black-clad swordsman cuts through the mist, the pole hooks the rail and water ripples reveal the attack line, three-quarter low angle medium-wide framing, tense foreground splashes, lantern glow against ink-blue shadows, weathered wood texture, cinematic Korean wuxia dark fantasy, shallow depth of field, no text, no watermark, no logo, no subtitles, no modern objects, no collage, no duplicate people, no extra limbs.";
    expect(() => validateDenseScenePromptResult(input, [{ sceneNumber: 8, prompt: "no text, cinematic river" }])).toThrow("길이");
    expect(() => validateDenseScenePromptResult(input, [{ sceneNumber: 8, prompt: `${valid}${"a".repeat(3_300)}` }])).toThrow("길이");
    expect(() => validateDenseScenePromptResult(input, [{ sceneNumber: 9, prompt: valid }])).toThrow("장면 번호");
    expect(() => validateDenseScenePromptResult(input, [{ sceneNumber: 8, prompt: valid.replace("no text", "clean image") }])).toThrow("텍스트 제거");
  });
});
