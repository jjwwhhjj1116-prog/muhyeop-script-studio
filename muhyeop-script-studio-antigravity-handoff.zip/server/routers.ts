import { COOKIE_NAME } from "@shared/const";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { generateDenseChunkScenePrompts } from "./chunkScenePrompts";
import { generateCharacterProductionImage, generateSceneProductionImage } from "./productionImages";
import { rewriteManuscriptChunk, scoreManuscriptChunk } from "./scriptStudio";

const manuscriptInput = z.object({
  chunk: z.number().int().min(1).max(21),
  content: z.string().min(1).max(14_000),
  projectBrief: z.string().max(5_000).optional(),
});
type ManuscriptInput = z.infer<typeof manuscriptInput>;

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  manuscript: router({
    rewrite: protectedProcedure
      .input(manuscriptInput)
      .mutation(({ input }: { input: ManuscriptInput }) => rewriteManuscriptChunk(input)),
    score: protectedProcedure
      .input(manuscriptInput)
      .mutation(({ input }: { input: ManuscriptInput }) => scoreManuscriptChunk(input)),
  }),

  productionImages: router({
    generateCharacter: protectedProcedure.input(z.object({
      title: z.string().min(1).max(160),
      name: z.string().min(1).max(80),
      characterSheet: z.string().min(12).max(4_000),
      supportAnchor: z.string().max(1_000).optional(),
    })).mutation(({ input }) => generateCharacterProductionImage(input)),
    generateScene: protectedProcedure.input(z.object({
      title: z.string().min(1).max(160),
      sceneNumber: z.number().int().min(1).max(1_000),
      scenePrompt: z.string().min(12).max(4_000),
      sceneSummary: z.string().max(1_500).optional(),
    })).mutation(({ input }) => generateSceneProductionImage(input)),
    generateDenseChunkPrompts: protectedProcedure.input(z.object({
      title: z.string().min(1).max(160),
      chunk: z.number().int().min(1).max(21),
      chunkScript: z.string().min(1).max(14_000),
      scenes: z.array(z.object({
        number: z.number().int().min(1).max(1_000),
        sentenceIds: z.array(z.string().min(1).max(40)).min(1).max(3),
        koreanEvidence: z.string().min(1).max(1_500),
        dialogueEvidence: z.string().max(1_000).optional(),
      })).min(1).max(120),
      characters: z.array(z.object({
        name: z.string().min(1).max(80),
        characterSheet: z.string().max(1_000).optional(),
        appearanceAnchor: z.string().max(800).optional(),
      })).max(8).optional(),
    })).mutation(({ input }) => generateDenseChunkScenePrompts(input)),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
