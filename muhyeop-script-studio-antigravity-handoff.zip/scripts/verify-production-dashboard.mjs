import { chromium } from "playwright";

import { readFile } from "node:fs/promises";
import { strFromU8, unzipSync } from "fflate";

const baseUrl = process.env.DASHBOARD_URL ?? "http://localhost:3000";
const browser = await chromium.launch({
  headless: true,
  executablePath: process.env.CHROMIUM_PATH ?? "/usr/bin/chromium",
  args: ["--no-sandbox"],
});
const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });

try {
  await page.goto(baseUrl, { waitUntil: "networkidle" });
  await page.getByText("무협스튜디오", { exact: true }).waitFor({ state: "visible" });
  await page.getByLabel("현재 제작 작품").getByText("칠성탈명록", { exact: true }).waitFor({ state: "visible" });
  const dashboard = page.getByRole("region", { name: "무협 장편영화 제작 대시보드" });
  await dashboard.getByRole("button", { name: "제작 관리 열기" }).click();

  const [scriptDownload] = await Promise.all([
    page.waitForEvent("download"),
    dashboard.getByRole("button", { name: "최종 대본 JSON" }).click(),
  ]);
  if (!scriptDownload.suggestedFilename().endsWith("_최종대본.json")) throw new Error("최종 대본 JSON 다운로드 파일명이 올바르지 않습니다.");

  const scriptCard = dashboard.locator("article").filter({ hasText: "대본 승인" });
  const scriptApproval = scriptCard.getByRole("button", { name: "대본 승인" });
  if (!(await scriptApproval.isEnabled())) throw new Error("기본 21청크 원고에서 대본 승인 버튼이 활성화되지 않았습니다.");
  await scriptApproval.click();
  await page.getByRole("status").waitFor({ state: "visible" });
  await page.getByRole("status").waitFor({ state: "hidden" });

  await page.evaluate(() => {
    const key = "chilseong-production-workflow-v1";
    const workflow = JSON.parse(window.localStorage.getItem(key) ?? "{}");
    ["characters", "visualization", "flow", "video", "metadata", "audit"].forEach((key) => { workflow.stages[key].status = "APPROVED"; });
    workflow.scenes = (workflow.sentences ?? []).reduce((scenes, sentence, index) => {
      if (index % 3 === 0) scenes.push({ number: scenes.length + 1, scriptSentenceIds: [], dialogueIds: [], koText: "", enImagePrompt: "Cinematic wuxia river scene" });
      const scene = scenes.at(-1);
      scene.scriptSentenceIds.push(sentence.id);
      if (sentence.dialogue) scene.dialogueIds.push(sentence.id);
      scene.koText = `${scene.koText} ${sentence.text}`.trim();
      return scenes;
    }, []);
    workflow.flowLines = workflow.scenes.map((scene) => scene.enImagePrompt);
    workflow.videoLines = workflow.scenes.map((scene) => `Slow camera movement through scene ${scene.number}, silent visual only`);
    window.localStorage.setItem(key, JSON.stringify(workflow));
  });
  await page.reload({ waitUntil: "networkidle" });
  const preparedDashboard = page.getByRole("region", { name: "무협 장편영화 제작 대시보드" });
  await preparedDashboard.getByRole("button", { name: "제작 관리 열기" }).click();
  const characterCard = preparedDashboard.locator("article").filter({ hasText: "캐릭터 승인" });
  await characterCard.getByPlaceholder("캐릭터 시트: 역할, 나이, 외형, 의상, 무기, 감정선").first().fill("은사촌의 사공. 오래된 삿대를 들고 사람을 끝까지 건너편에 내려준다.");
  const appearanceAnchor = "Kang Mujin, Korean man in his mid twenties, weathered navy ferryman robe, wooden pole, calm determined gaze";
  await characterCard.getByPlaceholder("English full appearance anchor for generated image").first().fill(appearanceAnchor);
  await page.getByRole("status").waitFor({ state: "visible" });
  await page.getByRole("status").waitFor({ state: "hidden" });
  const characterInvalidation = await page.evaluate(() => {
    const workflow = JSON.parse(window.localStorage.getItem("chilseong-production-workflow-v1") ?? "{}");
    return ["visualization", "flow", "video", "audit"].every((key) => workflow.stages[key]?.status === "INVALIDATED");
  });
  if (!characterInvalidation) throw new Error("캐릭터 수정 뒤 시각화 이후 단계가 무효화되지 않았습니다.");
  const characterLab = preparedDashboard.locator("article").filter({ hasText: "주요 인물 이미지 생성" });
  const characterGenerate = characterLab.getByRole("button", { name: "인물 이미지 생성" }).first();
  if (!(await characterGenerate.isEnabled())) throw new Error("캐릭터 시트 입력 뒤 인물 이미지 생성 버튼이 활성화되지 않았습니다.");
  await page.route("**/api/trpc/productionImages.generateCharacter**", async (route) => {
    await route.fulfill({ contentType: "application/json", body: JSON.stringify([{ result: { data: { json: { url: "/manus-storage/chilseong-hero-river_2078f38d.jpg" } } } }]) });
  });
  await characterGenerate.click();
  await page.getByText("강무진 인물 이미지를 생성했습니다.").last().waitFor({ state: "visible" });
  const storedCharacter = await page.evaluate(() => JSON.parse(window.localStorage.getItem("chilseong-production-workflow-v1") ?? "{}").characters?.find((character) => character.name === "강무진"));
  if (storedCharacter?.imageUrl !== "/manus-storage/chilseong-hero-river_2078f38d.jpg" || storedCharacter?.supportAnchor !== appearanceAnchor) throw new Error("생성 이미지 URL 또는 주요 인물 외형 앵커가 저장소에 정확히 반영되지 않았습니다.");
  await page.getByRole("status").waitFor({ state: "visible" });
  await page.getByRole("status").waitFor({ state: "hidden" });
  await characterCard.getByRole("button", { name: "시트·이미지 미리보기" }).first().click();
  const preview = page.getByRole("dialog", { name: "강무진 캐릭터 미리보기" });
  await preview.waitFor({ state: "visible" });
  await preview.getByText("캐릭터 시트").waitFor({ state: "visible" });
  await preview.getByText("ENGLISH APPEARANCE ANCHOR").waitFor({ state: "visible" });
  const displayedAnchor = await preview.locator("p").filter({ hasText: appearanceAnchor }).last().textContent();
  if (displayedAnchor !== appearanceAnchor) throw new Error("캐릭터 미리보기 모달의 외형 앵커가 입력값과 일치하지 않습니다.");
  const generatedPreviewSrc = await preview.locator("img").getAttribute("src");
  if (!generatedPreviewSrc?.includes("chilseong-hero-river_2078f38d.jpg")) throw new Error("캐릭터 미리보기 모달에 생성 이미지 URL이 반영되지 않았습니다.");
  await preview.getByRole("button", { name: "캐릭터 미리보기 닫기" }).click();
  const visualReview = preparedDashboard.locator("article").filter({ hasText: "인물 이미지 · 외형 앵커 육안 검수" });
  await visualReview.getByText("ENGLISH APPEARANCE ANCHOR").first().waitFor({ state: "visible" });
  await visualReview.getByLabel("강무진 외형 검수 메모").fill("턱 흉터, 남색 사공 도포, 삿대가 외형 앵커와 일치한다.");
  await visualReview.getByRole("button", { name: "일치 승인" }).first().click();
  await page.getByText("강무진 외형 비교를 승인했습니다.").waitFor({ state: "visible" });
  const reviewedCharacter = await page.evaluate(() => JSON.parse(window.localStorage.getItem("chilseong-production-workflow-v1") ?? "{}").characters?.find((character) => character.name === "강무진"));
  if (reviewedCharacter?.appearanceReviewStatus !== "APPROVED" || !reviewedCharacter?.appearanceReviewNote.includes("턱 흉터")) throw new Error("인물 이미지·외형 앵커 시각 검수 판정이 저장되지 않았습니다.");
  await page.unroute("**/api/trpc/productionImages.generateCharacter**");
  await page.route("**/api/trpc/productionImages.generateCharacter**", async (route) => {
    await route.fulfill({ status: 500, contentType: "application/json", body: JSON.stringify({ error: "temporary image service failure" }) });
  });
  await characterLab.getByRole("button", { name: "인물 이미지 재생성" }).first().click();
  await page.getByText("강무진 이미지 생성을 완료하지 못했습니다.").waitFor({ state: "visible" });
  await page.unroute("**/api/trpc/productionImages.generateCharacter**");
  await page.route("**/api/trpc/productionImages.generateCharacter**", async (route) => {
    await route.fulfill({ contentType: "application/json", body: JSON.stringify([{ result: { data: { json: { url: "/manus-storage/chilseong-hero-river_2078f38d.jpg" } } } }]) });
  });
  await characterLab.getByRole("button", { name: "인물 이미지 재생성" }).first().click();
  await page.getByText("강무진 인물 이미지를 생성했습니다.").last().waitFor({ state: "visible" });

  await page.evaluate(() => {
    const key = "chilseong-production-workflow-v1";
    const workflow = JSON.parse(window.localStorage.getItem(key) ?? "{}");
    ["characters", "visualization", "flow", "video", "metadata", "audit"].forEach((key) => { workflow.stages[key].status = "APPROVED"; });
    window.localStorage.setItem(key, JSON.stringify(workflow));
  });
  await page.reload({ waitUntil: "networkidle" });
  const visualDashboard = page.getByRole("region", { name: "무협 장편영화 제작 대시보드" });
  await visualDashboard.getByRole("button", { name: "제작 관리 열기" }).click();
  const visualizationCard = visualDashboard.locator("article").filter({ hasText: "시각화 매핑" });
  await visualizationCard.getByPlaceholder("English image prompt. Keep continuity, character references, props, location, and action.").first().fill("Moonlit river crossing, older ferryman, cinematic dark wuxia, medium shot");
  await page.getByRole("status").waitFor({ state: "visible" });
  await page.getByRole("status").waitFor({ state: "hidden" });
  const visualInvalidation = await page.evaluate(() => {
    const workflow = JSON.parse(window.localStorage.getItem("chilseong-production-workflow-v1") ?? "{}");
    return ["flow", "video", "metadata", "audit"].every((key) => workflow.stages[key]?.status === "INVALIDATED");
  });
  if (!visualInvalidation) throw new Error("시각화 수정 뒤 Flow·영상·메타데이터·감사가 무효화되지 않았습니다.");
  const sceneLab = visualDashboard.locator("article").filter({ hasText: "장면 이미지 일괄 생성" });
  const batchGenerate = sceneLab.getByRole("button", { name: "프롬프트 장면 일괄 생성" });
  if (!(await batchGenerate.isEnabled())) throw new Error("시각화 프롬프트 입력 뒤 장면 이미지 일괄 생성 버튼이 활성화되지 않았습니다.");
  await page.evaluate(() => {
    const key = "chilseong-production-workflow-v1";
    const workflow = JSON.parse(window.localStorage.getItem(key) ?? "{}");
    workflow.scenes = workflow.scenes.slice(0, 2);
    workflow.scenes.forEach((scene) => { scene.enImagePrompt = scene.enImagePrompt || "Moonlit river crossing, dark wuxia cinematic scene"; scene.imageUrl = ""; scene.imageGeneratedAt = null; });
    const kangMujin = workflow.characters?.find((character) => character.name === "강무진");
    if (kangMujin) kangMujin.supportAnchor = "scarred jaw, weathered navy hemp robe";
    workflow.scenes.push({
      ...workflow.scenes[1],
      number: 3,
      chunk: 2,
      scriptSentenceIds: ["c02-l001-s1", "c02-l001-s2"],
      dialogueIds: [],
      koText: "청크 이의 보관 장면. 이 장면은 청크 일 프롬프트 오류와 무관하다.",
      enImagePrompt: "Chunk two preserved riverbank scene, no text, cinematic Korean wuxia",
      promptSource: "manual",
      promptGeneratedAt: null,
      promptModel: null,
      imageUrl: "/manus-storage/preserved-chunk-two.png",
      imageGeneratedAt: "2026-08-20T00:00:00.000Z",
    });
    window.localStorage.setItem(key, JSON.stringify(workflow));
  });
  await page.reload({ waitUntil: "networkidle" });
  const batchDashboard = page.getByRole("region", { name: "무협 장편영화 제작 대시보드" });
  await batchDashboard.getByRole("button", { name: "제작 관리 열기" }).click();
  await page.unroute("**/api/trpc/productionImages.generateCharacter**");
  const densePromptLab = batchDashboard.locator("article").filter({ hasText: "청크별 고밀도 장면 프롬프트" });
  const densePromptButton = densePromptLab.getByRole("button", { name: "이 청크 고밀도 생성" });
  if (!(await densePromptButton.isEnabled())) throw new Error("청크별 장면 골격 뒤 고밀도 프롬프트 생성 버튼이 활성화되지 않았습니다.");
  await page.route("**/api/trpc/productionImages.generateDenseChunkPrompts**", async (route) => {
    await route.fulfill({ status: 500, contentType: "application/json", body: JSON.stringify({ error: "temporary prompt service failure" }) });
  });
  await densePromptButton.click();
  await page.getByText("청크 1 프롬프트 생성을 완료하지 못했습니다.").waitFor({ state: "visible" });
  await page.unroute("**/api/trpc/productionImages.generateDenseChunkPrompts**");
  const beforeMalformedResponse = await page.evaluate(() => JSON.parse(window.localStorage.getItem("chilseong-production-workflow-v1") ?? "{}").scenes?.map((scene) => ({ chunk: scene.chunk, prompt: scene.enImagePrompt, source: scene.promptSource })));
  const stageStateBeforeMalformedResponse = await page.evaluate(() => JSON.parse(window.localStorage.getItem("chilseong-production-workflow-v1") ?? "{}").stages);
  const preservedChunkTwoBefore = await page.evaluate(() => JSON.parse(window.localStorage.getItem("chilseong-production-workflow-v1") ?? "{}").scenes?.find((scene) => scene.chunk === 2));
  const malformedDensePrompt = "A moonlit river ferry at night, adult Korean ferryman Kang Mujin braces beside the wet wooden rail while the aged adult Bok-ah withdraws behind him, an enforcer blocks the riverbank in the midground, old wooden pole and torn ferry rope anchor the foreground, decisive three-quarter medium-wide low angle, lantern glow fractures over ink-blue water and black mist, rain-dark hemp robes and wet wood grain, cinematic Korean wuxia dark fantasy, deep atmospheric perspective, no watermark, no logo, no subtitles, no modern objects, no collage, no duplicate people, no extra limbs.";
  await page.route("**/api/trpc/productionImages.generateDenseChunkPrompts**", async (route) => {
    await route.fulfill({ contentType: "application/json", body: JSON.stringify([{ result: { data: { json: { chunk: 1, model: "gpt-5-mini", prompts: [{ sceneNumber: 1, prompt: malformedDensePrompt }, { sceneNumber: 2, prompt: malformedDensePrompt }] } } } }]) });
  });
  await densePromptLab.getByRole("button", { name: "이 청크 고밀도 생성" }).click();
  await page.getByText("청크 1 프롬프트 생성을 완료하지 못했습니다.").last().waitFor({ state: "visible" });
  const afterMalformedResponse = await page.evaluate(() => JSON.parse(window.localStorage.getItem("chilseong-production-workflow-v1") ?? "{}").scenes?.map((scene) => ({ chunk: scene.chunk, prompt: scene.enImagePrompt, source: scene.promptSource })));
  if (JSON.stringify(afterMalformedResponse) !== JSON.stringify(beforeMalformedResponse)) throw new Error("잘못된 고밀도 응답이 저장소를 변경했습니다.");
  const stageStateAfterMalformedResponse = await page.evaluate(() => JSON.parse(window.localStorage.getItem("chilseong-production-workflow-v1") ?? "{}").stages);
  if (JSON.stringify(stageStateAfterMalformedResponse) !== JSON.stringify(stageStateBeforeMalformedResponse)) throw new Error("잘못된 고밀도 응답이 전역 제작 단계 상태를 변경했습니다.");
  const preservedChunkTwoAfterMalformed = await page.evaluate(() => JSON.parse(window.localStorage.getItem("chilseong-production-workflow-v1") ?? "{}").scenes?.find((scene) => scene.chunk === 2));
  if (JSON.stringify(preservedChunkTwoAfterMalformed) !== JSON.stringify(preservedChunkTwoBefore)) throw new Error("청크 1의 잘못된 응답이 청크 2 보관 장면을 변경했습니다.");
  await page.unroute("**/api/trpc/productionImages.generateDenseChunkPrompts**");
  const densePrompt = "A moonlit river ferry at night, adult Korean ferryman Kang Mujin with a scarred jaw and weathered navy hemp robe braces beside the wet wooden rail while the aged adult Bok-ah withdraws behind him, an enforcer blocks the riverbank in the midground, old wooden pole and torn ferry rope anchor the foreground, decisive three-quarter medium-wide low angle, lantern glow fractures over ink-blue water and black mist, rain-dark hemp robes and wet wood grain, cinematic Korean wuxia dark fantasy, deep atmospheric perspective, no text, no watermark, no logo, no subtitles, no modern objects, no collage, no duplicate people, no extra limbs.";
  await page.route("**/api/trpc/productionImages.generateDenseChunkPrompts**", async (route) => {
    await route.fulfill({ contentType: "application/json", body: JSON.stringify([{ result: { data: { json: { chunk: 1, model: "gpt-5-mini", prompts: [{ sceneNumber: 1, prompt: densePrompt }, { sceneNumber: 2, prompt: densePrompt }] } } } }]) });
  });
  await densePromptLab.getByRole("button", { name: "이 청크 고밀도 생성" }).click();
  await page.getByText("청크 1 고밀도 프롬프트를 생성했습니다.").waitFor({ state: "visible" });
  const denseStored = await page.evaluate(() => JSON.parse(window.localStorage.getItem("chilseong-production-workflow-v1") ?? "{}").scenes?.map((scene) => ({ chunk: scene.chunk, prompt: scene.enImagePrompt, source: scene.promptSource })));
  const denseChunkOneStored = denseStored?.filter((scene) => scene.chunk === 1);
  if (!Array.isArray(denseChunkOneStored) || denseChunkOneStored.length !== 2 || denseChunkOneStored.some((scene) => scene.prompt !== densePrompt || scene.source !== "generated")) throw new Error("청크별 고밀도 프롬프트가 장면 저장소에 정확히 연결되지 않았습니다.");
  await densePromptLab.getByText("예상 이미지 생성 비용 단위 · 2회 요청").waitFor({ state: "visible" });
  await densePromptLab.getByText("외형 앵커 핵심어 유지").waitFor({ state: "visible" });
  const overlongPromptPrefix = "scarred jaw navy robe wet wooden ferry rail, ".repeat(90);
  await page.evaluate((prefix) => {
    const key = "chilseong-production-workflow-v1";
    const workflow = JSON.parse(window.localStorage.getItem(key) ?? "{}");
    workflow.scenes.filter((scene) => scene.chunk === 1).forEach((scene) => {
      scene.enImagePrompt = `${prefix}${scene.enImagePrompt}`;
    });
    workflow.scenes.find((scene) => scene.number === 1).koText = "강무진과 복아가 젖은 나루에 함께 섰다.";
    const kangMujin = workflow.characters?.find((character) => character.name === "강무진");
    const bokA = workflow.characters?.find((character) => character.name === "복아");
    if (kangMujin) kangMujin.supportAnchor = "male female, black hair white hair, navy robe, wooden pole";
    if (bokA) bokA.supportAnchor = "female, white hair, navy robe, wooden pole";
    window.localStorage.setItem(key, JSON.stringify(workflow));
  }, overlongPromptPrefix);
  await page.reload({ waitUntil: "networkidle" });
  const optimizedDashboard = page.getByRole("region", { name: "무협 장편영화 제작 대시보드" });
  await optimizedDashboard.getByRole("button", { name: "제작 관리 열기" }).click();
  const optimizedPromptLab = optimizedDashboard.locator("article").filter({ hasText: "청크별 고밀도 장면 프롬프트" });
  await optimizedPromptLab.getByRole("button", { name: "길이·중복 자동 보정" }).click();
  await page.getByText("청크 1 프롬프트를 자동 보정했습니다.").waitFor({ state: "visible" });
  const optimizedPrompts = await page.evaluate(() => JSON.parse(window.localStorage.getItem("chilseong-production-workflow-v1") ?? "{}").scenes?.filter((scene) => scene.chunk === 1).map((scene) => scene.enImagePrompt));
  if (!optimizedPrompts?.every((prompt) => prompt.length <= 1600 && /no text/i.test(prompt))) throw new Error("프롬프트 자동 보정이 길이 상한 또는 네거티브 가드를 지키지 못했습니다.");
  const optimizationDiff = optimizedDashboard.locator("article").filter({ hasText: "자동 보정 전후 비교 · 되돌리기" });
  await optimizationDiff.getByText("BEFORE · 보정 전").first().waitFor({ state: "visible" });
  await page.evaluate((prefix) => {
    const key = "chilseong-production-workflow-v1";
    const workflow = JSON.parse(window.localStorage.getItem(key) ?? "{}");
    const scene = workflow.scenes?.find((entry) => entry.number === 1);
    if (scene) scene.enImagePrompt = `${prefix}${scene.enImagePrompt}`;
    window.localStorage.setItem(key, JSON.stringify(workflow));
  }, overlongPromptPrefix);
  await page.reload({ waitUntil: "networkidle" });
  const versionDashboard = page.getByRole("region", { name: "무협 장편영화 제작 대시보드" });
  await versionDashboard.getByRole("button", { name: "제작 관리 열기" }).click();
  const versionPromptLab = versionDashboard.locator("article").filter({ hasText: "청크별 고밀도 장면 프롬프트" });
  await versionPromptLab.getByRole("button", { name: "길이·중복 자동 보정" }).click();
  await page.getByText("청크 1 프롬프트를 자동 보정했습니다.").last().waitFor({ state: "visible" });
  const versionVault = versionDashboard.locator("article").filter({ hasText: "자동 보정 이력 버전 선택 복구" });
  const versionSelector = versionVault.getByLabel("장면 1 보정 이력 선택");
  await versionSelector.selectOption({ index: 0 });
  await versionVault.getByRole("button", { name: "선택 이력으로 복구" }).first().click();
  await page.getByText("장면 1 프롬프트를 선택한 보정 전 상태로 되돌렸습니다.", { exact: true }).waitFor({ state: "visible" });
  const restoredPrompt = await page.evaluate(() => JSON.parse(window.localStorage.getItem("chilseong-production-workflow-v1") ?? "{}").scenes?.find((scene) => scene.number === 1)?.enImagePrompt);
  if (!restoredPrompt?.startsWith(overlongPromptPrefix)) throw new Error("프롬프트 자동 보정 전 상태 복구가 원문을 되살리지 못했습니다.");
  const conflictWatch = versionDashboard.locator("article").filter({ hasText: "장면별 인물 외형 앵커 충돌 경고" });
  await conflictWatch.getByText("강무진의 성별 앵커가 서로 모순됩니다.").first().waitFor({ state: "visible" });
  await conflictWatch.getByText(/강무진·복아.*navy robe 표식/).first().waitFor({ state: "visible" });
  const conflictQuickFix = versionDashboard.locator("article").filter({ hasText: "경고 창에서 외형 앵커 바로 수정" });
  await conflictQuickFix.getByLabel("강무진 충돌 앵커 수정").fill("male, black hair, navy robe, wooden pole");
  await conflictQuickFix.getByRole("button", { name: "저장 · 충돌 다시 검사" }).first().click();
  await page.getByText("강무진의 외형 앵커를 저장하고 충돌을 다시 검사했습니다.").waitFor({ state: "visible" });
  await conflictQuickFix.getByLabel("복아 충돌 앵커 수정").fill("female, white hair, white robe, long sword");
  await conflictQuickFix.getByRole("button", { name: "저장 · 충돌 다시 검사" }).last().click();
  await page.getByText("복아의 외형 앵커를 저장하고 충돌을 다시 검사했습니다.").waitFor({ state: "visible" });
  await conflictWatch.getByText("충돌 없음", { exact: true }).waitFor({ state: "visible" });
  const resolvedAnchors = await page.evaluate(() => {
    const characters = JSON.parse(window.localStorage.getItem("chilseong-production-workflow-v1") ?? "{}").characters ?? [];
    return characters.filter((character) => ["강무진", "복아"].includes(character.name)).map((character) => character.supportAnchor);
  });
  if (resolvedAnchors.some((anchor) => /male female|black hair white hair|navy robe, wooden pole/.test(anchor) && anchor.includes("female"))) throw new Error("충돌 경고의 인라인 앵커 수정이 저장되지 않았습니다.");
  const preservedChunkTwoAfterRetry = await page.evaluate(() => JSON.parse(window.localStorage.getItem("chilseong-production-workflow-v1") ?? "{}").scenes?.find((scene) => scene.chunk === 2));
  if (JSON.stringify(preservedChunkTwoAfterRetry) !== JSON.stringify(preservedChunkTwoBefore)) throw new Error("청크 1 재시도가 청크 2 보관 장면을 변경했습니다.");
  await page.evaluate(() => {
    const key = "chilseong-production-workflow-v1";
    const workflow = JSON.parse(window.localStorage.getItem(key) ?? "{}");
    workflow.scenes.filter((scene) => scene.chunk === 1 || scene.chunk === 2).forEach((scene) => { scene.koText = "강무진과 복아가 같은 나루에 섰다."; });
    const kangMujin = workflow.characters?.find((character) => character.name === "강무진");
    const bokA = workflow.characters?.find((character) => character.name === "복아");
    if (kangMujin) kangMujin.supportAnchor = "male, black hair, navy robe, wooden pole";
    if (bokA) bokA.supportAnchor = "female, white hair, navy robe, wooden pole";
    window.localStorage.setItem(key, JSON.stringify(workflow));
  });
  await page.reload({ waitUntil: "networkidle" });
  const commonConflictDashboard = page.getByRole("region", { name: "무협 장편영화 제작 대시보드" });
  await commonConflictDashboard.getByRole("button", { name: "제작 관리 열기" }).click();
  const commonConflictLab = commonConflictDashboard.locator("article").filter({ hasText: "여러 청크 공통 충돌 일괄 수정" });
  const commonConflictControl = commonConflictDashboard.locator("article").filter({ hasText: "공통 충돌 이력 · 필터 · 수정안" });
  await commonConflictControl.getByLabel("공통 충돌 심각도 필터").selectOption("warning");
  await commonConflictControl.getByLabel("공통 충돌 영향 청크 필터").selectOption("2");
  await commonConflictControl.getByLabel("공통 충돌 정렬").selectOption("impact_asc");
  await commonConflictControl.getByRole("button", { name: "수정안 채우기" }).first().click();
  const suggestedBokA = await commonConflictControl.getByLabel("공통 충돌 제안 복아 앵커 수정").first().inputValue();
  if (suggestedBokA === "female, white hair, navy robe, wooden pole") throw new Error("공통 충돌 수정안이 외형 앵커 초안을 바꾸지 못했습니다.");
  await commonConflictLab.getByText(/강무진 · 복아 · 청크 01, 02/).first().waitFor({ state: "visible" });
  await commonConflictControl.getByLabel("공통 충돌 제안 복아 앵커 수정").first().fill("female, silver hair, white robe, long sword");
  await commonConflictControl.getByRole("button", { name: "이 충돌 일괄 수정 · 전체 재검사" }).first().click();
  await page.getByText("2명 외형 앵커를 일괄 저장하고 21청크를 다시 검사했습니다.").waitFor({ state: "visible" });
  await commonConflictControl.getByRole("button", { name: "이 이력으로 복구" }).first().click();
  await page.getByText("공통 충돌 수정 이력의 이전 앵커로 복구했습니다.").waitFor({ state: "visible" });
  await commonConflictControl.getByLabel("공통 충돌 제안 복아 앵커 수정").first().fill("female, silver hair, white robe, long sword");
  await commonConflictControl.getByRole("button", { name: "이 충돌 일괄 수정 · 전체 재검사" }).first().click();
  await page.getByText("2명 외형 앵커를 일괄 저장하고 21청크를 다시 검사했습니다.").last().waitFor({ state: "visible" });
  await commonConflictLab.getByText("반복 충돌 없음", { exact: true }).waitFor({ state: "visible" });
  const commonFixed = await page.evaluate(() => {
    const workflow = JSON.parse(window.localStorage.getItem("chilseong-production-workflow-v1") ?? "{}");
    return { bokA: workflow.characters?.find((character) => character.name === "복아")?.supportAnchor, characterStage: workflow.stages?.characters?.status };
  });
  if (commonFixed.bokA !== "female, silver hair, white robe, long sword" || commonFixed.characterStage !== "NEEDS_REVIEW") throw new Error("공통 충돌 일괄 앵커 수정 또는 전체 재검사가 저장되지 않았습니다.");
  const preservedChunkTwoAfterCommonBatch = await page.evaluate(() => JSON.parse(window.localStorage.getItem("chilseong-production-workflow-v1") ?? "{}").scenes?.find((scene) => scene.chunk === 2));
  const [chunkDownload] = await Promise.all([
    page.waitForEvent("download"),
    densePromptLab.getByRole("button", { name: "이 청크 JSON" }).click(),
  ]);
  if (!chunkDownload.suggestedFilename().endsWith("_청크_01_고밀도_시각화.json")) throw new Error("청크별 고밀도 시각화 JSON 다운로드 파일명이 올바르지 않습니다.");
  await page.unroute("**/api/trpc/productionImages.generateDenseChunkPrompts**");
  await page.route("**/api/trpc/productionImages.generateScene**", async (route) => {
    await new Promise((resolve) => setTimeout(resolve, 80));
    await route.fulfill({ contentType: "application/json", body: JSON.stringify([{ result: { data: { json: { url: "/manus-storage/chilseong-hero-river_2078f38d.jpg" } } } }]) });
  });
  const batchLab = batchDashboard.locator("article").filter({ hasText: "장면 이미지 일괄 생성" });
  await batchLab.getByRole("button", { name: "프롬프트 장면 일괄 생성" }).click();
  await batchLab.getByText(/진행 \d+\/2/).waitFor({ state: "visible" });
  await page.getByText("장면 이미지 일괄 생성을 마쳤습니다.").waitFor({ state: "visible" });
  const generatedScenes = await page.evaluate(() => JSON.parse(window.localStorage.getItem("chilseong-production-workflow-v1") ?? "{}").scenes);
  const generatedChunkOneScenes = generatedScenes?.filter((scene) => scene.chunk === 1);
  const preservedChunkTwoAfterImages = generatedScenes?.find((scene) => scene.chunk === 2);
  if (!Array.isArray(generatedChunkOneScenes) || generatedChunkOneScenes.length !== 2 || generatedChunkOneScenes.some((scene) => scene.imageUrl !== "/manus-storage/chilseong-hero-river_2078f38d.jpg") || JSON.stringify(preservedChunkTwoAfterImages) !== JSON.stringify(preservedChunkTwoAfterCommonBatch)) throw new Error("청크별 장면 일괄 생성 결과 또는 다른 청크 보관 자산이 올바르게 유지되지 않았습니다.");
  await page.unroute("**/api/trpc/productionImages.generateScene**");

  await page.evaluate(() => {
    const key = "chilseong-production-workflow-v1";
    const workflow = JSON.parse(window.localStorage.getItem(key) ?? "{}");
    workflow.stages.visualization.status = "APPROVED";
    window.localStorage.setItem(key, JSON.stringify(workflow));
  });
  await page.reload({ waitUntil: "networkidle" });
  const flowDashboard = page.getByRole("region", { name: "무협 장편영화 제작 대시보드" });
  await flowDashboard.getByRole("button", { name: "제작 관리 열기" }).click();
  const flowChunkLab = flowDashboard.locator("article").filter({ hasText: "청크별 고밀도 장면 프롬프트" });
  const [flowZipDownload] = await Promise.all([
    page.waitForEvent("download"),
    flowChunkLab.getByRole("button", { name: "Flow ZIP" }).click(),
  ]);
  if (!flowZipDownload.suggestedFilename().endsWith("_청크_01_Flow_묶음.zip")) throw new Error("승인 청크의 Flow ZIP 파일명이 올바르지 않습니다.");
  const zipPath = await flowZipDownload.path();
  if (!zipPath) throw new Error("Flow ZIP 다운로드 경로를 찾지 못했습니다.");
  const zipFiles = unzipSync(new Uint8Array(await readFile(zipPath)));
  const flowZipNames = Object.keys(zipFiles).sort();
  if (!flowZipNames.some((name) => name.endsWith("_청크_01_Flow.txt")) || !flowZipNames.some((name) => name.endsWith("_청크_01_Flow_장면_ID_매핑.json"))) throw new Error("Flow ZIP 안에 txt와 장면 ID 매핑 JSON이 함께 들어 있지 않습니다.");
  if (!strFromU8(zipFiles[flowZipNames.find((name) => name.endsWith(".txt"))]).includes("no text")) throw new Error("Flow ZIP의 txt에 청크 프롬프트가 없습니다.");
  const flowMultiLab = flowDashboard.locator("article").filter({ hasText: "여러 청크 Flow CSV · ZIP 일괄 내보내기" });
  await flowMultiLab.getByLabel("Flow 패키지 청크 1").check();
  await flowMultiLab.getByLabel("Flow 패키지 청크 2").check();
  const [flowMultiZipDownload] = await Promise.all([
    page.waitForEvent("download"),
    flowMultiLab.getByRole("button", { name: "Flow CSV·ZIP 일괄 내보내기" }).click(),
  ]);
  if (!flowMultiZipDownload.suggestedFilename().endsWith("_청크_01-02_Flow_일괄_묶음.zip")) throw new Error("다중 청크 Flow ZIP 파일명이 올바르지 않습니다.");
  const multiZipPath = await flowMultiZipDownload.path();
  if (!multiZipPath) throw new Error("다중 청크 Flow ZIP 다운로드 경로를 찾지 못했습니다.");
  const multiZipFiles = unzipSync(new Uint8Array(await readFile(multiZipPath)));
  const multiZipNames = Object.keys(multiZipFiles);
  if (!multiZipNames.some((name) => name.endsWith("_Flow_전체_장면_매핑.csv")) || multiZipNames.filter((name) => name.endsWith(".txt")).length !== 2 || multiZipNames.filter((name) => name.endsWith("_장면_ID_매핑.json")).length !== 2) throw new Error("다중 청크 Flow ZIP의 txt·JSON·CSV 구성이 올바르지 않습니다.");
  const csvName = multiZipNames.find((name) => name.endsWith("_Flow_전체_장면_매핑.csv"));
  if (!csvName || !strFromU8(multiZipFiles[csvName]).includes("script_sentence_ids")) throw new Error("다중 청크 Flow CSV에 장면 ID 매핑이 없습니다.");

  await page.evaluate(() => {
    const key = "chilseong-production-workflow-v1";
    const workflow = JSON.parse(window.localStorage.getItem(key) ?? "{}");
    workflow.stages.metadata.status = "APPROVED";
    workflow.stages.audit.status = "APPROVED";
    window.localStorage.setItem(key, JSON.stringify(workflow));
  });
  await page.reload({ waitUntil: "networkidle" });
  const metadataDashboard = page.getByRole("region", { name: "무협 장편영화 제작 대시보드" });
  await metadataDashboard.getByRole("button", { name: "제작 관리 열기" }).click();
  const metadataCard = metadataDashboard.locator("article").filter({ hasText: "제목·설명란·썸네일" });
  await metadataCard.getByPlaceholder("제목 입력").first().fill("별은 왜 강으로 떨어졌나?");
  await page.getByRole("status").waitFor({ state: "visible" });
  await page.getByRole("status").waitFor({ state: "hidden" });
  const metadataInvalidation = await page.evaluate(() => JSON.parse(window.localStorage.getItem("chilseong-production-workflow-v1") ?? "{}").stages.audit?.status === "INVALIDATED");
  if (!metadataInvalidation) throw new Error("메타데이터 수정 뒤 최종 감사가 무효화되지 않았습니다.");

  const reloadedDashboard = page.getByRole("region", { name: "무협 장편영화 제작 대시보드" });
  const [visualizationDownload] = await Promise.all([
    page.waitForEvent("download"),
    reloadedDashboard.getByRole("button", { name: "시각화 JSON" }).first().click(),
  ]);
  if (!visualizationDownload.suggestedFilename().endsWith("_시각화_장면.json")) throw new Error("시각화 JSON 다운로드 파일명이 올바르지 않습니다.");

  await page.locator('input[type="file"]').nth(2).setInputFiles({ name: "새_무협기획안.md", mimeType: "text/markdown", buffer: Buffer.from("# 흑월검가\n\n강호를 뒤흔드는 검가와 별의 장부를 다룬 무협 장편 기획안이다.", "utf8") });
  await page.getByText("GPT 기획본을 작업실에 연결했습니다.").waitFor({ state: "visible" });
  const planningBrief = page.getByRole("region", { name: "무협기획안 상위 제작 단계" });
  await planningBrief.getByRole("heading", { name: "무협기획안" }).waitFor({ state: "visible" });
  await planningBrief.getByText("흑월검가", { exact: true }).waitFor({ state: "visible" });
  await page.getByLabel("현재 제작 작품").getByText("흑월검가", { exact: true }).waitFor({ state: "visible" });
  await page.waitForFunction(() => JSON.parse(window.localStorage.getItem("chilseong-production-workflow-v1") ?? "{}").title === "흑월검가");

  console.log(JSON.stringify({ ok: true, scriptJson: scriptDownload.suggestedFilename(), visualizationJson: visualizationDownload.suggestedFilename(), chunkVisualizationJson: chunkDownload.suggestedFilename() }));
} finally {
  await browser.close();
}
