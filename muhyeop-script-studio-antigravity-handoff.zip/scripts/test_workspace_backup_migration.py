#!/usr/bin/env python3
"""Unit tests for the workspace-backup-to-Firestore migration transformer."""

from __future__ import annotations

import importlib.util
import sys
import unittest
from pathlib import Path


MODULE_PATH = Path(__file__).with_name("migrate_workspace_backup_to_firestore.py")
SPEC = importlib.util.spec_from_file_location("workspace_migration", MODULE_PATH)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


def workspace_backup() -> dict:
    return {
        "schema": "chilseong-script-studio-backup-v1",
        "createdAt": "2026-08-21T00:00:00.000Z",
        "projectBrief": {"sourceName": "칠성탈명록_기획안.md", "content": "# 칠성탈명록\n\n기획안 본문", "importedAt": "2026-08-21T00:00:00.000Z"},
        "importedChunks": {
            "1": {"chunk": 1, "title": "별이 떨어진 밤", "content": "[청크 01/21]\n원고", "sourceName": "chunk_01.md", "importedAt": "2026-08-21T00:00:00.000Z"},
            "2": {"chunk": 2, "title": "목숨에도 세금이 붙었다", "content": "[청크 02/21]\n원고", "sourceName": "chunk_02.md", "importedAt": "2026-08-21T00:00:00.000Z"},
        },
        "editedChunks": {"2": "[청크 02/21]\n수정 원고"},
        "draftVersions": {"2": [{"id": "snapshot/one", "content": "이전 수정 원고", "memo": "초안", "createdAt": "2026-08-21T00:00:00.000Z"}]},
        "stateLedgers": {
            "1": {"chunk": 1, "characters": {"복아": {"mind_age": 20, "body_age": 70}}, "relationships": {"강무진-복아": {"stage": 1}}},
            "2": {"chunk": 2, "characters": {"강무진": {"body_age": 24}}, "relationships": {"강무진-단여령": {"stage": 1}}},
        },
        "styleProfile": {"preferredEnding": "현재형 혼합"},
        "productionWorkflow": {"title": "칠성탈명록", "scenes": []},
    }


class WorkspaceBackupMigrationTest(unittest.TestCase):
    def test_builds_project_documents_and_preserves_edited_chunk(self) -> None:
        project_id, documents, warnings = MODULE.build_migration_plan(workspace_backup(), "muhyeop-studio-test")
        by_path = {document.path: document.data for document in documents}
        self.assertEqual(project_id, "muhyeop-studio-test")
        self.assertIn("projects/muhyeop-studio-test/chunks/02", by_path)
        self.assertEqual(by_path["projects/muhyeop-studio-test/chunks/02"]["currentSource"], "edited")
        self.assertEqual(by_path["projects/muhyeop-studio-test/chunks/02"]["currentContent"], "[청크 02/21]\n수정 원고")
        self.assertIn("projects/muhyeop-studio-test/stateLedgers/01", by_path)
        self.assertIn("projects/muhyeop-studio-test/workflow/current", by_path)
        self.assertTrue(any("원본 청크가 2개" in warning for warning in warnings))

    def test_rejects_edited_chunk_without_source(self) -> None:
        backup = workspace_backup()
        backup["editedChunks"] = {"3": "고아 수정본"}
        with self.assertRaises(MODULE.MigrationError):
            MODULE.build_migration_plan(backup, "muhyeop-studio-test")

    def test_rejects_wrong_backup_schema(self) -> None:
        backup = workspace_backup()
        backup["schema"] = "other-schema"
        with self.assertRaises(MODULE.MigrationError):
            MODULE.build_migration_plan(backup, "muhyeop-studio-test")

    def test_serializes_safe_snapshot_id_and_plan(self) -> None:
        project_id, documents, _ = MODULE.build_migration_plan(workspace_backup(), "muhyeop-studio-test")
        payload = MODULE.plan_payload(project_id, documents, [])
        paths = [entry["path"] for entry in payload["documents"]]
        self.assertIn("projects/muhyeop-studio-test/chunkVersions/02-snapshot-one", paths)
        self.assertEqual(payload["documentCount"], len(documents))


if __name__ == "__main__":
    unittest.main()
