import assert from "node:assert/strict";
import { captureDraftVersion, findDraftVersions, lineDiff, toggleDraftVersionPin } from "../client/src/lib/draftVersions.ts";

let versions = {};
versions = captureDraftVersion(versions, 2, "첫 원고\n둘째 줄", "수정본 저장", "첫 호흡 보정");
assert.equal(versions[2].length, 1, "첫 저장본이 보관되어야 합니다.");
assert.equal(versions[2][0].characterCount, 6, "공백을 제외한 글자 수를 기록해야 합니다.");
assert.equal(versions[2][0].note, "첫 호흡 보정", "사용자 제목 메모를 함께 보관해야 합니다.");

versions = captureDraftVersion(versions, 2, "첫 원고\n둘째 줄", "수정본 저장");
assert.equal(versions[2].length, 1, "같은 내용은 중복 보관하면 안 됩니다.");

versions = captureDraftVersion(versions, 2, "첫 원고\n둘째 줄", "수정본 저장", "대사 톤 보정");
assert.equal(versions[2].length, 1, "같은 내용에 메모만 더하면 중복 버전 대신 기존 메모를 갱신해야 합니다.");
assert.equal(versions[2][0].note, "대사 톤 보정", "같은 원고의 제목 메모를 갱신해야 합니다.");

versions = captureDraftVersion(versions, 2, "첫 원고\n고친 둘째 줄", "수정본 저장");
assert.equal(versions[2].length, 2, "변경된 내용은 새 버전으로 보관되어야 합니다.");
versions = toggleDraftVersionPin(versions, 2, versions[2][0].id);
assert.equal(versions[2][0].pinned, true, "핀 고정은 브라우저 보관 데이터에 남아야 합니다.");
assert.equal(findDraftVersions(versions[2], "대사")[0].note, "대사 톤 보정", "제목 메모 검색은 관련 버전만 찾아야 합니다.");
assert.equal(findDraftVersions(versions[2], "")[0].pinned, true, "고정한 버전은 최신 저장본보다 먼저 표시되어야 합니다.");
assert.equal(lineDiff("첫 원고\n둘째 줄", "첫 원고\n고친 둘째 줄").length, 1, "줄 비교는 바뀐 줄만 반환해야 합니다.");

console.log("draft version regression: passed");
