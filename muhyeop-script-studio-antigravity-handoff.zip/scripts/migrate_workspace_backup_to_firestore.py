#!/usr/bin/env python3
"""Convert and optionally upload a Manus workspace backup to Cloud Firestore.

The script is intentionally two-stage. It always validates and creates a
document plan first. Firestore writes occur only when --apply is supplied.
Authentication uses Google Application Default Credentials and never reads
credentials from the backup JSON.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


BACKUP_SCHEMA = "chilseong-script-studio-backup-v1"
MIGRATION_SCHEMA_VERSION = 1
PROJECT_ID_PATTERN = re.compile(r"^[a-z][a-z0-9-]{2,62}$")
CHUNK_ID_PATTERN = re.compile(r"^(?:0?[1-9]|1[0-9]|2[01])$")


class MigrationError(ValueError):
    """Raised when a workspace backup cannot be mapped without loss."""


@dataclass(frozen=True)
class FirestoreDocument:
    """One Firestore document write in the migration plan."""

    path: str
    data: dict[str, Any]


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def normalise_document_id(value: str, label: str) -> str:
    cleaned = value.strip().lower()
    cleaned = re.sub(r"[^a-z0-9-]+", "-", cleaned).strip("-")
    if not PROJECT_ID_PATTERN.fullmatch(cleaned):
        raise MigrationError(f"{label}은(는) 영문 소문자·숫자·하이픈으로 된 3~63자 ID여야 합니다: {value!r}")
    return cleaned


def derive_project_id(backup: dict[str, Any]) -> str:
    brief = backup.get("projectBrief") or {}
    content = brief.get("content") if isinstance(brief, dict) else ""
    source_name = brief.get("sourceName") if isinstance(brief, dict) else ""
    heading_match = re.search(r"^#\s+(.+?)\s*$", content or "", re.MULTILINE)
    candidate = heading_match.group(1) if heading_match else Path(source_name or "muhyeop-script-studio").stem
    ascii_slug = re.sub(r"[^a-z0-9]+", "-", candidate.lower()).strip("-")
    if not ascii_slug:
        ascii_slug = "muhyeop-script-studio"
    return normalise_document_id(f"{ascii_slug[:40]}-{sha256(candidate)[:8]}", "자동 생성 project ID")


def load_backup(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as error:
        raise MigrationError(f"백업 파일을 찾지 못했습니다: {path}") from error
    except json.JSONDecodeError as error:
        raise MigrationError(f"백업 JSON 문법 오류: {error}") from error
    if not isinstance(payload, dict):
        raise MigrationError("백업 JSON 최상위 값은 객체여야 합니다.")
    return payload


def require_mapping(payload: dict[str, Any], key: str) -> dict[str, Any]:
    value = payload.get(key)
    if not isinstance(value, dict):
        raise MigrationError(f"백업의 {key} 값은 객체여야 합니다.")
    return value


def normalise_chunk_number(value: Any, context: str) -> int:
    text = str(value).strip()
    if not CHUNK_ID_PATTERN.fullmatch(text):
        raise MigrationError(f"{context}의 청크 번호는 1~21이어야 합니다: {value!r}")
    return int(text)


def validate_backup(backup: dict[str, Any]) -> list[str]:
    if backup.get("schema") != BACKUP_SCHEMA:
        raise MigrationError(
            "지원하지 않는 백업 형식입니다. 무협스튜디오에서 내보낸 "
            f"{BACKUP_SCHEMA} 백업만 사용할 수 있습니다."
        )

    imported = require_mapping(backup, "importedChunks")
    edited = require_mapping(backup, "editedChunks")
    ledgers = require_mapping(backup, "stateLedgers")
    warnings: list[str] = []

    for key, chunk in imported.items():
        number = normalise_chunk_number(key, "importedChunks")
        if not isinstance(chunk, dict) or not isinstance(chunk.get("content"), str) or not chunk["content"].strip():
            raise MigrationError(f"importedChunks/{number:02d}에 비어 있지 않은 content 문자열이 필요합니다.")
        if int(chunk.get("chunk", number)) != number:
            raise MigrationError(f"importedChunks/{number:02d}의 키와 chunk 필드가 일치하지 않습니다.")

    for key, content in edited.items():
        number = normalise_chunk_number(key, "editedChunks")
        if number not in {normalise_chunk_number(entry, "importedChunks") for entry in imported}:
            raise MigrationError(f"editedChunks/{number:02d}는 원본 청크 없이 존재할 수 없습니다.")
        if not isinstance(content, str) or not content.strip():
            raise MigrationError(f"editedChunks/{number:02d}는 비어 있지 않은 문자열이어야 합니다.")

    for key, ledger in ledgers.items():
        number = normalise_chunk_number(key, "stateLedgers")
        if not isinstance(ledger, dict):
            raise MigrationError(f"stateLedgers/{number:02d}는 객체여야 합니다.")
        if not isinstance(ledger.get("characters"), dict) or not isinstance(ledger.get("relationships"), dict):
            raise MigrationError(f"stateLedgers/{number:02d}에는 characters와 relationships 객체가 필요합니다.")
        declared = ledger.get("chunk")
        if declared is not None and normalise_chunk_number(declared, "stateLedgers.chunk") != number:
            raise MigrationError(f"stateLedgers/{number:02d}의 키와 chunk 필드가 일치하지 않습니다.")

    loaded = len(imported)
    if loaded != 21:
        warnings.append(f"원본 청크가 {loaded}개입니다. 21개 전체가 아니므로 최종 통합본·전수 검수는 가져오기 뒤 별도 확인이 필요합니다.")
    if len(ledgers) != 21:
        warnings.append(f"상태 장부가 {len(ledgers)}개입니다. 누락 장부가 있으면 청크 간 연속성 검수가 잠깁니다.")
    return warnings


def text_title(brief: dict[str, Any] | None) -> str:
    if not brief:
        return "칠성탈명록"
    content = brief.get("content") if isinstance(brief, dict) else ""
    heading = re.search(r"^#\s+(.+?)\s*$", content or "", re.MULTILINE)
    if heading:
        return heading.group(1).strip()[:80]
    source = brief.get("sourceName") if isinstance(brief, dict) else ""
    return Path(source or "칠성탈명록").stem[:80] or "칠성탈명록"


def append_document(documents: list[FirestoreDocument], path: str, data: dict[str, Any]) -> None:
    if len(path.split("/")) % 2 != 0:
        raise MigrationError(f"Firestore 문서 경로가 아닙니다: {path}")
    documents.append(FirestoreDocument(path=path, data=data))


def build_migration_plan(backup: dict[str, Any], project_id: str | None = None) -> tuple[str, list[FirestoreDocument], list[str]]:
    warnings = validate_backup(backup)
    target_id = normalise_document_id(project_id, "project ID") if project_id else derive_project_id(backup)
    imported = require_mapping(backup, "importedChunks")
    edited = require_mapping(backup, "editedChunks")
    versions = backup.get("draftVersions") or {}
    ledgers = require_mapping(backup, "stateLedgers")
    brief = backup.get("projectBrief")
    style_profile = backup.get("styleProfile")
    workflow = backup.get("productionWorkflow") or backup.get("workflow")
    migrated_at = utc_now()
    base = f"projects/{target_id}"
    documents: list[FirestoreDocument] = []

    append_document(documents, base, {
        "schemaVersion": MIGRATION_SCHEMA_VERSION,
        "title": text_title(brief if isinstance(brief, dict) else None),
        "sourceBackupSchema": BACKUP_SCHEMA,
        "sourceBackupCreatedAt": backup.get("createdAt"),
        "sourceBackupSha256": sha256(backup),
        "migratedAt": migrated_at,
        "migrationTool": "migrate_workspace_backup_to_firestore.py",
        "counts": {
            "importedChunks": len(imported),
            "editedChunks": len(edited),
            "stateLedgers": len(ledgers),
            "draftVersionGroups": len(versions) if isinstance(versions, dict) else 0,
        },
    })

    if isinstance(brief, dict) and isinstance(brief.get("content"), str) and brief["content"].strip():
        append_document(documents, f"{base}/briefs/current", {
            **brief,
            "contentSha256": sha256(brief["content"]),
            "migratedAt": migrated_at,
        })

    for key, source in sorted(imported.items(), key=lambda item: normalise_chunk_number(item[0], "importedChunks")):
        chunk = normalise_chunk_number(key, "importedChunks")
        current = edited.get(str(chunk), edited.get(chunk, source["content"]))
        current_source = "edited" if str(chunk) in edited or chunk in edited else "source"
        chunk_path = f"{base}/chunks/{chunk:02d}"
        append_document(documents, chunk_path, {
            "chunk": chunk,
            "title": source.get("title") or f"청크 {chunk:02d}",
            "source": source,
            "currentContent": current,
            "currentSource": current_source,
            "currentContentSha256": sha256(current),
            "updatedAt": migrated_at,
        })
        append_document(documents, f"{base}/chunkVersions/legacy-{chunk:02d}-source", {
            "chunk": chunk,
            "kind": "source",
            "content": source["content"],
            "sourceName": source.get("sourceName"),
            "importedAt": source.get("importedAt"),
            "contentSha256": sha256(source["content"]),
            "migratedAt": migrated_at,
        })
        if current_source == "edited":
            append_document(documents, f"{base}/chunkVersions/legacy-{chunk:02d}-edited", {
                "chunk": chunk,
                "kind": "edited",
                "content": current,
                "contentSha256": sha256(current),
                "migratedAt": migrated_at,
            })

    if isinstance(versions, dict):
        for key, snapshots in versions.items():
            chunk = normalise_chunk_number(key, "draftVersions")
            if not isinstance(snapshots, list):
                raise MigrationError(f"draftVersions/{chunk:02d}는 배열이어야 합니다.")
            for index, snapshot in enumerate(snapshots):
                if not isinstance(snapshot, dict) or not isinstance(snapshot.get("content"), str):
                    raise MigrationError(f"draftVersions/{chunk:02d}/{index}에 content 문자열이 필요합니다.")
                snapshot_id = str(snapshot.get("id") or f"legacy-{index + 1}")
                safe_id = re.sub(r"[^A-Za-z0-9_-]", "-", snapshot_id)[:120] or f"legacy-{index + 1}"
                append_document(documents, f"{base}/chunkVersions/{chunk:02d}-{safe_id}", {
                    "chunk": chunk,
                    "kind": "snapshot",
                    "snapshot": snapshot,
                    "contentSha256": sha256(snapshot["content"]),
                    "migratedAt": migrated_at,
                })

    for key, ledger in sorted(ledgers.items(), key=lambda item: normalise_chunk_number(item[0], "stateLedgers")):
        chunk = normalise_chunk_number(key, "stateLedgers")
        append_document(documents, f"{base}/stateLedgers/{chunk:02d}", {
            **ledger,
            "chunk": chunk,
            "ledgerSha256": sha256(ledger),
            "migratedAt": migrated_at,
        })

    if style_profile is not None:
        append_document(documents, f"{base}/settings/styleProfile", {
            "profile": style_profile,
            "profileSha256": sha256(style_profile),
            "migratedAt": migrated_at,
        })

    if workflow is not None:
        if not isinstance(workflow, dict):
            raise MigrationError("productionWorkflow 또는 workflow는 객체여야 합니다.")
        append_document(documents, f"{base}/workflow/current", {
            "workflow": workflow,
            "workflowSha256": sha256(workflow),
            "migratedAt": migrated_at,
        })
    else:
        warnings.append("현재 작업실 백업 v1에는 제작 대시보드 상태가 포함되지 않을 수 있습니다. productionWorkflow를 추가한 확장 백업이 있으면 함께 이관할 수 있습니다.")

    append_document(documents, f"{base}/migrationEvents/legacy-import", {
        "type": "workspace_backup_import",
        "sourceBackupSha256": sha256(backup),
        "documentCount": len(documents) + 1,
        "warnings": warnings,
        "createdAt": migrated_at,
    })
    return target_id, documents, warnings


def plan_payload(project_id: str, documents: Iterable[FirestoreDocument], warnings: list[str]) -> dict[str, Any]:
    materialised = list(documents)
    return {
        "schemaVersion": MIGRATION_SCHEMA_VERSION,
        "projectId": project_id,
        "documentCount": len(materialised),
        "warnings": warnings,
        "documents": [{"path": item.path, "data": item.data} for item in materialised],
    }


def upload_documents(project_id: str, documents: list[FirestoreDocument], allow_overwrite: bool) -> None:
    try:
        import firebase_admin
        from firebase_admin import firestore
    except ImportError as error:
        raise MigrationError(
            "업로드에는 firebase-admin 패키지가 필요합니다. "
            "requirements-migration.txt를 설치한 뒤 다시 실행하세요."
        ) from error

    try:
        firebase_admin.get_app()
    except ValueError:
        firebase_admin.initialize_app(options={"projectId": project_id})
    db = firestore.client()
    project_ref = db.document(f"projects/{project_id}")
    if project_ref.get().exists and not allow_overwrite:
        raise MigrationError(
            f"projects/{project_id}가 이미 존재합니다. 기존 데이터를 보존하려면 다른 --project-id를 사용하세요. "
            "정말 덮어쓸 경우에만 --allow-overwrite를 추가하세요."
        )

    for start in range(0, len(documents), 400):
        batch = db.batch()
        for document in documents[start:start + 400]:
            batch.set(db.document(document.path), document.data)
        batch.commit()


def main() -> int:
    parser = argparse.ArgumentParser(description="무협스튜디오 작업실 백업을 Firestore 프로젝트 문서로 변환·업로드합니다.")
    parser.add_argument("--backup", required=True, type=Path, help="칠성탈명록_작업실_백업.json 경로")
    parser.add_argument("--project-id", help="Firestore projects 컬렉션의 대상 문서 ID. 미입력 시 기획안에서 안전하게 생성합니다.")
    parser.add_argument("--plan-out", type=Path, help="변환한 Firestore 문서 계획을 JSON으로 저장할 경로")
    parser.add_argument("--apply", action="store_true", help="검증된 계획을 실제 Firestore에 업로드합니다. 없으면 드라이런만 수행합니다.")
    parser.add_argument("--allow-overwrite", action="store_true", help="이미 존재하는 projects/{projectId} 문서를 덮어씁니다. --apply와 함께만 사용할 수 있습니다.")
    args = parser.parse_args()

    if args.allow_overwrite and not args.apply:
        parser.error("--allow-overwrite는 --apply와 함께만 사용할 수 있습니다.")
    try:
        backup = load_backup(args.backup)
        project_id, documents, warnings = build_migration_plan(backup, args.project_id)
        payload = plan_payload(project_id, documents, warnings)
        if args.plan_out:
            args.plan_out.parent.mkdir(parents=True, exist_ok=True)
            args.plan_out.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(f"[OK] projectId: {project_id}")
        print(f"[OK] Firestore documents: {len(documents)}")
        for warning in warnings:
            print(f"[WARN] {warning}")
        if not args.apply:
            print("[DRY RUN] 실제 Firestore에는 쓰지 않았습니다. 업로드하려면 --apply를 추가하세요.")
            return 0
        upload_documents(project_id, documents, args.allow_overwrite)
        print("[APPLIED] Firestore 업로드를 완료했습니다.")
        return 0
    except MigrationError as error:
        print(f"[ERROR] {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
