import assert from "node:assert/strict";
import { applyCastSuggestions, inspectRhythmWithRanges, parseCastTable, previewRelationshipSuggestions, styleGuidance, updateStyleProfile } from "../client/src/lib/writingAssistant.ts";

const cast = parseCastTable(`
## 인물표
강무진
- 나이: 24세
- 무기: 오래된 나무 삿대, 배의 밧줄

복아
- 실제 나이: 20세
- 육체 나이: 70세
`);
const bokAh = cast.suggestions.find((item) => item.name === "복아");
assert.equal(bokAh?.fields.mind_age, 8);
assert.equal(bokAh?.fields.body_age, 58);

const relationReport = parseCastTable("강무진 ↔ 단여령 관계: 2단계 불편한 동행");
assert.equal(relationReport.relationships[0]?.pair, "강무진|단여령");
assert.equal(relationReport.relationships[0]?.stage, 2);
const ledger = { chunk: 5, characters: { 강무진: {}, 단여령: {} }, relationships: { "강무진|단여령": { stage: 1, evidence: ["직전 장부"] } } };
const relationApplied = applyCastSuggestions(ledger, relationReport);
assert.equal(relationApplied.ledger.relationships?.["강무진|단여령"]?.stage, 2, "현재 청크 상한 안의 관계 단계만 반영해야 합니다.");
const relationPreview = previewRelationshipSuggestions(ledger, relationReport);
assert.equal(relationPreview[0]?.status, "apply", "반영 가능한 관계는 미리보기에서 적용 가능으로 표시해야 합니다.");
assert.equal(relationPreview[0]?.currentStage, 1, "미리보기는 현재 장부 단계를 보여줘야 합니다.");
assert.equal(relationPreview[0]?.nextStage, 2, "미리보기는 반영 후 단계를 보여줘야 합니다.");
const futureReport = parseCastTable("강무진 ↔ 단여령 관계: 9단계 같은 배에 남음");
const futureBlocked = applyCastSuggestions(ledger, futureReport);
assert.equal(futureBlocked.ledger.relationships?.["강무진|단여령"]?.stage, 1, "미래 관계 단계는 현재 청크에 반영하면 안 됩니다.");
assert.equal(previewRelationshipSuggestions(ledger, futureReport)[0]?.status, "skip", "상한을 넘는 관계 제안은 미리보기에서 보류로 표시해야 합니다.");

const rhythm = inspectRhythmWithRanges("문이 열렸다. 불이 번졌다. 배가 흔들렸다. 그는 삿대를 놓지 않았다.");
assert.ok(rhythm.some((notice) => notice.label === "짧은 문장 3연속"));
assert.ok(rhythm.every((notice) => notice.end > notice.start));

const profile = updateStyleProfile(null, "문이 열렸다.", "문이 열렸다. 그는 배를 밀었다. 물살이 길을 열었다.");
assert.equal(profile.sampleCount, 1);
assert.ok(styleGuidance(profile).includes("사용자 수정 1회"));
const learnedRhythm = inspectRhythmWithRanges("문이 열렸다. 불이 번졌다. 배가 흔들렸다.", profile);
assert.ok(Array.isArray(learnedRhythm));

console.log("writing assistant regression checks passed");
